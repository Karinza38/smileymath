db = [
"""
   ___      ___
  /   \____/   \ 
 /    / __ \    \ 
/    |  ..  |    \ 
\___/|      |\___/\ 
   | |_|  |_|      \ 
   | |/|__|\|       \ 
   |   |__|         |\ 
   |   |__|   |_/  /  \ 
   | @ |  | @ || @ |   '
   |   |~~|   ||   |     -Hamilton Furtado-
   'ooo'  'ooo''ooo'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/elephants
""", 
"""            __     __
           /  \~~~/  \ 
     ,----(     ..    )
    /      \__     __/
   /|         (\  |(
  ^ \   /___\  /\ |   hjw
     |__|   |__|-"    `97

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/elephants
""", 
"""
                    _,,......_
                 ,-'          `'--.
              ,-'  _              '-.
     (`.    ,'   ,  `-.              `.
      \ \  -    / )    \               \ 
       `\`-^^^, )/      |     /         :
         )^ ^ ^V/            /          '.
         |      )            |           `.
         9   9 /,--,\    |._:`         .._`.
         |    /   /  `.  \    `.      (   `.`.
         |   / \  \    \  \     `--\   )    `.`.___
-hrr-   .;;./  '   )   '   )       ///'       `-"'
        `--'   7//\    ///\ 

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/aardvarks
""", 
"""
   /\                 /\ 
  / \'._   (\_/)   _.'/ \ 
 /_.''._'--('.')--'_.''._\ 
 | \_ / `;=/ " \=;` \ _/ |
  \/ `\__|`\___/`|__/`  \/
jgs`      \(/|\)/       `
           " ` "

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/bats
""", 
"""
        _     _
       (o\---/o)
        ( . . )
       _( (T) )_
      / /     \ \ 
     / /       \ \ 
     \_)       (_/
   hjw \   _   /
   w97 _)  |  (_
      (___,'.___)

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/bears%20(teddybears)
""", 
"""
         _  /  _       /
        (o\/--/o)     /
        ,(/. . )    ,/
      ,'_/ (Y) )  ,'/
 ___,'_(/ \__ ( ,' /
 \ ,' //\    `-.-./
  \  (/  `---.__)/)
   \ /\    \  \ /\ 
    \__)    )  )__\ 
  hjw (    (  (
  `97  \    )  )
        `--^`--^

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/bears%20(teddybears)
""", 
"""
          (`-"-`)
           /'Y'\ 
         __\_^_/__
        ()_ >o< _()
           ) : (
      jgs / /-\ \ 
         ()/   \()

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/bears%20(teddybears)
""", 
"""
   .
    .\!i/, ,. .,: ,!i//., . ,      ,
   -\'  _ `  `" `"' '"`' ''" ":/.\'!i/.
   >-  :,'     ,-'  .:   ._          /-
    `.   ..'..     .:.     '     .'. -"
     -; .'   `.    .;.            `  ""'
     ,:  :, .:      ;              ,\\'
    -;     "                      .;
    ".            0  0       ..'  ;"
    ':  `.      _.----.__   .''   -:
     =!  '`   .' (`\"\"\";  `.      ."
   .-\"\"\"-.    !   `--'    !  ,-`""''.
  _____.'  .'   ;___`.___/\____.'_:    .'  :_______
    :_      .'                 `._     ,'Bugbyte
   '""`""                      `"'"`

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/bears%20(teddybears)
""", 
r"""

                                       .m. .m.
                                      m$$$$$"$m
      .m$m. .m$m.                     #$$$$$m$#
     m$$$$$v$$L"$m                     `#$$$#'
     $$$$$$$$$$ $$                       `#'
     `$$$$$$$$$$$'
      `#$$$$$$$#'                                 .m$m.  .m$m.
        `#$$$#'                                   m$$$$v$$L"$m
          `#'                                     $$$$$$$$$ $$
                                                  `$$$$$$$$$$'
                             _.......__          _.-`#$$$$#'
  .m. .m.            _...--""    `.    ""'--.../'  ___`#\ 
  $$$$$m$         _."              :              ' .  \ \ 
  `#$$$#'_....__."..                :                `./ /
    `#' /  __ .'...                 :                  ,/      .m. .m.
       l  /  ....           .-.     :     .-.           \      $$$$$m$
      l. /  .....          ( o )    :    ( o )           1     `#$$$#'
      1  |  ....            `-'  _______  `-'            |       `#'
       \  \ .....             ,-"   Y   "-.          .---.
        `\_ .....            /      :      \ .---.x.(     )
           \.....   .---.   l  )-.__j__.-(  (     )xx".@.'_._
            \....  (     )   \            -"-".@.'-"-)@o@(   )
             `\. .-.`.@.'.-.  `'-.---.--x(   )@o@(   )'@'.'-'
               )(   )@o@(   )xxx(     )xxx`-','@`.`-'(   )xx.
           .xxxxx`-','@'.`-'xx.-.`.@.'.-.xxx(     )xxx`-'xxxxxxxxx.
      .xxxxxxxxxxxx(     )xxx(   )@o@(   )xxx`---'xxxxxxx \xxxxxxxxxxx.
   .xxxxx' .:xxxxxxx`---'xxxxx`-','@`.`-'   /        `xxx .\xx'`xx  `xxx
  xxx'   .xxxxxx'  .xxxxxx'     (     )     \          `x  .lx'   `x
 x'      xxx'/... .xxx'          `---'       )          { }/       { }
{ }     x'  /..   xx'                       /';-\"\"\"""-._ ~/         ~
 ~     { }  |...  x' \...                 ,/ /'  _____  `\ 
        ~   l..  { }  \...              ,/ /'  _/     `\. `\ 
            |...  ~    `-....________,.-' /.. /         \   1
            1.. :                        l.. /           |   l
             \.. :                       l.. |           |   l
              \.. `._                    l.. |           |   l
               l...   ""__               l..  \          /   l
               l.._.-""  ""--..______.--"=\..  `\_      /   /       "
              /....                     \  \.    ""===""   /   jgs
             l...                        l  "-._        _.'
   ""        \...                        l      `------'  "
              \....                      /
               "-._                  _-"              "          '
                   `--.___________.-'       "  '        "
   "                       "     '"
              '"                                  "
            "              '

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/bears%20(teddybears)
""", 
"""
    ___
  {~._.~}
   ( Y )
  ()~*~()                         
  (_)-(_)                         
  Rowan                           
  Crawford                        
------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/bears%20(teddybears)
""", 
"""
    (  )_(  )  
     ( O.O )
   __\  ~  /__
  (__       __)
     (   _  )
     (__) (__)
------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/bears%20(teddybears)
""", 
"""
    /\___/\ 
    | o o |
   __\_^_/__
  (__/   \__)
   _|  .  |_
  (__\___/__)
R. Elizabeth A.
------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/bears%20(teddybears)
""", 
"""
    _--_     _--_    _--_     _--_     _--_     _--_     _--_     _--_
   (    )~~~(    )  (    )~~~(    )   (    )~~~(    )   (    )~~~(    )
    \           /    \           /     \           /     \           /
     (  ' _ `  )      (  ' _ `  )       (  ' _ `  )       (  ' _ `  )
      \       /        \       /         \       /         \       /
    .__( `-' )          ( `-' )           ( `-' )        .__( `-' )  ___
   / !  `---' \      _--'`---_          .--`---'\       /   /`---'`-'   \ 
  /  \         !    /         \___     /        _>\    /   /          ._/   __
 !   /\        )   /   /       !  \   /  /-___-'   ) /'   /.-----\___/     /  )
 !   !_\       ). (   <        !__/ /'  (        _/  \___//          `----'   !
  \    \       ! \ \   \      /\    \___/`------' )       \            ______/
   \___/   )  /__/  \--/   \ /  \  ._    \      `<         `--_____----'
     \    /   !       `.    )-   \/  ) ___>-_     \   /-\    \    /
     /   !   /         !   !  `.    / /      `-_   `-/  /    !   !
    !   /__ /___       /  /__   \__/ (  \---__/ `-_    /     /  /__
    (______)____)     (______)        \__)         `-_/     (______)
Shawn Johnson

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/bears%20(teddybears)
""", 
"""
    ,^~~~-.         .-~~~"-.
   :  .--. \       /  .--.  \ 
   : (    .-`<^~~~-: :    )  :
   `. `-,~            ^- '  .'
     `-:                ,.-~
      .'                  `.
     ,'   @   @            |
     :    __               ;
  ...{   (__)          ,----.
 /   `.              ,' ,--. `.
|      `.,___   ,      :    : :
|     .'    ~~~~       \    / :
 \.. /               `. `--' .'
    |                  ~----~
    |                      |
robin chokie

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/bears%20(teddybears)
""", 
"""
                                    .-.*_,
           ."". ."".               {*(,\}/___           .-"-,
           |   '   |              `;)@\*|"   `",     _.'     \ 
            \     / ."". ."".      '((/;        | .-'         |
             '. .'  |   '   |       *;-.=-=-=._ .;-,          |
               '     \     /       __;____..---/' -,\        ;
            _,__      '. .'  .--';`_     __.-'`    _/       /
      ,-..-"    "-,     '   /      `;---'__0       \      .'
     /,- \.        \-.     |        /   (__)       \   _.'
     \_       -   -   \   _.-,_     {              |-'`
      /       0 __0 7_/  ({\*,;)     \,'-`-'      /'
     |/        (__)  \   /*(@-'})  ___",_ __ __,;`.--,
      |/             |`  \_,'-;}`.'    `'."".,---.._, )
       \       \/   /'_.-"/ _`)  |`----'`(  (=       /`-._
       .="-,_ __ _,'`    /   ',  \    =";`--'\ '=.  /|   ()()
     __`;.____...-'\.    |     | /`     / |\  '.  `  |  ()@()*
   /`               '    |  ,_/.=\    .;  | |   '.   /-' -##@()
  |    .--,          `y-'`\  ||   '--'/|  \ \    \`-`      ##)@()
  \   /   `)          \    '.||_,.--'/ /  /  )   |/       *`(\A/)()
   '. | ,-'            }     ||     { |.'.| /_.'./    .-.* { >*< }*)
     `\__/        _..._|     |/     {           |    (\A/) @(/V\)()@()
       /`--....--`  . `}            /{          \___{ >*< }()()##()()*{
      {             ;  }           {  \        /  ###(/V\)()@()(####\)
      {            ,  }            |   `--.. ,'   #########()()#####
       \           _,'             {        /     <><><><><><><><><>
        `,_    ,--'{                \       |        |
         }     {   }                 ;      \        /
    jgs  /     }   {                  \      |      /
      ,-`      }    `-._           _.-'`     {      `-.
    .'     _,-``,       `\       .'          }        .`\ 
    \(_(_.'      `-.__)_)/       `.-'   _.-'`'-._      \'
                                   `\"\"\"`         `\"\"\""`

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/bears%20(teddybears)
""", 
"""
        .-. _,,,,,_ .-.
       ( , ' :   : ' , )
        /    :   :    \ 
       ;    0.---.0    ;
        \  /   _   \  /
         \ |  (_)  | /
       ." `\  -'-  /` ".
      /     `\"\"\"""`     \ 
     /   .'   .-== '.    \ 
    /   /       .-=='\    \ 
   (   /              \    )
    '-;`.             .';-'
jgs  /_  `-.______ .-` __\ 
   /`  `\  /      `\  /   `\ 
   \    | /         \ |    /
    `'--'`           `'--'`

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/bears%20(teddybears)
""", 
"""
         __..._.-.
        /.-.   '-.)
        \',       \ 
         |       o'--D
         \      /    |
          ;._  _\ '-/
        .'    __ `\`.-"-. .-"-.
      .'    .'  '.|'     '     ',
     /      \     '._,          |
    ;        '-._     \         /
   (|           /'-.__/       .'
    \  __     ,'     '-.   .-'
     `/  `\.-'|         '.'
      |    |  '-.
      |    '-.   )
  jgs \       )-'
       '-----'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/bears%20(teddybears)
""", 
"""
           .-""-.                    _
          /  _   \              _   /|)
        .'---""-.|             /|) /|/
      .'          `.          /|/ /|/
   __/_             \    .   /|/ /|/
 .'    `-.          .8-. \\-/|/ /|/
J   .--.  Y     .o./ .o8\ |/\ `/_.-.
|  (    \       98P  888| /\ / ( ` |
|  `-._/          |   `"|/\ / \|\  F
 `.     .            "-'|\ / \/\  J
   |---'              _/\ / \// ` |
   J                 /// /   /   F
   _\    .'`-._    ./// /   /\\.'
  /  `. / .-'  `<-'/// /  _/\ \\ 
  F.--.\||       `.`/ /.-' )|\ \`.
  \__.-/)'         `.-'   ')/\\  /
 .-' .'/  \               ')  `-'
(  .'.'   '`.            .'
 \'.'    '   `.       .-'
  /     '      `.__.-'/|
 J     :          `._/ |
 |     :               |
 J     ;-\"\"\"-.         F
  \   /       \       /
   `.J         L   _.'
     F         |--' |
     J         |    |__
      L        |       `.
      |        |-.      \|
      |           \   )_.'
 VK   F        -.\ )-'
      \         )_)
       `\"\"\"\"\"\""'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/bears%20(teddybears)
""", 
"""
        (()__(()
        /       \ 
       ( /    \  \ 
        \ o o    /
        (_()_)__/ \ 
       / _,==.____ \ 
      (   |--|      )
      /\_.|__|'-.__/\_
     / (        /     \ 
     \  \      (      /
      )  '._____)    /
   (((____.--(((____/mrf

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/bears
""", 
"""
** bear **  10/96

     :"'._..---.._.'";
     `.             .'
     .'    ^   ^    `.
    :      a   a      :                 __....._
    :     _.-0-._     :---'""'"-....--'"        '.
     :  .'   :   `.  :                          `,`.
      `.: '--'--' :.'                             ; ;
       : `._`-'_.'                                ;.'
       `.   '"'                                   ;
        `.               '                        ;
         `.     `        :           `            ;
          .`.    ;       ;           :           ;
        .'    `-.'      ;            :          ;`.
    __.'      .'      .'              :        ;   `.
  .'      __.'      .'`--..__      _._.'      ;      ;
  `......'        .'         `'""'`.'        ;......-'
 jgs    `.......-'                 `........'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/bears
""", 
"""
@@ bear face @@  11/96

 .'"'.        ___,,,___        .'``.
: (\  `."'"```         ```"'"-'  /) ;
 :  \                         `./  .'
  `.                            :.'
    /        _         _        \ 
   |         0}       {0         |
   |         /         \         |
   |        /           \        |
   |       /             \       |
    \     |      .-.      |     /
     `.   | . . /   \ . . |   .'
 jgs   `-._\.'.(     ).'./_.-'
           `\'  `._.'  '/'
             `. --'-- .'
               `-...-'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/bears
""", 
"""
           .--.              .--.
          : (\ ". _......_ ." /) :
           '.    `        `    .'
            /'   _        _   `\ 
           /     0}      {0     \ 
          |       /      \       |
          |     /'        `\     |
           \   | .  .==.  . |   /
            '._ \.' \__/ './ _.'
       jgs  /  ``'._-''-_.'``  \ 
                    `--`

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/bears
""", 
"""
                                       .,;;;;;;;,.
                                     ,;;;;;;;,/;;;;
                    .,aa###########@a;;;;;/;;;,//;;;
           ..,,,.,aa##################@a;//;;;,//;;;
        ,;;;;;;;O#####OO##############OOO###a,/;;;;'
      .;;//,;;;O####OOO##########OOO####OOO#####a'
     .;;/,;;/;OO##OO#######################OOO####.
     ;;;/,;;//OO#######OOO###########OOO###########.
     `;;//,;,OOO#########OO#########OO##############.
   ;.  ``````OOO#####;;;;;;OO#####OO;;;;;;######O####.
  .;;,       OOO###O;;' ~`;##OOOOO##;' ~`;;O#####OO###
  ;;;;    ,  OOO##O;;;,.,;O#########O;,.,;;;O####OO###,
  `;;'   ,;; OOO##OO;;;;OOO(???????)OOO;;;;OO####OO###%,
    `\   ;;; `OOO#####OOOO##\?????/##OOOO#######O####%O@a
       \,`;'  `OOO####OOO######;######OOO###########%O###,
       .,\      `OO####OO"#####;#####"OO##########%oO###O#;
     ,;;;; \   .::::OO##OOOaaa###aaaOOO#######',;OO##OOO##;,
    .;;''    \:::.OOaa`###OO#######OO###'::aOO.:;;OO###OO;::.
    '       .::\.OO####O#::;;;;;;;;;;;;::O#O@OO.::::::::://::
           .:::.O\########O#O::;;;::O#OO#O###@OO.:;;;;;;;;//:,
          .:/;:.OO#\#########OO#OO#OO########@OO.:;;;;;;;;;//:
         .://;;.OO###\##########O#############@OO.:;;;;;;;;//:.
         ;//;;;;.O'//;;;;;;\##################@OO.:;;;;;;;;//:..
        ;//:;;;;:.//;;;;;;;;;#################@OO.:;;;;;;;;;//..
        ;;//:;;;:://;;;;;;;;;################@OO.:/;;;;;;;;;//..
        `;;;;;:::::::ooOOOoo#\############@OOO.;;//;;;;;;;;;//.o,
        .;,,,.OOOOO############\#######@OOO.;;;//;;;;;;;;;;//;.OO,
       //;;.oO##################@\OOO.;;;;;;;;;;;;;;;;;;;;//;.oO#O,
      //;;;;O##############@OOO=;;;;//;;;;;;;;;;;;;;;;;;;//;.oO##Oo
      //::;;O#########@OOOOO=;;;;;;;//;;;;;;;;;;;;;;;////;.oO####OO
  .n.n.n.n`;O########@OOOOO=;;;;;;;;;;///;;;;////////';oO########OO
 .%%%%%%%%%,;;########@=;;;;=;;;;///////////////':::::::::.a######@
 /%%%%%%%%%%.;;;;\"\"\""=:://:::::::::::::::::\::::::::::::://:.####@'
 /%%%%%%%%%//.;'     =:://:::::::::::::::::::\::::::::::://:.###@'
  /%%%%%%%%//'        =:://::::::::;:::::::::::\:::::::://:.##@'
   /%%%%%%/             =:://:::;;:::::::::::::::\::::::::'
     ''''                 ''''''   ''''''''''''''''\''''
                                                     \  Susie Oviatt

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/bears
""", 
"""
-=[ lazy bears ]=-  9/97

   _,-""`""-~`)
(`~_,=========\ 
 |---,___.-.__,\ 
 |        o     \ ___  _,,,,_     _.--.
  \      `^`    /`_.-"~      `~-;`     \ 
   \_      _  .'                 `,     |
     |`-                           \'__/
    /                      ,_       \  `'-.
   /    .-""~~--.            `"-,   ;_    /
  |              \               \  | `""`
   \__.--'`"-.   /_               |'
              `"`  `~~~---..,     |
 jgs                         \ _.-'`-.
                              \       \ 
                               '.     /
                                 `"~"`

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/bears
""", 
"""
                              _,add8ba,
                            ,d888888888b,
                           d8888888888888b                        _,ad8ba,_
                          d888888888888888)                     ,d888888888b,
                          I8888888888888888 _________          ,8888888888888b
                __________`Y88888888888888P\"\"\"\"\"\"\"\"\"""baaa,__ ,888888888888888,
            ,adP\"\"\"\"\"\"\"\"\"""9888888888P""^                 ^""Y8888888888888888I
         ,a8"^           ,d888P"888P^                           ^"Y8888888888P'
       ,a8^            ,d8888'                                     ^Y8888888P'
      a88'           ,d8888P'                                        I88P"^
    ,d88'           d88888P'                                          "b,
   ,d88'           d888888'                                            `b,
  ,d88'           d888888I                                              `b,
  d88I           ,8888888'            ___                                `b,
 ,888'           d8888888          ,d88888b,              ____            `b,
 d888           ,8888888I         d88888888b,           ,d8888b,           `b
,8888           I8888888I        d8888888888I          ,88888888b           8,
I8888           88888888b       d88888888888'          8888888888b          8I
d8886           888888888       Y888888888P'           Y8888888888,        ,8b
88888b          I88888888b      `Y8888888^             `Y888888888I        d88,
Y88888b         `888888888b,      `\"\"\""^                `Y8888888P'       d888I
`888888b         88888888888b,                           `Y8888P^        d88888
 Y888888b       ,8888888888888ba,_          _______        `""^        ,d888888
 I8888888b,    ,888888888888888888ba,_     d88888888b               ,ad8888888I
 `888888888b,  I8888888888888888888888b,    ^"Y888P"^      ____.,ad88888888888I
  88888888888b,`888888888888888888888888b,     ""      ad888888888888888888888'
  8888888888888698888888888888888888888888b_,ad88ba,_,d88888888888888888888888
  88888888888888888888888888888888888888888b,`\"\"\"^ d8888888888888888888888888I
  8888888888888888888888888888888888888888888baaad888888888888888888888888888'
  Y8888888888888888888888888888888888888888888888888888888888888888888888888P
  I888888888888888888888888888888888888888888888P^  ^Y8888888888888888888888'
  `Y88888888888888888P88888888888888888888888888'     ^88888888888888888888I
   `Y8888888888888888 `8888888888888888888888888       8888888888888888888P'
    `Y888888888888888  `888888888888888888888888,     ,888888888888888888P'
     `Y88888888888888b  `88888888888888888888888I     I888888888888888888'
       "Y8888888888888b  `8888888888888888888888I     I88888888888888888'
         "Y88888888888P   `888888888888888888888b     d8888888888888888'
            ^\"\"\"\"\"\"""^     `Y88888888888888888888,    888888888888888P'
                  Normand    "8888888888888888888b,   Y888888888888P^
                  Veilleux    `Y888888888888888888b   `Y8888888P"^
                                "Y8888888888888888P     `\"\"\""^
                                  `"YY88888888888P'
                                       ^\"\"\"\"\"\"""'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/bears
""", 
"""
                   |    :|
                   |     |
                   |    .|
               ____|    .|
             .' .  ).   ,'
           .' c   '7 ) (
       _.-"       |.'   `.
     .'           "8E   :|
     |          _}""    :|
     |         (   |     |
    .'         )   |    :|
.odCG8o_.---.__8E  |    .|
`Y8MMP""       ""  `-...-'   cgmm

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/beavers
""", 
"""
              n__n_
             /  = =\ 
            /   ._Y_)
___________/      "\________________________________
          (_/  (_,  \                        o!O
            \      ( \_,--\"\"\""--.
      __..-,-`.___,-` )-.______.'
    <'     `-,'   `-, )-'    >
     `----._/      ( /"`>.--"
            "--..___,--"

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/beavers
""", 
"""
             ___
           .="   "=._.---.
         ."         c ' Y'`p
        /   ,       `.  w_/
    jgs |   '-.   /     /
  _,..._|      )_-\ \_=.\ 
 `-....-'`------)))`=-'"`'"

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/beavers
""", 
"""
-=[ bird in tree ]=-  12/96
              _
             ('>
             /))@@@@@.
            /@"@@@@@()@
           .@@()@@()@@@@
           @@@O@@@@()@@@
           @()@@\@@@()@@
            @()@||@@@@@'
             '@@||@@@'
          jgs   ||
         ^^^^^^^^^^^^^^^^^

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
-=[ more birds ]=-  12/96
             _      _
            <')_,/ <') ,/
            (_==/  (_==/
      jgs    ='-    ='-

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
** a little bird **  10/96
		  ___
		 (  ">
		  )(
		 // )
  jgs --//""--
	  -/------

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
* toucan *  11/96
                                 `| |
                    .-"-.__       | .'
                   /  ,-|  ```'-, || . `
                  /  /@)|_       `-,  |
                 /  ( ~ \_```""--.,_',  :
              _.'    \   /```''''""`^
             /        | /        `|   :
            /         \/          | |   .
           /      __/  |          |. |
          |     __/  / |          |     |
"-._      |    _/ _/=_//          ||  :
'.  `~~`~^|   /=/-_/_/`~~`~~~`~~`~^~`.
  `> ' .   \  ~/_/_ /"   `  .  ` ' .   |
 .' ,'~^~`^|   |~^`^~~`~~~^~~~^~`;       '
 .-'       | | |                  \ ` : `
           |  :|                  | : |
      jgs  |:  |                  ||    '
           | |/                   |  |   :
           |_/                    | .  '

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
              __.------.
           .-' .---.    \ 
         .'  .' O   )/"\/
       .'    )     >:'  L
   .'"/      (    _J:   |
  /  ''      \   / `\   F
 J  '         L_(   _> J
 |  ( (         `--' |/
J /  : :.      :  J
| |   :. :. :. : .:L
| \   .     .  .:'|F
| |       `:. .: ||
F ||         '  |||
| :)       : .  JJ
|) |            /F
 V A           /J
 || \_.-.   .-.FF
---'--. /<--\\ L----.
      |||L   \||     |
      JJ))   `||     |
      )|___.---\----'
.--'""<'|/ |F
    |J`-'  FF
    | L : JJ
    | J  :||
    J | | ||
    J |_/\_F
    J |  |J
     L L ||
     | | |F
VK   | | |F

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
             _____
      ,----/,--.   `.
     /    '. `-'     \ 
     | ____ \      '`|_
     \'.--._/` _     \ '.
          /'-|/ \|`\|-`  \ 
         /   /       \   |
         |  ;    '`  |  .'
         '. |;;      ;  /
          \ \ ;     / ,'
           ;--,   .,--,
      mx__||=|=|./|=|=||___
          `'-'-'  `-'-'`
  ___________________________
          /'/ /  \  \ \ 
         / '.';  ; \ ' \ 
        '-/   | ; | ; \-'
          \_| |   | |_/
            `-'\_/`-'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
** owl-2 **  10/96
        ,___,
        (6v6)
        (_^(_\ 
   jgs^^^"^" \\^^^^
      ^^^^^^^^^^^^^

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
			 ____                                ____
	  ,----.' ,--.`.                       ___.-' ,--.`.
	 / ___'. (O     \                    .'.---. (O     \ 
	 \(`--._\ ```   |                    \(`--._\ ```   |
	  `    /` _     \_                    `    /` _     \_
		 /'-|/ \|`\|-`'.                     /'-|/ \|`\|-`'.
		/   /       \   \                   /   /       \   \ 
		|  /.   '`  :  .'                   |  /.   '`  :  .'
		'. |;;      ;  /                    '. |;;      ;  /
		 \ \ ;     / ,'                      \ \ ;     / ,'
		  ;--,   .,--,                        ;--,   .,--,
	 mx__||=|=|./|=|=||___               mx__||=|=|./|=|=||___
		 `'-'-'  `-'-'`                      `'-'-'  `-'-'`
 ___________________________         ___________________________
		 /'/ /  \  \ \                       /'/ /  \  \ \ 
		/ '.';  ; \ ' \                     / '.';  ; \ ' \ 
	   '-/   | ; | ; \-'                   '-/   | ; | ; \-'
		 \_| |   | |_/                       \_| |   | |_/
		   `-'\_/`-'                           `-'\_/`-'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
             _____
          _/       `.
       ,'' . O       \ 
      / ,-. \      '`|_
      |/--._/` _     \ '.
      '   /'-|/ \|`\|-`  \ 
         /   /       \   |
         |  ;    '`  |  .'
         '. |;;      ;  /
          \ \ ;     / ,'
           ;--,   .,--,
      mx__||=|=|./|=|=||___
          `'-'-'  `-'-'`
  ___________________________
              | |  |
              | |  | [TM]
              | |  |
              + |  |
              \|\  /
               | ||
               | ||
               | ||
               | ||
               | ||
               \ \/
                ||
                 |
                 |

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
            ,---,_
         ,'" -o.  `.
        (,----      `.
             \        \ 
             ;      __ --._
           ," \` \`-`,--._ `.
          /     ` ` /        `.
         : (       (           \ 
         :  \       \           \ 
          \  \       \           \ 
           \  \     , \.          ;
            \  \   :   `:.        |
             `. \  :    `::.     ,|
  -hrr-        ` \  \     \ `---'  \ 
                  :-|\  __ `. `.`.  \ 
                  | | `| \"" `       \ 
    __,------- ,--; |,-' |\_.__\      \ 
  -"          (  / (  /- |__    `. `-.'
  ----\"\"\"\"\"\"`----.__`_`     `-._  `-'
                      `--.__    `-.
                            `-.    `.
                               `.

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
            ___
         ,-'   >---.        ,---.
        /  ,o)'     `.     /     `.
       '|    (   ,_   )   |        `.
     ,--|    -.,'  `./    ;        `.
    /   |      `.         :   .      `
   /    |:.      `-       ,    \    :.\ 
  |   ,-|'        \-.___,'     :\   ;::\ 
  |, ::'\   ,      `.        ,.::\   :(-
  |: |:; \,'\  ).   / .:..  ,:::::\   `\ 
  |  |,:  `  `/  `-/ ::::::::::::::\    ;
  |   |:             ::::::::::::::.\   |
  \   |:.,           ::::::::::   ` |;  |
   \  `.:'       ::.,::::::: `:  \  ||  |
    \   \     . ,:::::::,:::  . ( `-'|  |
     `.  \     ::::,`':(::' ` |\ \   :  |
       \  :-:. `::      \ `   | \ \   \ |
        `'  |:' `'  /`.  `. \ :  `'    \|
 -hrr-     /   \    \ `._/ `'`-`        |
       __ / \, ,\   _\\  `.
     _/ ,\- (`'  `-',-','-,"-.
    /,-(,- \_\     (-'(,---.:.)
    `   `    '      `  `    '

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
     .-.
    /'v'\ 
   (/   \)
  ='="="===<
  mrf|_|

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
   ,_
  >' )
  ( ( \ 
mrf''|\ 

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
                             /T /I
                              / |/ | .-~/
                          T\ Y  I  |/  /  _
         /T               | \I  |  I  Y.-~/
        I l   /I       T\ |  |  l  |  T  /
     T\ |  \ Y l  /T   | \I  l   \ `  l Y
 __  | \l   \l  \I l __l  l   \   `  _. |
 \ ~-l  `\   `\  \  \\ ~\  \   `. .-~   |
  \   ~-. "-.  `  \  ^._ ^. "-.  /  \   |
.--~-._  ~-  `  _  ~-_.-"-." ._ /._ ." ./
 >--.  ~-.   ._  ~>-"    "\\   7   7   ]
^.___~"--._    ~-{  .-~ .  `\ Y . /    |
 <__ ~"-.  ~       /_/   \   \I  Y   : |
   ^-.__           ~(_/   \   >._:   | l______
       ^--.,___.-~"  /_/   !  `-.~"--l_ /     ~"-.
              (_/ .  ~(   /'     "~"--,Y   -=b-. _)
               (_/ .  \  :           / l      c"~o \ 
                \ /    `.    .     .^   \_.-~"~--.  )
                 (_/ .   `  /     /       !       )/
                  / / _.   '.   .':      /        '
                  ~(_/ .   /    _  `  .-<_
                    /_/ . ' .-~" `.  / \  \          ,z=.
                    ~( /   '  :   | K   "-.~-.______//
                      "-,.    l   I/ \_    __{--->._(==.
                       //(     \  <    ~"~"     //
                      /' /\     \  \     ,v=.  ((
                    .^. / /\     "  }__ //===-  `
                   / / ' '  "-.,__ {---(==-       -Row
                 .^ '       :  T  ~"   ll
                / .  .  . : | :!        \\ 
               (_/  /   | | j-"          ~^
                 ~-<_(_.^-~"

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
                                 .ze$$e.
              .ed$$$eee..      .$$$$$$$P""
           z$$$$$$$$$$$$$$$$$ee$$$$$$"
        .d$$$$$$$$$$$$$$$$$$$$$$$$$"
      .$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$e..
    .$$****\"\"\""***$$$$$$$$$$$$$$$$$$$$$$$$$$$be.
                     ""**$$$$$$$$$$$$$$$$$$$$$$$L
                       z$$$$$$$$$$$$$$$$$$$$$$$$$
                     .$$$$$$$$P**$$$$$$$$$$$$$$$$
                    d$$$$$$$"              4$$$$$
                  z$$$$$$$$$                $$$P"
                 d$$$$$$$$$F                $P"
                 $$$$$$$$$$F
                  *$$$$$$$$"
                    "***""  Gilo94'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
-=[ chickens ]=-  12/96

        (\  }\   (\  }\   (\  }\ 
       (  \_('> (  \_('> (  \_('>
       (__(=_)  (__(=_)  (__(=_)
     jgs  -"=      -"=      -"=

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
                  _          _
                 ('<        >')
                \(_)________( \ 
                 (___________)\\ 
                    (     )     \ 
                     |   |
                     |   |
                     |   |
                    _|   |_
                   (_______)lc

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
-------|-------------------------------------------------|---------
    ___|___                                           ___|___
   ////////\   _                                 _   /\\\\\\\\ 
  ////////  \ ('<                               >') /  \\\\\\\\ 
  | (_)  |  | (^)                               (^) |  | (_)  |
  |______|.===="==                             =="====.|______|
---------------------------------------------------------------ldb--

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
               ,\--/,                       ,-,__
        ------{ @  @ }-------------------,-,| |_/|
    ----------|  \/  |-------------------| |`-/  |
              | )  ( |                ,-,`-'_/ _/
--------------`W-mm-W'----------------| | _/  /
                \  /                 /`-'/  _/|
                 WW                 /___/  /  |
                                    |   | /|  |
                                    |___|/ |  |
                                       |   |  |
              -Ed Savage-              |   |  |
                                       |   |  |
                                       |   |  |
                                       |   |  |

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
         V
       (o o)
      (  V  )
 .......m.m........
   Daniel Schoo

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
     | |  *tock*
     | |     *tock*
     | <-*)
     | |(()
     | |"/
     | |'
                PhS

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
                 _.----._
               ,'.::.--..:._
              /::/_,-<o)::;_`-._
             ::::::::`-';'`,--`-`
             ;::;'|::::,','
           ,'::/  ;:::/, :.
          /,':/  /::;' \ ':\ 
         :'.:: ,-''   . `.::\ 
         \.:;':.    `    :: .:
         (;' ;;;       .::' :|
          \,:;;      \ `::.\.\ 
          `);'        '::'  `:
           \.  `        `'  .:      _,'
            `.: ..  -. ' :. :/  _.-' _.-
              >;._.:._.;,-=_(.-'  __ `._
            ,;'  _..-((((''  .,-''  `-._
         _,'<.-''  _..``'.'`-'`.        `
     _.-((((_..--''       \ \ `.`.
   -'  _.``'               \      ` SSt
     ,'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
  |\_____/|
  |[o] [o]|   Jean
  |   V   |  Pajerek
  |       |
 -ooo---ooo-

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
 ^ ^
(O,O)
(   )
-"-"---dwb-

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
 ,_,
(.,.)
(   )
-"-"---dwb-

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
             .
           ,' '.
   How __ -.   .- __ to
  many \`\-|___|-/'/ the
 licks /  ,-.  ,-. \ center
 does ,--(  .)(.  )-- of
   it {   `-'<\`-'  ) a
 take {    _~</     ) Toosie
    to V  (_)    ,  \ Roll
  get /  /_|     \  / Pop?
     (_____3      WW
        \_________/
        __| | | |__
-------'WW--'-`--WW'-dwb----

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
                                             _______
                                         _.-'       ''...._
                                       .'        .--.    '.`
                                      : .--.    :    :     '-.
                                     : :    :   :    :       :`
                                     : :  @ :___:  @ : __     '`.
                                 __..:---''''   `----''  `.   .'"
                         __..--''                   ___j  :   :
                 __..--''    .--'             __..''      :    `.
           ..--''                     __..--''        __..'   /``
         .'                   __..--''        __..--''       /
        :             __..--''        __..--''               \ 
       :        _.--''        __..--''    :                :`.:
      :     _.-'      __..--''             :              /
      :   .'  __..--''                      \            /
      \  :--''                               \          .'
       \ :                   [WILU]           :         :
        \:                                     :        \ 
         '                                     :         \ 

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
 __
( o>
///\ 
\V_/_

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
 __
( o>
///\ 
\V_/_

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
      _..         .-"--._                _.--"-.
  _.-7  |        /       \              /_,     \ 
 < ` '  |       ;      O_o             _oO_      ;
  \     |       |    .'`  `'.        .'    `.    |                _
   \    :        \  L `-._   `.    .'   _.-' J  /              .'` f_
    \   '.        |  `.  \`'-._\  /_.-'7__.-'  |             ,'      \ 
     ;    `.      ;  | `. \                 |  ;      _.._ ,/       _|
     | ,-.  `-._,/    ;  `-'               ;    \,_.-'  .-,        __j
     ; |  `._.         ;                  ;          .-'   ) ,.--'`
    |  .-'             ;                  ;              _'  |
    ;  \     _.'   .~  |                  |              _)  ;
     \   '-'`    /    /                    \        '-._)   /
      '.           _,'          \|./|       `,_           .`
 |\.|/  `-..___..-'`           .-"' `  \\,|_. '`-..___..-'   \|./|
 ' `"-.   ||   ||                         `      || ||      ' `"-._
          ;|   ||____                        ____|| |;  `
    mx  __| ,__=,--._\ |/,_'     _\ |/  ,|/ /_.--,r_ |__
       '"|/`"'-._\\|''``           \|_/-'   ''"`/_."'\"-`
         `       `'   |\.|/                    ''     '  \|  _
                      ' `"-._                           _."-'
              "I got up at 5:30 once and caught
            a worm -  it wasn't worth it, believe me."

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
      _..         .-"--._                _.--"-.
  _.-7  |        /       \              /_,     \ 
 < ` '  |       ;      O_o             _oO_      ;
  \     |       |    .'`  `'.        .'    `.    |                _
   \    :        \  L `-._   `.    .'   _.-' J  /              .'` f_
    \   '.        |  `.  \`'-._\  /_.-'7__.-'  |             ,'      \ 
     ;    `.      ;  | `. \                 |  ;      _.._ ,/       _|
     | ,-.  `-._,/    ;  `-'               ;    \,_.-'  .-,        __j
     ; |  `._.         ;                  ;          .-'   ) ,.--'`
    |  .-'             ;                  ;              _'  |
    ;  \     _.'   .~  |                  |              _)  ;
     \   '-'`    /    /                    \        '-._)   /
      '.           _,'          \|./|       `,_           .`
 |\.|/  `-..___..-'`           .-"' `  \\,|_. '`-..___..-'   \|./|
 ' `"-.   ||   ||                         `      || ||      ' `"-._
          ;|   ||____                        ____|| |;  `
    mx  __| ,__=,--._\ |/,_'     _\ |/  ,|/ /_.--,r_ |__
       '"|/`"'-._\\|''``           \|_/-'   ''"`/_."'\"-`
         `       `'   |\.|/                    ''     '  \|  _
                      ' `"-._                           _."-'
              "I got up at 5:30 once and caught
            a worm -  it wasn't worth it, believe me."

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
                                .---'''''''--.
                              .'        _    _\ 
                             :         (o)__(o)______
                             |           / ~~        `.
                              \         /______________\ 
                               `.__     \_______________\ 
                                 __)          (___
                               .'/( ( ( ( ) ) ) )\`.
           .---.              / / (_( (_( )_) )_) \ \ 
          /   @_@___         / /( ( ( ( ( ) ) ) ) )\ \ 
          \_  (_____\       / / (_( (_( (_) )_) )_) \ \ 
          //UUU\\           | | ( ( ( ( ( ) ) ) ) ) | |
         //UUUUU\\          | | ( (_( (_( )_) )_) ) | |
         ||UUUUU||          / / ( ( ( ( ( ) ) ) ) ) \ \ 
         ((UUUUU))          \_\ (_(_(_(_(_)_)_)_)_)_/_/
    ======ooo=ooo==============()=()=()=====()=()=()===============
            |||                       ( (_) )
            |||                       (_( )_)
                     dp               ( (_) )
                                      (_( )_)
                                      (_(_)_)
                                        (_)

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
                             __
                          .'`  `.      __
                         /      |  ,-'`  `'.
                        ;       '-'         )
                        |              _,.-'
                    _   |_.--.,       (_
                 .'` `'-'__    \        ''"'-.
                /  .-"-/`  `\   ;_            \ 
                | /   ;      ;  | `.   (`'.__.'
                 |   o| o    | __   \   `.
           _,.---'\___.\.__.'    `'. |_   )
       _.-'               _.-""-.   '-.'-'
     ,'                     |   \`.    `.
    /                       ;   |       |
   (_.-'""''---..           /   |      /
                 `'-..___.-'    ;  ,.-'
                       \ 7      ' / |
                       |/_  _  ; /  '
                   .-  /' /` j/ '   |
                   | \|  '   /  |
                   '  `.___.'  ;     '
                   ;          /      |
                    \        /       |
                     `.,__,.'         '
                        |             |
                        ;              '
                       /                |mx
                      ' ___________ ...-'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(land)
""", 
"""
              ___
          _..':::\ 
         /::::::::\ 
        /::::::::::\ 
       /::::::::::::\ ___
      (:.--.)\/(,.--.:::::;.
      ,',-. \   / ,-.`.:::::)
     ( /   \     /   \ ):::/%\ 
      || .d|     |b. ||:::'|%%\ 
     _|| 88|     |88 ||_   |%%%\ 
    /. \ 88|.---.|88 / ,\  |%%^%\ 
    `.\ `--"     "--' /,'  |%   %)
      `>  _________<'
    ,-' ,---.---.---. `-.
    `--'\    \j/    /`--'
       `.\         /,'
         \\_______//
          `-------'       hjw

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(water)
""", 
"""
-=[ ducks ]=-  12/96
       _          _          _          _          _
     >(')____,  >(')____,  >(')____,  >(')____,  >(') ___,
       (` =~~/    (` =~~/    (` =~~/    (` =~~/    (` =~~/
 jgs~^~^`---'~^~^~^`---'~^~^~^`---'~^~^~^`---'~^~^~^`---'~^~^~

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(water)
""", 
"""
                                 .....
                            .e$$$$$$$$$$$$$$e.
                          z$$ ^$$$$$$$$$$$$$$$$$.
                        .$$$* J$$$$$$$$$$$$$$$$$$$e
                       .$"  .$$$$$$$$$$$$$$$$$$$$$$*-
                      .$  $$$$$$$$$$$$$$$$***$$  .ee"
         z**$$        $$r ^**$$$$$$$$$*" .e$$$$$$*"
        " -\e$$      4$$$$.         .ze$$$\"\"\""
       4 z$$$$$      $$$$$$$$$$$$$$$$$$$$"
       $$$$$$$$     .$$$$$$$$$$$**$$$$*"
     z$$"    $$     $$$$P*""     J$*$$c
    $$"      $$F   .$$$          $$ ^$$
   $$        *$$c.z$$$          $$   $$
  $P          $$$$$$$          4$F   4$
 dP            *$$$"           $$    '$r
.$                            J$"     $"
$                             $P     4$
F                            $$      4$
                            4$%      4$
                            $$       4$
                           d$"       $$
                           $P        $$
                          $$         $$
                         4$%         $$
                         $$          $$
                        d$           $$
                        $F           "3
                 r=4e="  ...  ..rf   .  ""% Gilo94'
                $**$*"^""=..^4*=4=^""  ^\"\"\"

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(water)
""", 
"""
-=[ egret ]=-  12/96
          _,
     -==<' `\ 
         ) /
        / (_.
       | ,-,`\ 
        \\  \ \ 
         `\, \ \ 
          ||\ \`|,
   jgs   _|| `=`-'
        ~~`~`

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/birds%20(water)
""", 
"""
                    ________
                  c' e    -`-
               _   )    ___ ~'
             .|*|  |   `|
             '|+|  |    |
            _||*|_ |    |
           //`_,__\|    '
          //_/  ' \|    |
         ///  _    |    |
        /,|  /     \\   |
        |/          \\_//
         |           \+/
         |   '      ,/|
          \_/   ,__   )
           )\   |)   /
          (  \  ||  /
           ) ') |/ /
           # |\ ' /
             )(- -)\ 
            // \'( \\ 
          _//  | |  \\_
   b'ger //(  _)^(_  )\\  . ..
   ..   '^-  /`( )'\  -^'
            '^-' '-^' .. .

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/camels
""", 
"""
                     ,,__
           ..  ..   / o._)                   .---.
          /--'/--\  \-'||        .----.    .'     '.
         /        \_/ / |      .'      '..'         '-.
       .'\  \__\  __.'.'     .'          ì-._
         )\ |  )\ |      _.'
        // \\ // \\ 
       ||_  \\|_  \\_
   mrf '--' '--'' '--'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/camels
""", 
"""
            .               ,.
           T."-._..---.._,-"/|
           l|"-.  _.v._   (" |
           [l /.'_ \; _~"-.`-t
           Y " _(o} _{o)._ ^.|
           j  T  ,-<v>-.  T  ]
           \  l ( /-^-\ ) !  !
            \. \.  "~"  ./  /c-..,__
              ^r- .._ .- .-"  `- .  ~"--.
               > \.                      \ 
               ]   ^.                     \ 
               3  .  ">            .       Y  -Row
  ,.__.--._   _j   \ ~   .         ;       |
 (    ~"-._~"^._\   ^.    ^._      I     . l
  "-._ ___ ~"-,_7    .Z-._   7"   Y      ;  \        _
     /"   "~-(r r  _/_--._~-/    /      /,.--^-._   / Y
     "-._    '"~~~>-._~]>--^---./____,.^~        ^.^  !
         ~--._    '   Y---.                        \./
              ~~--._  l_   )                        \ 
                    ~-._~~~---._,____..---           \ 
                        ~----"~       \ 
                                       \ 

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/cats
""", 
"""
         /\_/\ 
    ____/ o o \ 
  /~____  =ø= /
 (______)__m_m)

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/cats
""", 
"""
    ("`-''-/").___..--''"`-._
     `6_ 6  )   `-.  (     ).`-.__.`)
     (_Y_.)'  ._   )  `._ `. ``-..-'
   _..`--'_..-_/  /--'_.' ,'
  (il),-''  (li),'  ((!.-'    Felix Lee <flee@cse.psu.edu>

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/cats
""", 
"""
     ("`-/")_.-'"``-._
      . . `; -._    )-;-,_`)
     (v_,)'  _  )`-.\  ``-'
    _.- _..-_/ / ((.'
  ((,.-'   ((,/    Felix Lee <flee@cse.psu.edu>

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/cats
""", 
"""
~ another little cat ~  9/96
     .       .
     \`-"'"-'/
      } 6 6 {
     =.  Y  ,=
       /^^^\  .
      /     \  )
 jgs (  )-(  )/
      ""   ""

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/cats
""", 
"""
* sleeping cat
 aka "Chessie" of the Chesapeake and Ohio Railroad *  11/96
                   ,
                  /|
             ___,/'\ 
         ,-"`    ~ `;
        .`\  /     `\.
      ,/_ _ |\       `\   ,--,__,-"
,_,-'"`   \`\ `- ,     \ /     /   _/
  `"~-\    \    /  .-' |/         /
       `\ __, .-; '.-' /
         `\_. `-'__, _/   _/
           `\`  /`__/    /
          _,-`--'/
       .-"     _/   /    /
      /   _,-"`/  /'    /
      \__/ jgs

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/cats
""", 
"""
                                       /;    ;\ 
                                   __  \\____//
                                  /{_\_/   `'\____
                                  \___   (o)  (o  }
       _____________________________/          :--'   DRINKA
   ,-,'`@@@@@@@@       @@@@@@         \_    `__\ 
  ;:(  @@@@@@@@@        @@@             \___(o'o)
  :: )  @@@@          @@@@@@        ,'@@(  `===='        PINTA
  :: : @@@@@:          @@@@         `@@@:
  :: \  @@@@@:       @@@@@@@)    (  '@@@'
  ;; /\      /`,    @@@@@@@@@\   :@@@@@)                   MILKA
  ::/  )    {_----------------:  :~`,~~;
 ;;'`; :   )                  :  / `; ;
;;;; : :   ;                  :  ;  ; :                        DAY !!!
`'`' / :  :                   :  :  : :
    )_ \__;      ";"          :_ ;  \_\       `,','
    :__\  \    * `,'*         \  \  :  \   *  8`;'*  *
        `^'     \ :/           `^'  `-^-'   \v/ :  \/   -Bill Ames-

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/cows
""", 
"""
* cow *  11/96
             .=     ,        =.
     _  _   /'/    )\,/,/(_   \ \ 
      `//-.|  (  ,\\)\//\)\/_  ) |
      //___\   `\\\/\\/\/\\///'  /
   ,-"~`-._ `"--'_   `\"\"\"`  _ \`'"~-,_
   \       `-.  '_`.      .'_` \ ,-"~`/
    `.__.-'`/   (-\        /-) |-.__,'
      ||   |     \O)  /^\ (O/  |
      `\\  |         /   `\    /
        \\  \       /      `\ /
         `\\ `-.  /' .---.--.\ 
           `\\/`~(, '()      ('
            /(O) \\   _,.-.,_)
           //  \\ `\'`      /
     jgs  / |  ||   `\"\"\""~"`
        /'  |__||
              `o

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/cows
""", 
"""
      db         db
    d88           88
   888            888
  d88             888b
  888             d88P
  Y888b  /``````\8888
,----Y888        Y88P`````\ 
|        ,'`\_/``\ |,,    |
 \,,,,-| | o | o / |  ```'
       |  \"\"\" \"\"\"  |
      /             \ 
     |               \ 
     |  ,,,,----'''```|
     |``   @    @     |
      \,,    ___    ,,/
         \__|   |__/
            | | |
            \_|_/

     _
 \\ |_|  _   _  _  _  _  | //
    |   (_\ |  |  |  |_| o
                     |

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/cows
""", 
"""
 ,_)/
   (-'
 .-'\ 
  "'\'\"\"\"""'),
     )/---,(
PjP / \  / |      , '     , '   , '   ,'   ,'    ,'   ;     ;

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/deer
""", 
"""
                      .          ..
                      . .       .. .
                      . ..     ... .
                       . ..    .. .
                       .  ......  .
                        . ...... .
                         ........
                         ........
                         .... 0..
                        .........
                       ........ .
       .              @...)  ....
       ..                    ....
       ...                .......
        ........................
         .......................
         .......................
        ........................
       ........      .....  .....
      .......      .....    .....
     ...  ...     ....       ....
    ...    ...   ...           ...
   ...       ......             ...
   ...        .:..                ...
   ...        ...:..                ...
    ...      ...   ..                 ..
      ..    ..                             gfj/ejm

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/deer
""", 
"""
                          _______
                  ,--,,--'       '-------,_
                 (        ---              ',
                 .'          '-     ,__  ,_)
                (      "          _     __)
                 '--`"----.~.-`--` `---`
                         / /   \   \   \ 
        |/  |           / /  \ \ \ \ \    \ 
       \I  \/          / /  \     \  \ \ 
         \_/           //       \  \  \ 
      ,_@@ ,>         //    \  \  \  \ \ \ \ 
      (___ \__        //              \ 
        ./\   \____   //       \  \    \  \ 
          /|  ---"-' //                   \    \ 
         // \    )\  / -                    \ 
        /|   \ _ \- ' -__
        ~    // \ | \ 
            //   \\ 
           //     \\ 
 snd      '-'     '-'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/deer
""", 
"""
                         \ )
    ) (            \ /   ~V~          \ /
    ~V~            ~V~    )           ~V~
     )              ) >-~-<            )
>-~-<          >-~-<  \  /~       >-~-<
\,,,,\,,,,,,,,,\, /~,,,,,,,,,,,,,/,,,/~,,,,,,,

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/deer
""", 
"""
                         \ )
    ) (            \ /   ~V~          \ /
    ~V~            ~V~    )           ~V~
     )              ) >-~-<            )
>-~-<          >-~-<  \  /~       >-~-<
\,,,,\,,,,,,,,,\, /~,,,,,,,,,,,,,/,,,/~,,,,,,,

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/deer
""", 
"""
                           ;
         ;               ~~`~~      ;
        ~`~             ~~`~~`~    `~`
       ~~`~~           `~~~`~~~~  `~`~`   ,
      ~~`~~`~           ~`~~~`~   `~`~`"_/O\""\ 
    ~`~~`~~`~~~        ~~~`~~~`~   ~|`~_ |[|##|
     `~~`~~~`~          ~~~|~~~`      '_--...__
      ~`~|~\_~\_   __/¯¯)  |     _- _-  _       _
         |   |/     .'( )  |              _- _-  _
         |  / -\   __`/\ \ |_- _- ¯_  -
      _____/ /--'(^,__ /\ \     //\       _
    /'       \      | |  \ \    ||\\_- _-  _
     \....( /       ;;;___;;;  /||~~`~~
      ||   \\          | |   _/ ||~~~`~~~ -
      \\    \\         |=|  /_( ||~~`~~~`      _
       \\_   \\_    , (__|    _  ~~~~`~~~_- _-  _
   _- _-  _   -   <`_\ __; _-  _  ~~~`~~
    _   -    _   -  (_ __)     _    ~~;~~     -_
       _- _-  _    < / < \  _-  _    -     _-   _ TS

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/deer
""", 
"""
                                ,._
                       ,--.    |   `-.
                    ,-'    \   :      `-.
                   /__,.    \  ;  `--.___)
                  ,'    \    \/   /       ,-"`.
                     __,-' - /   '\      '   ,'
                  ,-'              `-._ ,---^.
                  \   ,                `-|    |
                   \,(o                  ;    |
               _,-'   `-'                |    |
            ,-'                          |    |
        Y8PYF                            ;    ;
        `"" `           ,         ,--   /    :
         \      .   ___/|       ,'\   ,' ,'  ;
          `.     ;-' ___|     ,'  |\   ,'   /
            `---'  __\ /    ,'    | `-'   ,'
      ,-           \ ,'   ,'      `--.__,'
    ,'     ,-'     ,'    /
         ,'  ,     `----'    -hrr-
           ,'
          (
           `

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/dogs
""", 
"""
         ,--._______,-.
       ,','  ,    .  ,_`-.
      / /  ,' , _` ``. |  )       `-..
     (,';'""`/ '"`-._ ` \/ ______    \\ 
       : ,o.-`- ,o.  )\` -'      `---.))
       : , d8b ^-.   '|   `.      `    `.
       |/ __:_     `. |  ,  `       `    \ 
       | ( ,-.`-.    ;'  ;   `       :    ;
       | |  ,   `.      /     ;      :    \ 
       ;-'`:::._,`.__),'             :     ;
      / ,  `-   `--                  ;     |
     /  \                   `       ,      |
    (    `     :              :    ,\      |
     \   `.    :     :        :  ,'  \    :
      \    `|-- `     \ ,'    ,-'     :-.-';
      :     |`--.______;     |        :    :
       :    /           |    |         |   \ 
       |    ;           ;    ;        /     ;
     _/--' |   -hrr-   :`-- /         \_:_:_|
   ,',','  |           |___ \ 
   `^._,--'           / , , .)
                      `-._,-'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/dogs
""", 
"""
                              ,.  ,
                          .-. \ \| \ 
             ,---._    _,-.> `.\ \ (
            (__,'  `   `>-         -\ 
                     ,-'             `-.
         ,-'       ,  ,    .       .    `.
       ,'\       ,' ,-'    `-.      ;    :`.
      (__;     ,',,'      ,   `     : `. :  \ 
             ,' |  _,'   /_    `    :  ; :   \ 
            /  ,',' |   /  \        '     ;   \ 
           /   | |(o|  /  (o)          |  |    ;
          /     ___-^-^-----.          |  |    |
         (   ,---. `-.           :.    |       :
          ;,'      )  `          :..   |        |
          :\      /              :.    |        ;
          :.`-.__,              ,:`    |        |
          ;`.    .             ':'      \      ,
         /   `-.__\           '      ,   \     \.
        (   ,'    \`--,-----.       /     \     \`.
         `-'       \,' ,'   /    / |       \     | `.
      -hrr-        /  '   ,'    /-.|        `.   ;   `.
                  (      /`----'   |          `--'     `
                   `.__,'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/dogs
""", 
"""
                             ;\ 
                            |' \ 
         _                  ; : ;
        / `-.              /: : |
       |  ,-.`-.          ,': : |
       \  :  `. `.       ,'-. : |
        \ ;    ;  `-.__,'    `-.|
         \ ;   ;  :::  ,::'`:.  `.
          \ `-. :  `    :.    `.  \ 
           \   \    ,   ;   ,:    (\ 
            \   :., :.    ,'o)): ` `-.
           ,/,' ;' ,::"'`.`---'   `.  `-._
         ,/  :  ; '"      `;'          ,--`.
        ;/   :; ;             ,:'     (   ,:)
          ,.,:.    ; ,:.,  ,-._ `.     \""'/
          '::'     `:'`  ,'(  \`._____.-'"'
             ;,   ;  `.  `. `._`-.  \\ 
             ;:.  ;:       `-._`-.\  \`.
              '`:. :        |' `. `\  ) \ 
      -hrr-      ` ;:       |    `--\__,'
                   '`      ,'
                        ,-'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/dogs
""", 
"""
       ,.
      /  `-._
     /       `.     ___            __
   ,'       _/ ,---'   `-.       ,'  `.
  /   /`---' \/           `--.  /      \ 
 /   |       /             _  `/  -.    `.
 \   |              ,.    /O\  \    \     \ 
  \   `.           /O \  '   `. `. / \    |
   `._  `-.       /   ,   .    ,  `.  \  ,'
      `-.        .   /     `--'     \  \/
         \        `-',d8o8b.        /
          \          dP'88`8b      /
           \  ,'`.     `YP'       |
    -hrr-   \/ .        |       | |
            /  |\       :       |/\ 
           /   | `.   ,:::     / \ \ 
          ,\       `-'`""'`.--'  )o )
         (o `.__,               / o/
          \ o   \_           ,-'o /
           \  o  o`-----.__,' o ,'
            `----. o  o  o  o ,'
                  `----------'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/dogs
""", 
"""
           ____,'`-,
      _,--'   ,/::.;
   ,-'       ,/::,' `---.___        ___,_
   |       ,:';:/        ;'"`;"`--./ ,-^.;--.
   |:     ,:';,'         '         `.   ;`   `-.
    \:.,:::/;/ -:.                   `  | `     `-.
     \:::,'//__.;  ,;  ,  ,  :.`-.   :. |  ;       :.
      \,',';/O)^. :'  ;  :   '__` `  :::`.       .:' )
      |,'  |\__,: ;      ;  '/O)`.   :::`;       ' ,'
           |`--''            \__,' , ::::(       ,'
           `    ,            `--' ,: :::,'\   ,-'
            | ,;         ,    ,::'  ,:::   |,'
            |,:        .(          ,:::|   `
            ::'_   _   ::         ,::/:|
           ,',' `-' \   `.      ,:::/,:|
          | : _  _   |   '     ,::,' :::
          | \ O`'O  ,',   ,    :,'   ;::
           \ `-'`--',:' ,' , ,,'      ::
            ``:.:.__   ',-','        ::'
    -hrr-      `--.__, ,::.         ::'
                   |:  ::::.       ::'
                   |:  ::::::    ,::'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/dogs
""", 
"""
                                         do.
                                        :NOX
                                       ,NOM@:
                                       :NNNN:
                                       :XXXON
                                       :XoXXX.
                                       MM;ONO:
  .oob..                              :MMO;MOM
 dXOXYYNNb.                          ,NNMX:MXN
 Mo"'  '':Nbb                        dNMMN MNN:
 Mo  'O;; ':Mb.                     ,MXMNM MNX:
 @O :;XXMN..'X@b.                  ,NXOMXM MNX:
 YX;;NMMMM@M;;OM@o.                dXOOMMN:MNX:
 'MOONM@@@MMN:':NONb.            ,dXONM@@MbMXX:
  MOON@M@@MMMM;;:OOONb          ,MX'"':ONMMMMX:
  :NOOM@@MNNN@@X;""XNN@Mb     .dP"'   ,..OXM@N:
   MOON@@MMNXXMMO  :M@@M...@o.oN\"\"\":OOOXNNXXOo:
   :NOX@@@MNXXXMNo :MMMM@K"`,:;NNM@@NXM@MNO;.'N.
    NO:X@@MNXXX@@O:'X@@@@MOOOXMM@M@NXXN@M@NOO ''b
    `MO.'NMNXXN@@N: 'XXM@NMMXXMM@M@XO"'"XM@X;.  :b
     YNO;'"NXXXX@M;;::"XMNN:""ON@@MO: ,;;.:Y@X: :OX.
      Y@Mb;;XNMM@@@NO: ':O: 'OXN@@MO" ONMMX:`XO; :X@.
      '@XMX':OX@@MN:    ;O;  :OX@MO" 'OMM@N; ':OO;N@N
       YN;":.:OXMX"': ,:NNO;';XMMX:  ,;@@MNN.'.:O;:@X:
       `@N;;XOOOXO;;:O;:@MOO;:O:"" ,oMP@@K"YM.;NMO;`NM
        `@@MN@MOX@@MNMN;@@MNXXOO: ,d@NbMMP'd@@OX@NO;.'bb.
       .odMX@@XOOM@M@@XO@MMMMMMNNbN"YNNNXoNMNMO"OXXNO.."";o.
     .ddMNOO@@XOOM@@XOONMMM@@MNXXMMo;."' .":OXO ':.'"'"'  '""o.
    'N@@X;,M@MXOOM@OOON@MM@MXOO:":ONMNXXOXX:OOO               ""ob.
   ')@MP"';@@XXOOMMOOM@MNNMOO""   '"OXM@MM: :OO.        :...';o;.;Xb.
  .@@MX" ;X@@XXOOM@OOXXOO:o:'      :OXMNO"' ;OOO;.:     ,OXMOOXXXOOXMb
 ,dMOo:  oO@@MNOON@N:::"      .    ,;O:""'  .dMXXO:    ,;OX@XO"":ON@M@
:Y@MX:.  oO@M@NOXN@NO. ..: ,;;O;.       :.OX@@MOO;..   .OOMNMO.;XN@M@P
,MP"OO'  oO@M@O:ON@MO;;XO;:OXMNOO;.  ,.;.;OXXN@MNXO;.. oOX@NMMN@@@@@M:
`' "O:;;OON@@MN::XNMOOMXOOOM@@MMNXO:;XXNNMNXXXN@MNXOOOOOXNM@NM@@@M@MP
   :XN@MMM@M@M:  :'OON@@XXNM@M@MXOOdN@@@MM@@@@MMNNXOOOXXNNN@@M@MMMM"'
   .oNM@MM@ONO'   :;ON@@MM@MMNNXXXM@@@@M@PY@@MMNNNNNNNNNNNM@M@M@@P'
  ;O:OXM@MNOOO.   'OXOONM@MNNMMXON@MM@@b. 'Y@@@@@@@@@@@@@M@@MP"'"
 ;O':OOXNXOOXX:   :;NMO:":NMMMXOOX@MN@@@@b.:M@@@M@@@MMM@\"\"\""
 :: ;"OOOOOO@N;:  'ON@MO.'":""OOOO@@NNMN@@@. Y@@@MMM@@@@b
 :;   ':O:oX@@O;;  ;O@@XO'   "oOOOOXMMNMNNN@MN""YMNMMM@@MMo.
 :N:.   ''oOM@NMo.::OX@NOOo.  ;OOOXXNNNMMMNXNM@bd@MNNMMM@MM@bb
  @;O .  ,OOO@@@MX;;ON@NOOO.. ' ':OXN@NNN@@@@@M@@@@MNXNMM@MMM@,
  M@O;;  :O:OX@@M@NXXOM@NOO:;;:,;;ON@NNNMM'`"@@M@@@@@MXNMMMMM@N
  N@NOO;:oO;O:NMMM@M@OO@NOO;O;oOOXN@NNM@@'   `Y@NM@@@@MMNNMM@MM
  ::@MOO;oO:::OXNM@@MXOM@OOOOOOXNMMNNNMNP      ""MNNM@@@MMMM@MP
    @@@XOOO':::OOXXMNOO@@OOOOXNN@NNNNNNNN        '`YMM@@@MMM@P'
    MM@@M:'''' O:":ONOO@MNOOOOXM@NM@NNN@P  -hrr-     "`\"\"\"MM'
    ''MM@:     "' 'OOONMOYOOOOO@MM@MNNM"
      YM@'         :OOMN: :OOOO@MMNOXM'
      `:P           :oP''  "'OOM@NXNM'
       `'                    ':OXNP'
                               '"'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/dogs
""", 
"""
>> dog  <<  10/96

                .-._
               {_}^ )o
      {\________//~`
       (         )
       /||~~~~~||\ 
 jgs  |_\\_    \\_\_
      "' ""'    ""'"'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/dogs
""", 
"""
[peeing dog]
                |\ 
        /    /\/o\_
       (.-.__.(   __o
    /\_(      .----'
     .' \____/
    /   /  / \ 
___:____\__\__\__________________VK

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/dogs
""", 
"""
                            __
     ,                    ," e`--o
    ((                   (  | __,'
     \\~----------------' \_;/
hjw  (                      /
     /) ._______________.  )
    (( (               (( (
     ``-'               ``-'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/dogs
""", 
"""
                                                 .;
                                               .`;'
                                           . ` ;;'
                                  . ` `  `   ;;;'
                                `       @  ;;;
                             `            ;;;
                           `            ;;;;
                         `            ;;;;;.
                       `           .;;;;;;**.
                      `          ;`* .;;; `**.
                 .  `           ;;`****.    '*.
               '** `           ;;;;'****.    .
             '****`            ;;;;;`***.
           '*****`           ;;;;;;  `**.
            ` **`          ;;;;;;;    .*
             `*`         ;;;;;;;;
              `        ;;;;;;;;
              `      ;;;;;;;;
            `      ;;;;;;;
           `     ;;;;;;    . *
         `      ;;;;      ***
         .     ;;       ***
  * *    .    ;;      **
***  *    ` .;;     *
**        .****.       * *
*       . * ^^ *'.   *  ****
  * *               *     ****
***  *        *             ***
***           **
 *            ***
              ***
               **

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/dolphins
""", 
"""
                                        The Dolphins' Way,
                      In Me          Aspirations of the living
                   sea The dolphins do move within    me The aura of
                     their soul, I feel deep down To be in the water
                        and not on ground Sifting through the
                          ocean, an expressing show Communi-
                        cation of a song and a blow Pro-
                     tecting even those not of their
                  kind They ask nothing in return,
             they do not mind The most gracious
          and unselfish of all that wander I
      wish to swim with them, nothing   could
    be fonder The dolphins mean so     much
 to me, you see I need to thank      them,
for showing us how to be                           (Donovan 1997)

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/dolphins
""", 
"""
                                                _______
                                          .,add88YYYYY88ba,
                                     .,adPP""'         `"Yba___,aaadYPPba,
                                 .,adP""                .adP\"\"\""'     .,Y8b
                              ,adP"'                __  d"'     .,ad8P""Y8I
                           ,adP"'                  d88b I  .,adP""'   ,d8I'
                         ,adP"                     Y8P" ,adP"'    .,adP"'
                        adP"                        "' dP"     ,adP""'
                     ,adP"                             P    ,adP"'
             .,,aaaad8P"                                 ,adP"
        ,add88PP\"\"\"\"'                                  ,dP"
     ,adP""'                                         ,dP"
   ,8P"'                                            d8"
 ,dP'                                              dP'
 `"Yba                                             Y8
   `"Yba                                           `8,
     `"Yba,                                         8I
        `"8b                                        8I
          dP                              __       ,8I
         ,8'                            ,d88b,    ,d8'
         dP                           ,dP'  `Yb, ,d8'
        ,8'                         ,dP"      `"Y8P'
        dP                        ,8P"
       ,8'                      ,dP"    Normand
       dP                     ,dP"      Veilleux
      ,8'                    ,8P'
      I8                    dP"
      IP                   dP'
      dI                  dP'
     ,8'                 dP'
     dI                 dP'
     8'                ,8'
     8                ,8I
     8                dP'
     8               ,8'
     8,              IP'
     Ib             ,dI
     `8             I8'
      8,            8I
      Yb            I8
      `8,           I8
       Yb           I8
       `Y,          I8
        Ib          I8,
        `Ib         `8I
         `8,         Yb
          I8,        `8,
          `Yb,        `8a
           `Yb         `Yb,
            I8          `Yb,
            dP            `Yb,
           ,8'              `Yb,
           dP                 `Yb,
          d88baaaad88ba,        `8,
             `\"\"\"'   `Y8ba,     ,dI
                        `""Y8baadP'
                             `""'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/dolphins
""", 
"""
                                                                ,.
                                                               /  \ 
                                                              /..-'
                                                             .'
                                      __.-,'',--,..
           ,-.                    ,-''  .',-\' / _ |
           |  |              ,,'``      //  |   '| `
           `. |          _.-' /'        | ()|  ()|(,.-'''''-.
             '`        ,'    /         --.  | '--'          /
                    _,'     /              -'      __..._ ,'
                   /       /                   _,-'    ,.-
     .-.         ,'       /       _,.....,'- .'_  ,-:-'
     \  \      .'        /       '          `.` \  \ 
      `. |     `..---._ /     _. --           '-._..\.
        `\             .  _,-'           ..         _/             _
         '             /,'                 :.___,,.'            ,-' |
                      ,'                '''`-                ,,'   /
                    ,'        .         ,-'|             _.-'    ,'
                   ,'       ,/        ,'   |          _,'    _.-'
                  .'    _.-'/       ,'     |         '  _.-''
.'`-.             |  ,-'   |       /  \    |       ,:,-'
'.   \            `-' |    |     ,'    \   |       '
 `.   \               |   |     /       `._/
   `.  `.             |   |    /
     `-_`.            |   |   |                          _..'
        `|.           |   |   |                     _.-''  _/
          \            \  |   |fsr    ,,-'\        /.,---`'
           '            \ |   |   _,-'   ,'
                         \ \  |,-'      /
                 _        \ \ |       ,'
                <.`.       \ \|      /               _.
                  \|        `.      /              /' ,'
                             |     /              /--'
                             |    |
                     |.      |   /
          _          ' `._   |   |    ,-'.
          |'-.._,,.-'     `''|   |''''    `.    __.
          |                   \  |          `'''   \ 
         ,'                    `-'                  `-....--'
     _,,'                                                   `.
 ,'''                                                 ,       `-.--'.
'                                                   _'
            `.        .       '.     _ '           , :
              -       |.     ,' `__,'  \         ,' |
              |`._    | `...-           `._  _,-'   |
_             |   `---'                    `'        `.  _,'
 `....,.._   /                                         `'  \       _,
          '''                                              `.___,,'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/dolphins
""", 
"""
                                     _
                                    (_)
              |    .
          .   |L  /|   .          _
      _ . |\ _| \--+._/| .       (_)
     / ||\| Y J  )   / |/| ./
    J  |)'( |        ` F`.'/        _
  -<|  F         __     .-<        (_)
    | /       .-'. `.  /-. L___
    J \      <    \  | | O\|.-'  _
  _J \  .-    \/ O | | \  |F    (_)
 '-F  -<_.     \   .-'  `-' L__
__J  _   _.     >-'  )._.   |-'
`-|.'   /_.           \_|   F
  /.-   .                _.<
 /'    /.'             .'  `\ 
  /L  /'   |/      _.-'-\ 
 /'J       ___.---'\|
   |\  .--' V  | `. `
   |/`. `-.     `._)
      / .-.\ 
VK    \ (  `\ 
       `.\ 

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/fish
""", 
"""
                   ~MY AQUARIUM OF FISH~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
         .               `         /
                          .    ,../...       .
          .                .  /       `\  /  .
     \    .        o         < '  )     =<
     /\  .                    \ \      /  \   .  __
   >=)'>                       `'\'"'"'         /o \/
     \/ .    /         o              /,        \__/\    .:/
     /   .  /--\ /         /         <')=<     .      ,,///;,   ,;/
           <o)  =<      . / \         \`         .   o:::::::;;///
            \__/ \       <')_=<                     >::::::::;;\\\ 
             \            \_/            .            ''\\\\\'' ';\ 
    (                      \              .   __
     )                                       <'_><          (
    (          (                ,/..          `              )
     )     (    )             <')   `=<                )    (
    (       )  (               ``\```                 (      )
_____)_____(____)______________________________________)____(_______jgs_
( some of the fish in here are my creations, 3 are not...
  this is the order from left to right-
         yes, no, yes, yes/yes (tie), yes, yes, no, and no)

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/fish
""", 
"""
(my first ascii drawing was one of these fish!)

     ~^~^~^~^~^~^~^~^~^~^~^^~^~^~^~^~^~
       ~                            ~
            \   '    o      '
            /\ o       \  o
          >=)'>    '   /\ '
            \/   \   >=)'>        ~
            /    /\    \/
     ~         >=)'>   /     .
                 \/                   )
                 /                   (
                       ~          )   )
       }     ~              (    (   (
      {                      )    )   )
       }  }         .       (    (   (
      {  {               /^^^^^^^^^^^^jgs
     ^^^^^^^^^\         /
               ^^^^^^^^^

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/fish
""", 
"""
From:  Shanaka Dias (snd)
A blind fish with it's seeing eye dog fish! :)

                ()

         ,        O
-.       )',
 \'._.,-" c '-,_  o
  ) _,.c cc =[]L]
 /."   ',  c  __.`
-'       \('---'
          '=.____
                 '-.           O
                    \        0
                  ,  \|\_/)
            \-,   |',T(  66,_ o
             ) '-"    \\.___Y)
             ) ,-.Y  _.G
       snd  /-"   /.'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/fish
""", 
"""
** angel fish **  10/96

    ______
   `""-.  `````-----.....__
        `.  .      .       `-.
          :     .     .       `.
    ,     :   .    .          _ :
   : `.   :                  (@) `._
    `. `..'     .     =`-.       .__}
      ;     .        =  ~  :     .-"
    .' .'`.   .    .  =.-'  `._ .'
   : .'   :               .   .'
    '   .'  .    .     .   .-'
 jgs  .'____....----''.'=.'
      ""             .'.'
                  ''"'`

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/fish
""", 
"""
openbsd blowfish
                            .
                            A       ;
                  |   ,--,-/ \---,-/|  ,
                 _|\,'. /|      /|   `/|-.
             \`.'    /|      ,            `;.
            ,'\   A     A         A   A _ /| `.;
          ,/  _              A       _  / _   /|  ;
         /\  / \   ,  ,           A  /    /     `/|
        /_| | _ \         ,     ,             ,/  \ 
       // | |/ `.\  ,-      ,       ,   ,/ ,/      \/
       / @| |@  / /'   \  \      ,              >  /|    ,--.
      |\_/   \_/ /      |  |           ,  ,/        \  ./' __:..
      |  __ __  |       |  | .--.  ,         >  >   |-'   /     `
    ,/| /  '  \ |       |  |     \      ,           |    /
   /  |<--.__,->|       |  | .    `.        >  >    /   (
  /_,' \\  ^  /  \     /  /   `.    >--            /^\   |
        \\___/    \   /  /      \__'     \   \   \/   \  |
         `.   |/          ,  ,                  /`\    \  )
           \  '  |/    ,       V    \          /        `-\ 
            `|/  '  V      V           \    \.'            \_
             '`-.       V       V        \./'\ 
                 `|/-.      \ /   \ /,---`\         kat
                  /   `._____V_____V'
                             '     '
         (~ _   | _  _  _     _  _  _|  _|_|_  _  _ |  _
         _)(_)  |(_)| |(_|,  (_|| |(_|   | | |(_|| ||<_\ 
                        _|
         |` _  _   _ ||  _|_|_  _    _  _  _ _   _  _ _| _
        ~|~(_)|   (_|||   | | |(/_  |_)(_|_\_\VV(_)| (_|_\ 

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/fish
""", 
"""
           .--._.--.
          ( O     O )
          /   . .   \ 
         .`._______.'.
        /(           )\ 
      _/  \  \   /  /  \_
   .~   `  \  \ /  /  '   ~.
  {    -.   \  V  /   .-    }
_ _`.    \  |  |  |  /    .'_ _
>_       _} |  |  | {_       _<
 /. - ~ ,_-'  .^.  `-_, ~ - .\ 
         '-'|/   \|`-`

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/frogs
""", 
"""
       ____  __.---""---.__  ____
      /####\/              \/####\ 
     (/-----)              (------)
      \__OO/                \OO__/
    __/                          \__
 .-"    .                      .    "-.
 |  |   \.._                _../   |  |
  \  \    \."-.__________.-"./    /  /
    \  \    "--.________.--"    /  /
  ___\  \_                    _/  /___
./    )))))                  (((((    \.
\                                      /
 \           \_          _/           /
   \    \____/""-.____.-""\____/    /
     \    \                  /    /
      -.  .|               ./.
    ." / |  -              /  | -  ".
 ."  /   |   -           /   |   -   ".
/.-./.--.|.--.\          /.--.|.--.\.-.|

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/frogs
""", 
"""
  oO)-.
 /__  _\ 
 \  \(  |
  \__|\ {
  '  '--'
Dov Sherman

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/frogs
""", 
"""
     @..@
    (\--/)
   (.>__<.)
   ^^^  ^^^

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/frogs
""", 
"""
     _    _
    (o)--(o)
   /.______.\ 
   \________/
  ./        \.
 ( .        , )
  \ \_\\//_/ /
   ~~  ~~  ~~

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/frogs
""", 
"""
      o  o
     (    )
    /| || |\ 
    ^ ^  ^ ^
     (o)____(o)
   _/          \_
  / \----------/ \ 
  \   | |  | |   /
   ww ooo  ooo ww
             _____________________
             |###################|
             |###################|
             |###################|
             |###################|
 ((-----------------------------------------
 | \         /  /@@ \      /@@ \  \ 
  \ \,      /  (     )    (     )  \            _____
   \ \      |   \___/      \___/   |           /  __ \ 
    \ ""*-__/                      \           | |  | |
     ""*-_                         "-_         | |  \"\"\"
          \    -.  _________   .-   __"-.__.-((  ))
           \,    \^    U    ^/     /  "-___--((  ))
             \,   \         /    /'            | |
              |    \       /   /'              | |
              |     "-----"    \               | |
             /                  "*-._          | |
            /   /\          /*-._    \         | |
           /   /  "\______/"     /   /         | |
          /   /                 /   /          | |
         /. ./                  |. .|          \"\"\"
        /  | |                  / | \ 
       /   |  \                /  |  \ 
      /.-./.-.|               /.-.|.-.\ 

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/frogs
""", 
"""
          __________     __________
         /          \   /          \ 
        /            \ /            \ 
        |        @@  | |   /\       |
       /\        @@  / \            /\   Kerokerokeroppi
      /  \ _________/   \__________/  \ 
     /                                 \ 
    (    O                         O    )
     \    \_                     _/    /
       \_   ---------------------   _/
         ----___________________---- __-->
        /   / =  =  |\ /| =  =  =\       >
      /    /  =  =  |/ \| =  =  = \ __-- >
    /     /=  =  =  =  =  =  =  =  \ 

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/frogs
""", 
"""
    _____
   /     \______
  | o     |     \____
  /\_____/           \___
 /                       \ 
|_______/                 \ 
  \______   _       ___    \ 
        /\_//      /   \    |
       // //______/    /___/
      /\/\/\      \   / \ \ 
                    \ \   \ \ 
                      \ \   \ \ 
                        \ \  \ \ 
                         \ \ /\/\ 
                         /\/\  -Larry Trvis

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/frogs
""", 
"""
>> frog <<  10/96

                              ..
                            .' @`._
             ~       ...._.'  ,__.-;
          _..------/`           .-'    ~
         :     __./'       ,  .'-'--.._
      ~   `---(.-'''---.    \`._       `.   ~
        _.--'(  .______.'.-' `-.`        `.
       :      `-..____`-.                  ;
       `.             ````                 ;   ~
     jgs `-.__                        __.-'
              ````-----.......-----'''    ~
           ~                   ~

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/frogs
""", 
"""
      _______                            ______
     '       '                          '      '
    (   BUD   )         _______        (  WISE  )
     ,_ _____,         /       \        ,___ __,
       |              |   ER    |           |
        \             |         |          /
          oO)-.        \___ ___/      .-(Oo
         /__  _\           |         /_  __\ 
         \  \(  |         /         |  )/  /
          \__|\ |     ()~()         | /|__/
          '  '--'    (-___-)        '--'  '
                     ==`-'==
Steve

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/frogs
""", 
"""
      _______                            ______
     '       '                          '      '
    (   BUD   )         _______        (  WISE  )
     ,_ _____,         /       \        ,___ __,
       |              |   ER    |           |
        \             |         |          /
          oO)-.        \___ ___/      .-(Oo
         /__  _\           |         /_  __\ 
         \  \(  |         /         |  )/  /
          \__|\ |     ()~()         | /|__/
          '  '--'    (-___-)        '--'  '
                     ==`-'==
Steve

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/frogs
""", 
"""
       .--------.....----------..................------------....
     .'  .-.,-..-..---..---..---..---.  .---..----..---.  .---.  '.
     |   | . < | | \ \  \ \ | |-  \ \   | |- | || || |-<  | | |   |
     |   `-'`-'`-'`---'`---'`---'`---'  `-'  `----'`-'`-' `-^-'   |
     '.                   .--..-..-..---..-.,-.                  .'
      |                   |-< | || || |  | . <                   |
     .'                   `--'`----'`---'`-'`-'                  '.
     |_ ....___......__..................................___....._|
       | ||                           .'           `.        || |
       | ||                         ,'               \       || |
       | ||                         )    ,'`.         \      || |
       | ||                        ;    .'   '-.      |      || |
       | ||                        ;   ;<o>  <o>\     ;      || |
       | ||                         '. `.  (     `.    \     || |
       | ||                           )  \ ._.    |     `.   || |
       | ||                          .'   \      /        ;  || |
       | ||                         /      \- -` \        ;  || |
       | ||                       .'\       )    /\      .'\ || |
       | ||                     __   `._ _.' '.  | '._ _'   ||| |
       | ||                    /  ``---``  \   \/  ( )(\'._.'|| |
       | ||                   /             '. @ .. \|// |   || |
       | ||                 ,`                `. \| ||//)    || |
       | ||___....___....._ '.               _.'  \\'`'/ ..__|| |
     .'| ||                   )       .     (      ' .'      || |'.
   .'  | ||                  .`        \     \    / /        || |  '.
  /    | ||              .```.         |      `..'''.        || |    \ 
 ;     '.|'             `.    `.       |      .'    .'       '|.'     '
 |      _   _   _   _.-.  \  .  `.     |    .'  .  /  .-._             \ 
 :     (o)-(o)-(o) (.-. `. \  \   \    '  .'   /  / .' .-.)            |
 |      '======='   (_ `. `.\  \              /  /.' .' _)             '
 '.                  (_.-._ ``, ;            ; ,'' _.-._)             .'
 | ``-..                   `-.   \          /   .-'              ..-'' |
 '.     `._____.......------  `. `.        .' .'  .-------.____.'     .'
  ;`-..                         `-'`._.._.'`-'                    ..-';
  '    `-._____.......---------......--------......-------.____.-' LGB'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/frogs
""", 
"""
           ::'.:
            ''M;
           \"\"\":;
                M;.     .
       ...... ..M:'    MM;.
     ;MMMMMMMMMM:     :MMMM.
     MMMMMMMMMMMMM..  ;MMMM;.
     'MMMMMMMMMMMMMM;.MMM'MM;
      '"MMMMMMMMMMMMMMMMM 'MM;     ,. .
, ,:    ':MMMMMMMMMMMMMMM  'MM.   :;'""
"'.:     :M:":MMMMMMMMMMM   'M; ,;:;;""
'"'M;..;.;M'  ""MMMMMMMM:    'M.MMMM:""
'"'  ""'\"\"\" ;.MMMMMMMM""      '\"\"\"'
         ,;MMMMMMM:""
         'MMMMMMM;.;.
            \"\"\"'\"\"\"\"\":M..
                      ,MM
  -hrr-              ;MM:
                   ,;'MM'
                   ":"M:
                   ::::.

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/frogs
""", 
"""
           ::'.:
            ''$;
           \"\"\":;
                $;.     .
       ...... ..$:'    $$;.
     ;$$$$$$$$$$:     :$$$$.
     $$$$$$$$$$$$$..  ;$$$$;.
     '$$$$$$$$$$$$$$;.$$$'$$;
      '"$$$$$$$$$$$$$$$$$ '$$;     ,. .
, ,:    ':$$$$$$$$$$$$$$$  '$$.   :;'""
"'.:     :$:":$$$$$$$$$$$   '$; ,;:;;""
'"'$;..;.;$'  ""$$$$$$$$:    '$.$$$$:""
'"'  ""'\"\"\" ;.$$$$$$$$""      '\"\"\"'
         ,;$$$$$$$:""
         '$$$$$$$;.;.
           \"\"\"'\"\"\"\"\":$..
                      ,$$
  -hrr-              ;$$:
                   ,;'$$'
                   ":"$:
                   ::::.

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/frogs
""", 
"""
                 db.
                d88P
                88P
         8P    d88
         8     88P                                               d88
        d8b   d88                                               d8P
        888   88P                                             d88P
        8888888P                                  ..od888888888P
        8888888     d8b                       d88888888888888P       d8b
        8888888   d88P                     .d888888888888888888888b d88P
       d88888888888"                     d88888888888888888888888888P"
      d888888888888                    d888888888888P888888b
      8888888888d88b                   888888888888P888888888b..db
     d88888888d88888b                  Y888888888K   Y8b     "Y8888
     88888888d8888888b                  Y8888888888b  Y8b      "YP
    d8888888d888888888b              ... "Y8888888888b.YP  .d888888bo.
   d8888888d8888888888P         .od888888888b88d88888888888888888888888b.
   8888888d88888888888     .d88888888888888888888888888888888888888888888b.
   888888d88888888888P  .d8888888888888888888888888888888888888888888888888b
   888888888888888888 d88888888888888888888888888888888888888888888888888888b
  d88888d88888888888d88888888888888888888888888888888888888888888888888888888
  88888d88888888888d88888888888888888888888888888888888888888888888888888888P
  8888d88888888888d888888888888888888888888888888888888888888888888888888888
  888888888888888d888888888888888888888888888888888888888888888888888888888P
  88888888888888d888888888888888888888888888888888888888888888888888888888P
  8888888888888d888888888888888888888888888888888888888888888888888888888P
  Y888888888888888888888888888888888888888888888888888888888888888888888P
   Y888Pd8888d888888888888888888888888888888888888888888888888888888888"
       d888d8888888888888888888888888888888888888888888888888888888888P
      .88d8888888888888888888888888888888888888888888888888888888888P
      :d888888888888888888888888888888888888888888888888888888P  ""
      :888888888888888888888888888888888888888888888888888888P
      :888888888888888888888888888888888888888888888888P8888P
       8b88888888888888888888888888888888888888888888P888888
       888b88888888888888888888888888888888888888888Pd88888P
       "88888b8888888888888888888888888888888888888Pd888888
        Y88888888b8888888888888888888888888888888P d888888P
         8888888888b888888888888888888888888888P"  8888888
         "88888888888Y88888888888888888888888P     8888888b
          Y888888888888Y8888888888888888888P       Y8888888      d88b
           "Y8888888888b "Y888888888888P"           Y888888b  d888P Y88
             Y8888888888b     \"\"\"\"\"\"                 Y8888888888P
              Y8888888888b                            Y888888888b      .db
 d8b.          Y8888888888                             Y88888888888888888P
 8888888888888888888888888b                             Y88888888888bo.
d88888888888888888888888888                              Y888888888888888bo.
Y88888888888888888888888888b                              "Y8888888888888888888b
 888888888888888888888888888                                Y88888888b      "P8P
 Y888b "Y888888888888888888P                                   "Y88888b.
  8888b   "Y88888888888888P                                         "Y88b
  Y8888.     "Y8888888888P                                            "Y8b.
   88888b         \"\"\"""                                                 "Y88
   Y88888b
    Y888888bo.  .
     8888888888888
     Y8888888b8b "
      Y88888888b88b             .d88888b.
       Y888888b88b888b         d888888888b
        Y888888bY88b8P        d88P"   "Y88b
         "888888b Y88bo.      888       888
          Y888888b  "Y8888b   888                                888
           Y888888b    "YP    888                                888
            8888888b          888    888888                      888
            888P Y888b        888    888888 888d888 .d88b.   .d88888  8888b.
            Y88   "Y88b       888       888 888P"  d88""88b d88" 888     "88b
             Y8     Y88       Y88b.   .d88P 888    888  888 888  888 .d888888
              8b     Y8b       Y88888888888 888    Y88..88P Y88b 888 888  888
              88P     "8b       "Y88888P"88 888     "Y88P"   "Y88888 "Y888888
              "8       Y8P

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/frogs
""", 
"""
                 _
             ,.-" "-.,
            /   ===   \ 
           /  =======  \ 
        __|  (o)   (0)  |__
       / _|    .---.    |_ \ 
      | /.----/ O O \----.\ |
       \/     |     |     \/
       |                   |
       |                   |
       |                   |
       _\   -.,_____,.-   /_
   ,.-"  "-.,_________,.-"  "-.,
  /          |       |          \ 
 |           l.     .l           |
 |            |     |            |
 l.           |     |           .l
  |           l.   .l           | \,
  l.           |   |           .l   \,
   |           |   |           |      \,
   l.          |   |          .l        |
    |          |   |          |         |
    |          |---|          |         |
    |          |   |          |         |
    /"-.,__,.-"\   /"-.,__,.-"\"-.,_,.-"\ 
   |            \ /            |         |
   |             |             |         |
    \__|__|__|__/ \__|__|__|__/ \_|__|__/ Sandra

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/gorillas
""", 
"""
                  ."`".
              .-./ _=_ \.-.
             {  (,(oYo),) }}
             {{ |   "   |} }
             { { \(---)/  }}
             {{  }'-=-'{ } }
             { { }._:_.{  }}
             {{  } -:- { } }
       jgs   {_{ }`===`{  _}
            ((((\)     (/))))

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/gorillas
""", 
"""
                   .-'"`-.
                  /       `.
                 /          \ 
                /            \ 
               /    '-. .'   /\.
             .'|)  _`-. .--  ?) `.
            /   |  ___\/.--.  \|  \ 
          .'    /|("o`><'o`)   L   `._
          F'    >| `-'L >-' ) \J      \ 
         J::-'  >  ) /`^ >) (  |       `.
         F:.'   7   J`-./ ')   F     ` . \ 
 _    .-.-._   .'7, |`-._.'   F::.       .L
< `--/ / / /-.'    7 `-''   \F::::     `  J
 `-./ / / /  )-.    ',   ` .`'  `:`   `.`.J
    \:-.  _ /-._`-._  `:'`'     \`.`.      L
    )\::::-:) :)`-.`-. __        L    `-    L
   J   `:::' :/  . `-./ /`-.   ' |          J
   J     :' :J    :. ||| / _\-.-'|  J     -. L
    \.-----.:F  '. ''\||   |.`.`--------._   J
    /   ::'::\ '.  '  `.(  `-\ \              L
   J   ::'   `.  '' ,.  `-.   `.`.            J
   J    :      \',,   '  ..`._  `.`.          J
    L   :       \   ''.,'     `-_| |__       F
    J   .:       \ ,'  .  ,, .'   \`. `-._.-'
     \   ':,:.    \    '  .:' :    `.`.__\ 
      `.   ':'     \` ' '.:'   :     \\--'\ 
        `.   :      \'::.:' :.      : \>   F
          `.  .      \ .:   '::      :    F
            `.:`:.     ':     ':     :.  J
              >`-::::::::.   .::.    .':F
             J '   '::::::. .::::. .:::'
             F       F `''''.---:::::'/
            J    ._  L    .'.       .'
            |   (  \ )   /_/ >     /
 VK         L\\\\   "       /,   .'
             \\\)'         '/ / //
                            `'''"

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/gorillas
""", 
"""
                                                     ,   .
                                                 ___/J-._
                                               -"   L    ~
                                             -"      '  ; \ 
                                            "       /   `r,\ .
                                           /       |        \ 
                                          /        \       ;.\ 
                                          |         f"-_ "" ' \ 
                                          |       :  \  ',,-. bj
                                          |       : : \   L`]_/
                                          |      \"\"\"; :\:  "
                                          |   ::::      \ 
                                          |o::        :: \ 
                                         /:::'        :o |
                                        /               - -
                                       /               _ |_\ 
       _,,,--._                     _."        :  :.  / 'x  \ 
     ," ,..    "-,              _,-"          ::;. :: .  |  |
   ,, "'    `~..  )    __,---\"\"\"              :          |  L____
   d,         ,).(__,-"                              L   |-,     \"\"\"--"",
  ,d'.       :OO\   ,     '.. .                      7 _ L     __,,,_   |
  'P"   ;  ;.OP/ ,-"  ::;.          .               / _ (-\"\"\"""      T  J
  ,8:   o::oO`  /        :         ::;;     ,;:oO88(    "\           / /
 ,YP  ,::;:O:   |        .     (   ".:::::::::oo888 \     \         / /
 ',d: :;;O;:    |888::    ;;;   "-,  \ooooooooo88__, ",_   \      ,/ /
 dPY:  :o8O     |O8888O:O:; ;;;    " |       _,""      ",   \-,,_  \ 
,' O:  'ob`      |8888888Oo;        |__,,--""            ",  \   |  |
'  Y:  ,:o:       L,___            _j                      j  "  l -"
   ::  ';o:            \       _,-"                        \   \ 
   `:   Oo:             J / ,-"                             "._ j
    :o; 8oP            /  :/                                   \ \ 
   ,ooO:8O'          /" o:/                                     \ \ 
   ;O8odo'           L_(_|L                                      \ \ 
  d"`)8O'              -,, "-._                                   \ "-,
 ''-'`"                   ""-,_, "",                               L__ '-,
                               "-j  \                                 L   \ 

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/horses
""", 
"""
  .  ,
  |\/|
  bd "n.
 /   _,"n.___.,--x.
<co>'\             Y
 ~~   \       L   7|
       H l--'~\\ (||
       H l     H |`'    -Row
       H [     H [
  ____//,]____//,]___

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/horses
""", 
"""
                   ,%%%,
                 ,%%%` %
                ,%%`( '|
               ,%%@ /\_/
     ,%.-\"\"\"--%%% "@@__
    %%/             |__`\ 
   .%'\     |   \   /  //
   ,%' >   .'----\ |  [/
      < <<`       ||
       `\\\       ||
         )\\      )\ 
 ^^^jgs^^\"\"\"^^^^^^""^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/horses
""", 
"""
 '\__
  (o )     ___
  <>(_)(_)(___)
    < < > >
    ' ' ` `
pb

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/ants
""", 
"""
 \       /
  \     /
   \.-./
  (o\^/o)  _   _   _     __
   ./ \.\ ( )-( )-( ) .-'  '-.
    {-} \(//  ||   \\/ (   )) '-.
         //-__||__.-\\.       .-'
        (/    ()     \)'-._.-'
        ||    ||      \\ 
MJP     ('    ('       ')

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/ants
""", 
"""
              "=.
             "=. \ 
                \ \ 
             _,-=\/=._        _.-,_
            /         \      /=-._ "-.
           |=-./~\___/~\    /     `-._\ 
           |   \o/   \o/   /         /
            \_   `~~~;/    |         |
              `~,._,-'    /          /
                 | |      =-._      /
             _,-=/ \=-._     /|`-._/
           //           \\   )\ 
          /|             |)_.'/
         //|             |\_."   _.-\ 
        (|  \           /    _.`=    \ 
        ||   ":_    _.;"_.-;"   _.-=.:
     _-."/    / `-."\_."        =-_.;\ 
    `-_./   /             _.-=.    / \\ 
           |              =-_.;\ ."   \\ 
           \                   \\/     \\ 
           /\_                .'\\      \\ 
          //  `=_         _.-"   \\      \\ 
         //      `~-.=`"`'       ||      ||
   LGB   ||    _.-_/|            ||      |\_.-_
     _.-_/|   /_.-._/            |\_.-_  \_.-._\ 
    /_.-._/                      \_.-._\ 

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/ants
""", 
"""
        \/       \\ 
  ___  _@@       @@_  ___
 (___)(_)         (_)(___)
 //|| ||           || ||\\ 

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/ants
""", 
"""
                 \     /
             \    o ^ o    /
               \ (     ) /
    ____________(%%%%%%%)____________
   (     /   /  )%%%%%%%(  \   \     )
   (___/___/__/           \__\___\___)
      (     /  /(%%%%%%%)\  \     )
       (__/___/ (%%%%%%%) \___\__)
               /(       )\ 
             /   (%%%%%)   \ 
                  (%%%)
                    !

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/bees
""", 
"""
  **bee**
     ,-.
     \_/
   >{|||}
     / \ 
     `-^

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/bees
""", 
"""
                      __
                     // \ 
                     \\_/ //
sjw''-.._.-''-.._.. -(||)(')
                     '''

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/bees
""", 
"""
    ,-.
    \_/
   {|||)<
    / \ 
    `-'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/bees
""", 
"""
         _
        /_/_      .'''.
     =O(_)))) ...'     `.
 jgs    \_\              `.    .'''
                           `..'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/bees
""", 
"""
          _ ___
          \.\'.\ 
           \'\'.\ 
          __\.\:/_//
         {{{{{(__(")
     jgs `~~~~ >>>^

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/bees
""", 
"""
     ^^      .-=-=-=-.  ^^
 ^^        (`-=-=-=-=-`)         ^^
         (`-=-=-=-=-=-=-`)  ^^         ^^
   ^^   (`-=-=-=-=-=-=-=-`)   ^^                            ^^
       ( `-=-=-=-(@)-=-=-` )      ^^
       (`-=-=-=-=-=-=-=-=-`)  ^^
       (`-=-=-=-=-=-=-=-=-`)              ^^
       (`-=-=-=-=-=-=-=-=-`)                      ^^
       (`-=-=-=-=-=-=-=-=-`)  ^^
        (`-=-=-=-=-=-=-=-`)          ^^
         (`-=-=-=-=-=-=-`)  ^^                 ^^
     jgs   (`-=-=-=-=-`)
            `-=-=-=-=-`

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/bees
""", 
"""
                            ,-.
                           /$$|
                          ,;$'`:
                         / $'  `,
                         | `     \,
                         |,m.    ,\_
                         |Y"F ,-,$$ `.
                         |`-'/-'$$,::.\ 
                          \    ;$';::: )
                         ,:\   $':::;,'_
    _,---------.__   ,.. ::'\ `';::',-' \ 
   ($$$"'   (88") `-.;:::;, )  `',-dP  : `,
    `--.      ,--,     `-.|"-.,     --. : \,
        \_    `-',$$$:.   \ -'\`-._  `'  : \__
          `.`$$$$"',.:::/  `.-'\   `--._      `---._________,'`._,'
            ) .:::::::'/,   \`. \       `--------------------\"\"\"'
            `-.`:::'_,'P  / `  \_|
               `---'/:   (;  :
                    `. : :   |
                      `-.  ..|
                         `.  |
                           ):     Actias Isis
                           ||
                           ||
                           ||
                           ||
                           |'
                           /'
            -hrr-         /|
                         ( /
                          )
                         '

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/butterflies
""", 
"""
                                     ,
                                    ;o\ 
                                    ;Ob`.
                                   ;OOOOb`.
                                  ;OOOOOY" )
                                 ;OOOO' ,%%)
                             \  /OOO ,%%%%,%\ 
                              |:  ,%%%%%%;%%/
                              ||,%%%%%%%%%%/
                              ;|%%%%%%%%%'/`-'"`.
                             /: %%%%%%%%'/ c$$$$.`.
                `.______     \ \%%%%%%%'/.$$YF"Y$: )
              _________ "`.\`\o \`%%' ,',$F,.   $F )
     ___,--""'dOOO;,:%%`-._ o_,O_   ,',"',d88)  '  )
  -"'. YOOOOOOO';%%%%%%%%%;`-O   )_     ,X888F   _/
      \ YOOOO',%%%%%%%%%%Y    \__;`),-.  `""F  ,'
       \ `" ,%%%%%%%%%%,' _,-   \-' \_ `------'
        \_ %%%%',%%%%%_,-' ,;    ( _,-\ 
          `-.__`%%',-' .c$$'     |\-_,-\ 
               `""; ,$$$',md8oY  : `\_,')
                 ( ,$$$F `88888  ;   `--'
                  \`$$(    `""' /
                   \`"$$c'   _,'
    -hrr-           `.____,-'

                          Adris Tyranmus

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/butterflies
""", 
"""
                                                                __
    _.---._                                                _.--'  `-.
   /       `--.                                         .-'          \ 
  /            `\.      \                            .-'              |
  |               `\     \                  /      .'                 |
  |                 `\    \                /     .'                   |
  `               .mmm`\   \              /    ./mmmmm                '
  \             .mmmmmmm`\  \            /    / mmmmmmmm             /
   \           .mm-mm/mmm.`\ \          /   ./ mmm\mm/mmmmm         /
    \         mmmmmm\mmmmm  \ `\       /   / / mmmm/mmmmmm         /
     \       .mmmmmmm\mmm` m\m\ \     /   /m/   mm/mmmmmmm.       /
      \    .mmmmmmmmmm``   mm\m\ \   /   /m/mmm    mmmmmmmmmmm   /
       \   mmmmmmmmm`    -mmmm\m\ \ /   /m/mmm-mm    mmmmmmmm'  /
        `\ mm``/mmm.    mmm.-_m\m\ /-\ /m/mm-mmmm     mmm      /
          \    mmm'     `mmmmm.-\m\{__}m/-mmmmm             _./
           `-.________     `mmmmm \[ ]  mmmmm    ___.---::.'
            ..::'.'. .`---.__ mmmm/  \ mmm ___.-'. . .`. .`:.
           /: . . . . .`. .  `--' .__'  --' . . . . . . . . .\ 
          .. . .                . . _  .                 `   .
          |  '                     \_ .                      |
          `                       .|_|                       '
           \                       |/\.                     /
            \                    ./\| \.                   /
             \                   / ||  \                  /
              `.                /  ||   \               ./
                `\            ./   ||:F_P:.           ./
                  `-._      ./     ||      `-._____.-'
                      `----'       / \ 
                                   |_/

     Heliconius Erato Amalfreda Riffarth. - Heliconiidae_(Brasil)

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/butterflies
""", 
"""
       _                           _
      / `._                     _.' \ 
     ( @ : `.                 .' : @ )
      \  `.  `.  ._     _.  .'  .'  /
       \;' `.  `.  \   /  .'  .' `;/
        \`.  `.  \  \_/  /  .'  .'/
         ) :-._`. \ (:) / .'_.-: (
         (`.....,`.\/:\/.',.....')
          >------._|:::|_.------<
         / .'._>_.-|:::|-._<_.'. \ 
         |o _.-'_.-^|:|^-._`-._ o|
         |`'   ;_.-'|:|`-._;   `'|
    jgs  ".o_.-' ;."|:|".; `-._o."
           ".__."   \:/   ".__."
                     ^

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/butterflies
""", 
"""
       _                           _
      / `._                     _.' \ 
     ( @ : `.                 .' : @ )
      \  `.  `.  ._     _.  .'  .'  /
       \;' `.  `.  \   /  .'  .' `;/
        \`.  `.  \  \_/  /  .'  .'/
         ) :-._`. \ (:) / .'_.-: (
         (`.....,`.\/:\/.',.....')
          >------._|:::|_.------<
         / .'._>_.-|:::|-._<_.'. \ 
         |o _.-'_.-^|:|^-._`-._ o|
         |`'   ;_.-'|:|`-._;   `'|
    jgs  ".o_.-' ;."|:|".; `-._o."
           ".__."   \:/   ".__."
                     ^

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/butterflies
""", 
"""
.==-.                   .-==.
 \()8`-._  `.   .'  _.-'8()/
 (88"   ::.  \./  .::   "88)
  \_.'`-::::.(#).::::-'`._/
    `._... .q(_)p. ..._.'
      ""-..-'|=|`-..-""
      .""' .'|=|`. `"".
    ,':8(o)./|=|\.(o)8:`.
   (O :8 ::/ \_/ \:: 8: O)
    \O `::/       \::' O/
     ""--'         `--""   hjw

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/butterflies
""", 
"""
From: "B.K.Bullock" <B.K.Bullock@durham.ac.uk>

    .      .-~\ 
   / `-'\.'    `- :
   |    /          `._
   |   |   .-.        {
    \  |   `-'         `.
     \ |                /
~-.`. \|            .-~_
    .\-.\       .-~      \ 
     `-'/~~ -.~          /
   .-~/|`-._ /~~-.~ -- ~
  /  |  \    ~- . _\ 

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/butterflies
""", 
"""
                                                                  _______
                                                                LLLLLLLLLLL
                                                            __LLLLLLLLLLLLLL
                                                           LLLLLLLLLLLLLLLLL
                                                         _LLLLLLLLLLLLLLLLLL
                                                        LLLLLLLLLLLLLLLLLLLL
                                                      _LLLLLLLLLLLLLLLLLLLLL
                                                      LLLLLLLLLLLLLLLLLLLLLL
                                              L     _LLLLLLLLLLLLLLLLLLLLLLL
                                             LL     LLLLLL~~~LLLLLLLLLLLLLL
                                            _L    _LLLLL      LLLLLLLLLLLLL
                                            L~    LLL~        LLLLLLLLLLLLL
                                           LL   _LLL        _LL   LLLLLLLL
                                          LL    LL~         ~~     ~LLLLLL
                                          L   _LLL_LLLL___         _LLLLLL
                                         LL  LLLLLLLLLLLLLL      LLLLLLLL
                                         L  LLLLLLLLLLLLLLL        LLLLLL
                                        LL LLLLLLLLLLLLLLLL        LLLLL~
                  LLLLLLLL_______       L _LLLLLLLLLLLLLLLL     LLLLLLLL
                         ~~~~~~~LLLLLLLLLLLLLLLLLLLLLLLLL~       LLLLLL
                       ______________LLL  LLLLLLLLLLLLLL ______LLLLLLLLL_
                   LLLLLLLLLLLLLLLLLLLL  LLLLLLLL~~LLLLLLL~~~~~~   ~LLLLLL
             ___LLLLLLLLLL __LLLLLLLLLLLLL LLLLLLLLLLLLL____       _LLLLLL_
          LLLLLLLLLLL~~   LLLLLLLLLLLLLLL   LLLLLLLLLLLLLLLLLL     ~~~LLLLL
      __LLLLLLLLLLL     _LLLLLLLLLLLLLLLLL_  LLLLLLLLLLLLLLLLLL_       LLLLL
     LLLLLLLLLLL~       LLLLLLLLLLLLLLLLLLL   ~L ~~LLLLLLLLLLLLL      LLLLLL
   _LLLLLLLLLLLL       LLLLLLLLLLLLLLLLLLLLL_  LL      LLLLLLLLL   LLLLLLLLL
  LLLLLLLLLLLLL        LLLLLLLLLLLLL~LLLLLL~L   LL       ~~~~~       ~LLLLLL
 LLLLLLLLLLLLLLL__L    LLLLLLLLLLLL_LLLLLLL LL_  LL_            _     LLLLLL
LLLLLLLLLLLLLLLLL~     ~LLLLLLLL~~LLLLLLLL   ~L  ~LLLL          ~L   LLLLLL~
LLLLLLLLLLLLLLLL               _LLLLLLLLLL    LL  LLLLLLL___     LLLLLLLLLL
LLLLLLLLLLLLLLLL              LL~LLLLLLLL~     LL  LLLLLLLLLLLL   LLLLLLL~
LLLLLLLLLLLLLLLL_  __L       _L  LLLLLLLL      LLL_ LLLLLLLLLLLLLLLLLLLLL
 LLLLLLLLLLLLLLLLLLLL        L~  LLLLLLLL      LLLLLLL~LLLLLLLLLLLLLLLL~
  LLLLLLLLLLLLLLLLLLLL___L_ LL   LLLLLLL       LLLL     LLLLLLLLLLLLLL
   ~~LLLLLLLLLLLLLLLLLLLLLLLL     LLLLL~      LLLLL        ~~~~~~~~~
           LLLLLLLLLLLLLLLLLL_ _   LLL       _LLLLL
               ~~~~~~LLLLLLLLLL~             LLLLLL
                         LLLLL              _LLLLLL
                         LLLLL    L     L   LLLLLLL
                          LLLLL__LL    _L__LLLLLLLL
                          LLLLLLLLLL  LLLLLLLLLLLL
                           LLLLLLLLLLLLLLLLLLLLLL
                            ~LLLLLLLLLLLLLLLLL~~
                               LLLLLLLLLLLLL
                                 ~~~~~~~~~

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/butterflies
""", 
"""
                                                                  _______
                                                                LLLLLLLLLLL
                                                            __LLLLLLLLLLLLLL
                                                           LLLLLLLLLLLLLLLLL
                                                         _LLLLLLLLLLLLLLLLLL
                                                        LLLLLLLLLLLLLLLLLLLL
                                                      _LLLLLLLLLLLLLLLLLLLLL
                                                      LLLLLLLLLLLLLLLLLLLLLL
                                              L     _LLLLLLLLLLLLLLLLLLLLLLL
                                             LL     LLLLLL~~~LLLLLLLLLLLLLL
                                            _L    _LLLLL      LLLLLLLLLLLLL
                                            L~    LLL~        LLLLLLLLLLLLL
                                           LL   _LLL        _LL   LLLLLLLL
                                          LL    LL~         ~~     ~LLLLLL
                                          L   _LLL_LLLL___         _LLLLLL
                                         LL  LLLLLLLLLLLLLL      LLLLLLLL
                                         L  LLLLLLLLLLLLLLL        LLLLLL
                                        LL LLLLLLLLLLLLLLLL        LLLLL~
                  LLLLLLLL_______       L _LLLLLLLLLLLLLLLL     LLLLLLLL
                         ~~~~~~~LLLLLLLLLLLLLLLLLLLLLLLLL~       LLLLLL
                       ______________LLL  LLLLLLLLLLLLLL ______LLLLLLLLL_
                   LLLLLLLLLLLLLLLLLLLL  LLLLLLLL~~LLLLLLL~~~~~~   ~LLLLLL
             ___LLLLLLLLLL __LLLLLLLLLLLLL LLLLLLLLLLLLL____       _LLLLLL_
          LLLLLLLLLLL~~   LLLLLLLLLLLLLLL   LLLLLLLLLLLLLLLLLL     ~~~LLLLL
      __LLLLLLLLLLL     _LLLLLLLLLLLLLLLLL_  LLLLLLLLLLLLLLLLLL_       LLLLL
     LLLLLLLLLLL~       LLLLLLLLLLLLLLLLLLL   ~L ~~LLLLLLLLLLLLL      LLLLLL
   _LLLLLLLLLLLL       LLLLLLLLLLLLLLLLLLLLL_  LL      LLLLLLLLL   LLLLLLLLL
  LLLLLLLLLLLLL        LLLLLLLLLLLLL~LLLLLL~L   LL       ~~~~~       ~LLLLLL
 LLLLLLLLLLLLLLL__L    LLLLLLLLLLLL_LLLLLLL LL_  LL_            _     LLLLLL
LLLLLLLLLLLLLLLLL~     ~LLLLLLLL~~LLLLLLLL   ~L  ~LLLL          ~L   LLLLLL~
LLLLLLLLLLLLLLLL               _LLLLLLLLLL    LL  LLLLLLL___     LLLLLLLLLL
LLLLLLLLLLLLLLLL              LL~LLLLLLLL~     LL  LLLLLLLLLLLL   LLLLLLL~
LLLLLLLLLLLLLLLL_  __L       _L  LLLLLLLL      LLL_ LLLLLLLLLLLLLLLLLLLLL
 LLLLLLLLLLLLLLLLLLLL        L~  LLLLLLLL      LLLLLLL~LLLLLLLLLLLLLLLL~
  LLLLLLLLLLLLLLLLLLLL___L_ LL   LLLLLLL       LLLL     LLLLLLLLLLLLLL
   ~~LLLLLLLLLLLLLLLLLLLLLLLL     LLLLL~      LLLLL        ~~~~~~~~~
           LLLLLLLLLLLLLLLLLL_ _   LLL       _LLLLL
               ~~~~~~LLLLLLLLLL~             LLLLLL
                         LLLLL              _LLLLLL
                         LLLLL    L     L   LLLLLLL
                          LLLLL__LL    _L__LLLLLLLL
                          LLLLLLLLLL  LLLLLLLLLLLL
                           LLLLLLLLLLLLLLLLLLLLLL
                            ~LLLLLLLLLLLLLLLLL~~
                               LLLLLLLLLLLLL
                                 ~~~~~~~~~

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/butterflies
""", 
"""
     __....__                                           _..-'"`""+"'-.
   ."`.._____`"-._                                  _.-"__...-----\""'\ 
 ,'..._      '""-.`._                            _.'_."'       __..\---|
( :    "..__     _,'."-._                      ,'_.'__`.----""'     \ /
 . \        `",+'--.+`-..`.   o           o  .'-"   \  _.".-"''\"\"\"`"'/
  \"`.+"'----+----.'       `.  .        .' ,'       .'" ___"._____,'.
   \  .   __/......`.__      `. `.     ' ." __..--'"+'""     \    :-|
    \-:--"  :      /__ `'"-.._ \  \   / /.-'__..---""`."'----.\___; '
     .: _..+.--"'"/   `"--..__`_`. \ / /.-'"           `.     :   :7
     ':"  .'    .'--------""'   `.(_X_)'"'"'"`----""'`'--`-''".--.'
      \._.'-'""/    ______        / ^ \ _....--------...__`._'_."
       `.\_`."_..."",---. `""`'"": / \ :____    .""`"._   "-."
         `"",._...'"    '__..-''"`j   \'.   `"-;      ,`\"\"\"`.`.
          ,".'    :      \     .'.| " |\ `.   /       `      \ \ 
         '.'...--".       \  ,' / | - | .  "-/       ."`-.._  : .
        j":     _,'_       .'  /  | = | '   /       ,-\     `.:.|
        | .  _.'    ;      :  /   } = {  \ j       _\  `._    ' :
        | ',"     .'".      ./    `._,'   ':      :  \    "._: j
        '.':    ,"   ,".    .              \     ,-.  `._    '"|
         \ `  .'    /   :_  '               \   :   \    `._/ j
          . `'     /   /  \/                 ."".    \      : |
          ; :     /   /   /                  "   \    \     ; :
        ,'   \__.'___/__.'                    `.__\____\__.'   `.
      .'  .'".  _....-"                       mh "--...._  ,--.  `.
      `--'    `"                                         `"    `--"

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/butterflies
""", 
"""
    ___.---.      --.                              .-      __.------.
  .'     #  `-._     `.                          .'     .-'  ##    : \ 
 / :    #       `-.    `.                      .'    .-'       ##   : \ 
 |:            .###`-.   `.                  .'   .-'##/#.     #    : |
 |:  ##       .## `   `-   `.              .'   .'     `##       ##   |
 |                      `\   `.          .'   .'                      |
 \ : ##             .%%%\ `\   `.      .'   .' %%%.              ## : /
  \               %\%%%%    `\   `\ _.'   ./    %%%%%/               /
   \   #      %   %%%\%       \.   / \  ./       %%/%%   %      #   /
    \        %%        %%::-.   \ (;:)./   /._:-::       %%        /
     `\ #                 `:::-: \/:;/  ::::::''               #  /
       \                       `: ::: ::''                       /
        \        .........      :: :, :      ........          ./
         `---.:::::::::::::::::' ::,.::  :::::::::::::::::.-_-'
           / :'''  %%%%%/%%%%%/%%.|\.  %%\%%%%%%\%%%%       \ 
           |       `%%/%%%/%%|%%/%|||%%%%%|%\%%%/%\%     #  |
           |                      |||\%%                    |
            \     #               ||||               #     /
             \      ##       ## ./ || \ ##       ## #     /
              \        # # #   /   ||  \  ## # #        ./
               `-.           ./    ||   \              /
                  `_        / :F_P:||    `-.__      ./'
                    `------'       ||         `----'
                                   \|
                                    |
              Heliconius Atthis - Heliconiidae (Ecuador)

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/butterflies
""", 
"""
 _    _     _    _     _    _     _    _    _    _    _    _
(.\\//.)   (.\\//.)   (.\\//.)   (.\\//.)  (.\\//.)  (.\\//.)
 \ () /     \ () /     \ () /     \ () /    \ () /    \ () /
 (_/\_)     (_/\_)     (_/\_)     (_/\_)    (_/\_)    (_/\_)

JRO

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/butterflies
""", 
"""
       ___
      / _ \\  ,,
     /=(_)=\\//
     \ =(_) (O}
      \_____\\      .--.     Jonathon R. Oglesbee
       /=(_)\\\   .'_\/_'.
       \____///   '. /\ .'   aka JRO
            ())     "||"
                     || /\ 
                  /\ ||//\)
                 (/\\||/
        ____________\||/________________________________

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/butterflies
""", 
"""
                                  _ " _
   _ " _                         (_\|/_)
  (_\|/_)  _ " _         _ " _    (/|\)
   (/|\)  (_\|/_) " _   (_\|/_)
           (/|\)_\|/_)   (/|\)
   ejm97        (/|\)

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/butterflies
""", 
"""
              \    /
               \  /
            .--.().--.
           {\_o(  )o_/}
            {/_/\/\_\}
             \/    \/
 -Dana'98-  ,/      \,
           (/        \)

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/butterflies
""", 
"""
     .-.
    (  |.-.
   .-\/__ )
  (__/ \ 
     \_/


     .-.            .-.
    (  |.-.      .-.|  )
   .-'/__ )     ( __\ '-.
  (__/ \           / \___)
     \_/           \_/        S-v

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/butterflies
""", 
"""
     .-.
    (  |.-.
   .-\/__ )
  (__/ \ 
     \_/


     .-.            .-.
    (  |.-.      .-.|  )
   .-'/__ )     ( __\ '-.
  (__/ \           / \___)
     \_/           \_/        S-v

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/butterflies
""", 
"""
        .-.               .-.
        \  |.-.       .-.|  /
        ,\_|_/         \_|_/,
         / | \         / | \ 
S-v     /  |`-`       '-'|  \ 
        `-'               '-'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/butterflies
""", 
"""
    _
   { \,"
  {_`/
    ` BP

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/butterflies
""", 
"""
          O  O
 __________\/
(((((((((((oo)
Alex Krcek

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/butterflies
""", 
"""
     \_/-.--.--.--.--.--.
     (")__)__)__)__)__)__)
 jgs  ^ "" "" "" "" "" ""

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/butterflies
""", 
"""
           _ _ /--\ 
  \/_ _ _/(_(_(_o o)
   (_(_(_(/      ^

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/butterflies
""", 
"""
                            _     _
   ,,,,,,,,,,,,,,,,,,,,,,,,  \   /
 / (  (  (  (  (  (  (  (  \ [ = =]
<  (  (  (  (  (  (  (  (  /  { ^ }
 \ (__(__(__(__(__(__(__(__)    ~
   ^  ^  ^  ^  ^  ^  ^  ^  ^
             -cfbd-

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/butterflies
""", 
"""
                     _     _               _     _
    ,,,,,,,,,,,,,,,,  \   /                 \   /             -, ,-
   /  (  (  (  (  (  \( u u)     ,,,,,,,,,, ( @ @)     ,,,,,,,(. .)
   \__(__(__(__(__(__) ( ^ )    (__(__(__(_) ( ^ )    (__(__(__(^)
      ^  ^  ^  ^  ^  ^   ~       ^ ^  ^  ^ ^   ~       ^ ^  ^  ^ ^
                                     -cfbd-

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/butterflies
""", 
"""
           ,  .'''''.  ...    ''''',  .'
            ','     ,.MMMM;.;'      '.
             ;;    ;MMMMMMMMM;     ;;'
            :'M:  ;MMMMMMMMMMM;.  :M':
            : M:  MMMMMMMMMMMMM:  :M  .
           .' M:  MMMMMMMMMMMMM:  :M. ;
           ; :M'  :MMMMMMMMMMMM'  'M: :
           : :M: .;"MMMMMMMMM":;. ,M: :
           :  ::,MMM;.M":::M.;MMM ::' :
         ,.;    ;MMMMMM;:MMMMMMMM:    :,.
         MMM.;.,MMMMMMMM;MMMMMMMM;.,;.MMM
         M':''':MMMMMMMMM;MMMMMMMM: "': M
         M.:   ;MMMMMMMMMMMMMMMMMM;   : M
         :::   MMMMMMMMMMM;MMMMMMMM   ::M
        ,'';   MMMMMMMMMMMM:MMMMMMM   :'".
      ,'   :   MMMMMMMMMMMM:MMMMMMM   :   '.
     '     :  'MMMMMMMMMMMMM:MMMMMM   ;     '
     ,.....;.. MMMMMMMMMMMMM:MMMMMM ..:....;.
     :MMMMMMMM MMMMMMMMMMMMM:MMMMMM MMMMMMMM:
     :MM\"\"\":"" MMMMMMMMMMMMM:MMMMMM "": "'MM:
      MM:   :  MMMMMMMMMMMMM:MMMMMM  ,'  :MM
      'MM   :  :MMMMMMMMMMMM:MMMMM:  :   ;M:
       :M;  :  'MMMMMMMMMMMMMMMMMM'  :  ;MM
       :MM. :   :MMMMMMMMMM;MMMMM:   :  MM:
        :M: :    MMMMMMMMM'MMMMMM'   : :MM'
        'MM :    "MMMMMMM:;MMMMM"   ,' ;M"
         'M  :    \"\"\""":;;;\"\"\"""    :  M:
         ;'  :     "MMMMMMMM;."     :  "".
       ,;    :      :MMMMMMM:;.     :    '.
      :'     :    ,MM''\"\"\""'':M:    :     ';
     ;'      :    ;M'         MM.   :       ;.
   ,'        :    "            "'   :        '.
   '        :'                       '        ''
 .          :                        '          '
'          ;                          ;          '
          ;                            '

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/cockroaches
""", 
"""
       ,--.     .--.
      /    \. ./    \ 
     /  /\ / " \ /\  \ 
    / _/  {~~v~~}  \_ \ 
   /     {   |   }     \ 
  ;   /\{    |    }/\   \ 
  | _/  {    |    }  \_  :
  |     {    |    }      |
  |    /{    |    }\     |
  |   / {    |    } \    |
  |  /  {    |    }  \   |
  |  \  \    |    /  /   |
  |   \  \   |   /  /    |
  \    \  \  |  /  /     /
   \   /   ~~~~~   \    / krr

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/cockroaches
""", 
"""
       ,--.     .--.
      /    \. ./    \ 
     /  /\/  "  \/\  \ 
    / _/ /~~~v~~~\ \_ \ 
   /    /####|####\    \ 
  ;  /\{#####|#####}/\  \ 
  |_/  {#####|#####}  \_:
  |    {#####|#####}    |
  |   /{#####|#####}\   |
  |  / {#####|#####} \  |
  | /  {#####|#####}  \ |
  |  \ \#####|#####/ /  |
  |   \ \####|####/ /   |
   \   \ \###|###/ /   /
    \  /   ~~~~~   \  /   krr

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/cockroaches
""", 
"""
             Ralph
        ,--.       ,---.
       /    '.    /     \ 
              \  ;
               \-|
              (o o)      (/
              /'v'     ,-'
      ,------/ >< \---'
     /)     ;  --  :
        ,---| ---- |--.
       ;    | ---- |   :
      (|  ,-| ---- |-. |)
         | /| ---- |\ |
         |/ | ---- | \|
         \  : ---- ;  |
          \  \ -- /  /
          ;   \  /  :
         /   / \/ \  \ 
        /)           (\ -hrr-

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/cockroaches
""", 
"""
     ,--.       ,---.
    /    '.    /     \ 
           \  ;
            \-|
           (- -)
           /`v'\/;
    ,-----/ ,---/)--.
  ,'     ; ( /////// )
 /)  ,---| -`-----(\'
    ;    | ---- |  '
   (|  ,-| ---- |-.
      | /| ---- |\ |
      |/ | ---- | \|
      \  : ---- ;  |
       \  \ -- /  /
       ;   \  /  :
      /   / \/ \  \ 
     /)           (\ -hrr-
    .: Ralph & Son :.

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/cockroaches
""", 
"""
                      .-.
                     ()I()
                "==.__:-:__.=="
               "==.__/~|~\__.=="
               "==._(  Y  )_.=="
    .-'~~""~=--...,__\/|\/__,...--=~""~~'-.
   (               ..=\=/=..               )
    `'-.        ,.-"`;/=\ ;"-.,_        .-'`
        `~"-=-~` .-~` |=| `~-. `~-=-"~`
             .-~`    /|=|\    `~-.
          .~`       / |=| \       `~.
  jgs .-~`        .'  |=|  `.        `~-.
    (`     _,.-="`    |=|    `"=-.,_     `)
     `~"~"`           |=|           `"~"~`
                      |=|
                      |=|
                      |=|
                      /=\ 

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/other
""", 
"""
       (\"/)
       (/|\)
         |
ejm97    |

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/other
""", 
"""
           ()
ejm97   -----%
           ()

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/other
""", 
"""
       _ " _
      (_\|/_)
      (_/|\_)
         |
ejm97    |
         |

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/other
""", 
"""
             .-.
            o   \     .-.
               .----.'   \ 
             .'o)  / `.   o
            /         |
            \_)       /-.
              '_.`    \  \ 
               `.      |  \ 
                |       \ |
            .--/`-.     / /
          .'.-/`-. `.  .\|
         /.' /`._ `-    '-.
    ____(|__/`-..`-   '-._ \ 
   |`------.'-._ `      ||\ \ 
   || #   /-.   `   /   || \|
   ||   #/   `--'  /  /_::_|)__
   `|____|-._.-`  /  ||`--------`
         \-.___.` | / || #      |
          \       | | ||   #  # |
          /`.___.'\ |.`|________|
          | /`.__.'|'.`
        __/ \    __/ \ 
       /__.-.)  /__.-.) LGB

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/other
""", 
"""
         \   /
         .\-/.
     /\  () ()  /\ 
    /  \ /~-~\ /  \ 
        y  Y  V
  ,-^-./   |   \,-^-.  Don't Bug
 /    {    |    }    \   Me!!!
       \   |   /
       /\  A  /\ 
      /  \/ \/  \ 
     /           \ ∫VaMp FiNaL / crw

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/other
""", 
r"""
            _         _
           /x\       /x\ 
          /v\x\     /v\/\ 
          \><\x\   /></x/
           \><\x\ /></x/
   __ __  __\><\x/></x/___
  /##_##\/       \</x/    \__________
 |###|###|  \         \    __________\ 
  \##|##/ \__\____\____\__/          \\ 
    |_|   |  |  | |  | |              \|
    \*/   \  |  | |  | /              /
            /    /
Dorian Sergio Araneda

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/other
""", 
"""
   \ 
    '-.__.-'
    /oo |--.--,--,--.
    \_.-'._i__i__i_.'
          \"\"\"\"\"\"\"\"\"
fsc

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/other
""", 
"""
       / .'
 .---. \/
(._.' \()
 ^\"\"\"^"

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/other
""", 
"""
          /\ .---._
       /\/.-. /\ /\/\  br
     //\\oo //\\/\\\\ 
    //  /"/`---\\ \\"`-._
_.-'"           "`-.`-.

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/other
""", 
"""
                   .-"-.
    .-"-.       @@/     \ 
   /     \@@    Y '-<<<-'
   '->>>-' Y        '''
jgs  ```

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/other
""", 
"""
               .  .
                \/             ,
               @'"@_.-"':_.-"':
                4'  ',.,'"',.,'
                     |||   |||
              miK   "'"'" ""''"

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/other
""", 
"""
 \__/      \__/       \__/       \__/       \__/       \__/       \__/
 (oo)      (o-)       (@@)       (xx)       (--)       (  )       (OO)
//||\\    //||\\     //||\\     //||\\     //||\\     //||\\     //||\\ 
 bug       bug        bug/w      dead       bug       blind     bug after
         winking    hangover     bug      sleeping     bug      seeing a
                                                                 female
           -tony harris-                                          bug

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/insects/other
""", 
"""
       (\_          _/)
       )  (        )  (
      (    (      )    )
       )_(\ \.--./ /)_(
         `)` 6  6 '('
          /        \ 
     jgs (  )    (  )
          `(_c__c_)`
             `--`

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/moose
""", 
"""
       (\_            _/)
       )  (          )  (
      (    (        )    )
       )    (      )    (
       (    (      )    )
        \_ (\\.--.//) _/
          \)` 6  6 '(/
           /        \ 
      jgs (  )    (  )
           `(_c__c_)`
              `--`

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/moose
""", 
"""
      _/\_       __/\__
      ) . (_    _) .' (
      `) '.(   ) .'  (`
       `-._\(_ )/__(~`
           (ovo)-.__.--._
           )             `-.______
  jgs/VK  /                       `---._
         ( ,// )                        \ 
          `''\/-.                        |
                 \                       |
                 |                       |

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/moose
""", 
"""
                                      _.--\"\"\"--,
                                    .'          `\ 
  .-\"\"\"\"\"\"-.                      .'              |
 /          '.                   /            .-._/
|             `.                |             |
 \              \          .-._ |          _   \ 
  `""'-.         \_.-.     \   `          ( \__/
        |             )     '=.       .,   \ 
       /             (         \     /  \  /
     /`               `\        |   /    `'
     '..-`\        _.-. `\ _.__/   .=.
          |  _    / \  '.-`    `-.'  /
          \_/ |  |   './ _     _  \.'
               '-'    | /       \ |
                      |  .-. .-.  |
                      \ / o| |o \ /
                       |   / \   |
                      / `"`   `"` \ 
                     /             \ 
                    | '._.'         \ 
                    |  /             |
                     \ |             |
                      ||    _    _   /
                      /|\  (_\  /_) /
              jgs     \ \'._  ` '_.'
                       `""` `\"\"\"`

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/moose
""", 
"""
                      _,-------.
                    ,'          `.
                   ;              ;
          ,-'"`-. ;,---._         ;
         ;  ,-. ,'_      `.       ;
         ;  ;_;;;' ;      ;      ;
         `.    ;`-'       ;      ;
           `-,''.        ,'     ;
         _,-'    `-.__,-'      ;
  _,,-\"\"\"                     ;
  `.                         ;
   ;`.                      ;
   ;  `.                   ;
   ;.   `.       ;        ;
    ;     `.     ;       ;
    ;       `-.. ;      ;
    ;           ,'     ;
    ;                  ;
     ;                ;
     ;                ;
     ;               ;
      ; --.          ;
      ; .___         ;
       ;    '--..   ;
       ; '--..      ;
        ;_    '"    ;
         ;""'-._    ;
         ;-.._      ;
         ;_   '""   ;
         ; '- .     ;

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
       ___,A.A_  __
       \   ,   7"_/
        ~"T(  r r)
          | \    Y
          |  ~\ .|
          |   |`-'
          |   |
          |   |
          |   |
          |   |
          j   l
         /     \ 
        Y       Y
        l   \ : |
        /\   )( (
       /  \  I| |\ 
      Y    I l| | Y
      j    ( )( ) l
     / .    \ ` | |\   -Row
    Y   \    i  | ! Y
    l   .\_  I  |/  |
     \ /   [\[][]/] j
  ~~~~~~~~~~~~~~~~~~~~~~~

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
    (\-/)
   (:O O:)
    \   /o\ 
     | |\o \ 
     (:) \ o\ 
          \o \--_
          ( o O
          (  O

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
                          /\          /\ 
                         ( \\        // )
                          \ \\      // /
                           \_\\||||//_/ 
                            \/ _  _ \ 
                           \/|(O)(O)|
                          \/ |      |  
      ___________________\/  \      /
     //                //     |____|      
    //                ||     /      \ 
   //|                \|     \ 0  0 /
  // \       )         V    / \____/ 
 //   \     /        (     /
""     \   /_________|  |_/
       /  /\   /     |  ||
      /  / /  /      \  ||
      | |  | |        | ||
      | |  | |        | ||  
      |_|  |_|        |_||       
       \_\  \_\        \_\\ Hard'96  

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
          /\ 
  __     /^|
 / /\###//||
 |//  #  \//
  :(o) (o);
   \     /##
    || ||  ##
    /   \   `--...____
   ( @_@ )
    `---'    /
     |      |
      \      \   |ap

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
              :     :
        __    |     |    _,_
       (  ~~^-l_____],.-~  /
        \    ")\ "^k. (_,-"
         `>._  ' _ `\  \ 
      _.-~/'^k. (0)  ` (0
   .-~   {    ~` ~    ..T
  /   .   "-..       _.-'
 /    Y        .   "T
Y     l         ~-./l_
|      \          . .<'
|       `-.._  __,/"r'
l   .-~~"-.    /    I
 Y         Y "~[    |
  \         \_.^--, [
   \            _~> |
    \      ___)--~  |
     ^.       :     l
       ^.   _.j     |
         Y    I     |
         l    l     I
          Y    \    |    -Row
           \    ^.  |
            \     ~-^.
             ^.       ~"--.,_
              |~-._          ~-.
              |    ~Y--.,_      ^.
              :     :     "x      \ 
                            \      \.
                             \      ]
                              ^._  .^
                                 ~~
        ->Possum<-

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
        /^\    /^\ 
       {  O}  {  O}
        \ /    \ /
        //     //       _------_
       //     //     ./~        ~-_
      / ~----~/     /              \ 
    /         :   ./       _---_    ~-
   |  \________) :       /~     ~\   |
   |        /    |      |  :~~\  |   |
   |       |     |      |  \___-~    |
   |        \ __/`\______\.        ./
    \                     ~-______-~\.
    .|                                ~-_
   /_____________________________________~~____ jurcy

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
           eed*\"\"\"\"\"\"\"\"\"**be,
        .d"                  "b.
      .d                        b.
    ."         ..eeeeee..         ".
   P        z$*"        "*e.        9.
  A       d"                "b       A
 J       J    .e*\"\"\"\"\"\"%c     A       L
A       A    d"          $     L      A
#       %   d      d**y  'L    %      #
#       %   $     $ ,, Y  .$   %      #       _ _
#       %   $     *  \"\"\"   F   %      #      (@)@)
#       V    4.    $.   .e"    Y      #        % %
#        $    *.    \"\"\""     .Y      V         $ $
#        'b     "b.      ..e*       Y         .eeee
V         '$      ""eeee""        eP         A     %
 Y         eb                ..d*"         _#    O %
 I    _e%*\"\"\""*$ee......ee$*"eeeeeeeezee$**"       $
  V ,"                                            B
  J'                                        _,e=""
.'#######################################DWB''

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
    ______
   /  ___ \ 
  |  / ,.\ |O    O
  | |  \d/ | \__/
  |__\_____/-(..)
_/_____________/ dwb

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
             /~~~~\   /~~~~\ 
             \    /   \    /
              |  |_____|  |
            /~             ~\ 
   /~~~~~-_|  /~~\    /~~~\  |_-~~~~~\ 
   \ ==== /| |   O|  |   ^ | |\ ==== /
    ~-__-~ | |_---+--+----_| | ~-__-~
           |/~             ~\|
           /                 \ 
          (      O      O     )
           `\              ./'
             ~-__________-~|
             |   |\__/|    |
             |   |/~~\|    |
             | /~~~~~~~~~\ |
             | |         | |
             | |         | |
             | |         | |
             | |         | |

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
                  __------__
                /~          ~\ 
               |    //^\\//^\|         Oh..My great god ...
             /~~\  ||  o| |o|:~\       Please grant me many many
            | |6   ||___|_|_||:|    /  bananas .. I want to give them
             \__.  /      o  \/'       to my dear Mary, then she will
              |   (       O   )        agree to marry me!!
     /~~~~\    `\  \         /
    | |~~\ |     )  ~------~`\ 
   /' |  | |   /     ____ /~~~)\ 
  (_/'   | | |     /'    |    ( |
         | | |     \    /   __)/ \ 
         \  \ \      \/    /' \   `\ 
           \  \|\        /   | |\___|
             \ |  \____/     | |
             /^~>  \        _/ <
            |  |         \       \ 
            |  | \        \        \ 
            -^-\  \       |        )
                 `\_______/^\______/-jurcy

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
    .;;'
  `;;,.                                  ;;,
    `;;;;,.                               `;;;,
      `;;;;;,                          `;;,//`;;,
         `;;;;;, ,;;'                  .oOOoOOo.;;, .;;'
            `;;;;;,.                   OOOOOOOOO`;;;,
                `;;;;;,                `OOOOOOO' `;;;;;,
   ';.              `;;;;;,             `OOOOO'    `;;;;;
     ';;. ,;;'         ``;;;;;,                      `;;;,
      `;;;                  `;;;;;,                   ;;;;
        ;;;                     `;;;;;,           `;;,;;;;
         ;;;,.                     `;;;;;,           ,;;;.;;'
          `;;;;;,                     `;;;;;,      ,;;;;
    *     // `;;;;;;;;,.                 `;;;;;,.;;;;'
                   ``;;;;;;;;;,. ,;;'       `;;;;;,'
                           `;;;;;;,.           `;;;;;,.                  ,
     .     .     *             ``;;;;,..           `;;;;;,      `;;,  .,;'
                             `;;,// `;;;;;;;;;;,.     `;;;;;,      ,;'\\,;;'
         *                   .oOOoOOo.    ```;;;;;;,     `;;;;;,:;'.oOOoOOo.
   .           .             OOOOOOOOO           `;;;;;    `;;;;;;,OOOOOOOOO
                             `OOOOOOO'              `;;;;,    `;;;;`OOOOOOO'
     *                        `OOOOO'                  `;;;;,    `;;`OOOOO'
             .     *                                      `;;;;;;; ;;,,..
                                                                  ;;;;;;;;;,
    `;;,//    .                                                       `;;;;;
 .   .oOOoOOo.
     OOOOOOOOO
     `OOOOOOO'
      `OOOOO'


       .;;.a,      .,.        .,,.
     ,@;;;;.,a  ,@@a;a@@,   ,@@@@@@,
     @@`;;;;'@,@@@'@;@`@@@,@@@oooo@@
     @@,Ssss';@@@@aaaaa@@@@;@@oooo@@
      `SSSS;,@@@@@@@@@@@@@@@,@@@@@' ,;;,
     .sSSSS;@@@@@@@@@@@@@@@@@     ;,;;;;
     sSSSSS;`@@@@@@@@@@@@@@@'      ;;;;'
     SSSSSSSs;%%ssssssss%%,sSSs, .SsssS
     SSSSSSSS;%%sSSSSSSSs%%;SSSSSSSSSS'
     `SSSSSSS;%%sSSSSSSSSs%%;SSSSSSS'
       `SSSS;%%%%%%%%%%%%%%%% \"\"\"""       ..,,,,..
         `SS;%%%%%%%%%%%%%%%%,     .,;;;;;;'''''';;;;;;,
           %%%%%%%%%%%%%%xx%%%.;;;;;;'                `;;;.
           %%%%%%%%%%%%%xx%%%%%                         `;;.
           %%%%%%%xxx%^%%%%%%%%%                         `;;
           %%%%%%%%%%' `%%%%%%%%.,                        ;'
           %%%%%%%%%'    `%%%%';;;'oOOo                  ;'
           %%%%%%%%%       `%';;'oOOOOO                 '
           `%%%%%%%'         `;'OOOOOO'
             ;;;;;             `OOOOO'
        ',,''oOOOo'',,'          \"\"\"
            OOOOOOO
          ..,,,,,,,,.                      `;;.//
        ,'`;;;;;;;;;;;',                   .oOOoOOo.
       ;   ;;;;;;;;;;;  ;                  OOOOOOOOO
       ;  .;;;;;;;;;;;, ;,;;;;;;;,.        `OOOOOOO'
        `;;;;;;;;;;;;;;' ;;;;;;;;;;`,      ;`OOOOO',
         .%%%%%%%%%%,' ,;;;;;;;;;;  ;      ;;,,,,,;'
        .%%%%%%%%%%%%,%%%%%;;;;;;;, ;    .;;;;;;;;'       ;
       ,%%%%%%%%%%%%%,%%%%%%;;;;;;;'   .;;;;;;;;'        ;   .'
       %%%%%%%%%%%%%%,%%%%%%%        .;;;;;;;;;'        ;  .'
      ,%%%%%%%%%%%%%'%%%%%%%;,.     ;;;;;;;;;;    .a@~~a, '
      %%%%%%%%%%%%%'%%%%%%%,%%%%%%,,;;;;;;;;'  .a@@@@a@@@@a.
     ,%%%%%%%%%%%%'%%%%%%%,%%%%%%%%%,;;;;;;; .a@@oOOOo@@@@@@a.
     %%%%%%%%%%%%'%%%%%%%%%,'''',%%%%%%%%,;.a@@OOOOOOOO@""@ @@a.
    ,%%%%%%%%%%%'%%%%%%%,;;;,,,,,%%%%;;`%%.@@@OOOOOOOOO@@@a@@@@@.
    %%%%%%%%%%%%%%%%%%,;;;;;;;;,%%%,;;;;;.@@@@@OOOOOOO@@@@@@@@@@@
    ####%%%%%%%%%%%%%,;;;;;;;;,%%%%%%%%,;,@@@@@@@@@@@@@@@@@@@@@@@
    ####%%%%%%%%%%%%%;;;;;;;;;;;;;;;;;;%%,@@@@@@@@@@@@`aa.@@@@@@@
    `###%%%%%%%%%%%%%;;;;;;;;;;;;;;;;;;;;%%`@@@@@@@@@@`@@@.@@@@@'
      `%%%%%%%%%%%%\"\"\"`;;;;;;;;;;;;;;;;;;;;;''`@@@@@@@@`@@@.@@'@
       .;''''';.  .;;;;;,    ..,,,,,..    ,;;;;;.   ,;'''@@@a @@
       ;,,,,,,;; ;;;' `;;;,::;;;;;;;;;::,;;;' `;;; ;;,,,,@oo@a`@
       `;;;;;;;; ;;;,,,;;;;;:';;;;;;;;`;;;;;,,,;;; ;;;;;;@@oo@@a
        `;;;;;;;;,`;;;;;;;:,;;;;;;;;;;;;,;;;;;;;',;;;;;;;@@oooo@@a
         `;;;;;;'%%% .:::;;;;' ;;;;;' ;;;;:::, %%%`;;;;;'@@@ooooo@@a
           ;;'%%%%%%.::;;;;;a@@@. .@@@a;;;;;::.%%%%%%`;  `@@@oooooo@@a
          ,%%%%%%%%%.::;;;;@@@@@@;@@@@@@;;;;::.%%%%%%%%%, @@@oooooooo@@a
          `%%%%%%%%%%.::;;;@@@'@@;@@`@@@;;;::.%%%%%%%%%%' `@@ooooooooo@@a.
             `%%%%%%%%%`::;;@@@aaaaa@@@;;::'%%%%%%%%%'     @@oooooooooo@@@a
            .%%%%%%%%%%;!!,,,,,,,,,,,,,,,!!;%%%%%%%%%%%,  .@@@ooooooooo@@@@
           %%%%%%%%%%%;!!!!!!!!!!!!!!!!!!!!!;%%%%%%%%%%%  @;@@@oooooooo@@@'
           %%%%%%%%%%%;!!!!!!!!  "  !!!!!!!!;%%%%%%%%%%%  @a;@@@ooooo@@@@'
           `%%%%%%%%%;!!!!!!!!!!, .!!!!!!!!!!;%%%%%%%%%'  @@@a;@@@@@@@@'
              `%%%%%;!!;!!;!!;!!;!!;!!;!!;!!;!;%%%%%'     `@@@@aaaaaa'
                  .!!!!!!!!!!!!!!!!!!!!!!!!!!!!!.           `@@@@@@'
                 .!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!.
                !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
               ,!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!,
              ! !!! !!! !!! !!! !!! !!! !!! !!! !!! !
             .!!! !!! !!! !!! !!! !!! !!! !!! !!! !!!.
             !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! !!!!!
            !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!',;'!!!!!   ';,
            `!!`!!`!!`!!`!!`!!`!!`!!`!!`!!`!!',;; !'!!'    ;;,
                      ;;;;;;;;;;;^;;;;;;.,,,,.;;;a@@@@@@@@a;;;  .,,.      ,
                      ;;;;;;;;;;' `;;',a@@a%%%%%%%%%@@@@@%%%%,@@@@@@@@%%;'
       _             .::;;;;;;,'   ; a@@@@@%%%%%%%''%@@%%``%%%%@@@@@%%;;'
     ('v')    ;    ,@a,`;;;,aa@,  , a@@@%%%^%%%%%,%%%%%%%%%,%%%%%%%;;;'
     (,_,)   ;;; ,' `@@ @@@@@@';  ; @@@%%'  %%%%%%% `%%% `%%%%%%%;;'
    .,;;;;.  `;' :.           ,'  `,`@'  ..,;%%a@@@@@@@@@@@@@a%%'
  .;;'|/ `;;;;'.aaaaaaaaaaaaaa%%%%%%%%%%%%%%%a@@@@@@@@@@@@@@@@@a
  ;;.      .a@@@@@@@@@@%%%%%%%%%%%%%%%%%%%%%%@@@@(`@@@@@@@')@@@@
  `;;.   ,a@@@@@@@@@@@@@a%%%%%%%%%%%%%%%%%%%::@@@@a@@@@@@@a@@@@:.
    `;;.a@@@@@@@@@@@@@@%%%%%%%%%%%%%%a@@@%%::%%`@@@@@@@@@@@@@'%%::  ,'',
      `@@@@@@@@@@@@@@@%%%%%%%@@a%a@@@@@@@%::%%%%%%%%%%%%%%%%%%%%%::'   ;
      @@@@@@@@@@@@@@@@@a%%%%@@@@@@@@@@@@@%;;|;,;|;,;|;,;|;.;|;,;|;;   / \ 
      @@@@@@@@@@@@@@@@%%%%%%%@@@@@@@@@@@@%`;;,|;,;|;,;|;,;|;,;|;,;'  | A |
      %%%%%%@@@@@%%%;%%%%%%@@@@@@@@@@@@@@@%`|;,;|;,;|;,;|;,;|;,;|'   | P |
      `@@%%%%%%%%;'%%%%%%%%%%@@@@%%@@%%%%%%%,`|;,;|;,;|;,;|;,;|'     | P |
       `@@a%%%%%%.%%% '''%%%%%%%%%%%%%%%'''''' %%%@@@%%.%%%%'        | L |
        @@@@%%%%.%%%'                          %%%@@@@.%%%a@         | E |
        @@@%%%%.@a%%                           %%%@@%%.%%@@@         | S |
 ~~~~~~ @%%%%%%.@@%% ~~   ~~~~~~~~~    ~~~~~~~ %%%%@@@.%%%@@ ~~~~    `~~~'
        `:::::'`:::'                           `:::::'`::::' Susie Oviatt

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
         __
   __   (__`\ 
  (__`\   \\`\ 
   `\\`\   \\ \ 
     `\\`\  \\ \ 
       `\\`\#\\ \#
         \_ ##\_ |##
         (___)(___)##
          (0)  (0)`\##
           |~   ~ , \##
           |      |  \##
           |     /\   \##         __..---'''''-.._.._
           |     | \   `\##  _.--'                _  `.
           Y     |  \    `##'                     \`\  \ 
          /      |   \                             | `\ \ 
         /_...___|    \                            |   `\\ 
        /        `.    |                          /      ##
       |          |    |                         /      ####
       |          |    |                        /       ####
       | () ()    |     \     |          |  _.-'         ##
       `.        .'      `._. |______..| |-'|
         `------'           | | | |    | || |
                            | | | |    | || |
                            | | | |    | || |
                            | | | |    | || |
                      _____ | | | |____| || |
                 jgs /     `` |-`/     ` |` |
                     \________\__\_______\__\ 
                      \"\"\"\"\"\"\"\"\"   \"\"\"\"\"\""'\"\"\"

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
   (`-.          ,-')
    \ \\        / //
     \ \\      / //
      \ \\    / //
       \ `````-//
      (___)(___)-.
       (0)  (0)``-._
        |~   ~ , `-._
        |      |  `-._
        |     /\   `-._        __..---'''''-.._.._
        |     | \   `-._  _.--'                _  `.
        )     |  \      ``                     \`\  \ 
       /      |   \                             | `\ \ 
      /_....__)    \                            |   `\\ 
     /        \     |                          /      ))
    |          |    |                         /      ((((
    |          |    |                        /        ))))
    | () ()    |     \     |          |  _.-'         (((
    `.        .'      `._. |______..| |-'|
      `------'           | || |     | || |
                         | || |     | || |
                         | || |     | || |  rediddled by
                         | || |     | || |   Allen Mullen
                   _____ | || |_____| || |
              jgs /     `` |` /     ` |` |
                  \________\__\_______\__\ 
                   \"\"\"\"\"\"\"\"\"   \"\"\"\"\"\""'\"\"\"

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
* fox/ferret *  11/96
   ___
   "._`-.         (\-.
      '-.`;.--.___/ _`>
         `"( )    , )
            \\----\-\ 
 ~~jgs~~~~~~ "" ~~ \"\"\" ~~~~~~~~~~~~~~

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
-=[ gnu ]=-  12/96

    ,/       \,
   //         \\ 
  ((__,-\"\"\"-,__))
   `--)~   ~(--`
  .-'(       )`-,
  `~~`d)   (b`~~`
      |     |
      |     |
      |     |
      |     |
      |     |
 jgs  (6___6)
       `---`

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
* hippopotamus *  11/96

           _.---.)
 (^--^)_.-"      `;
 ) ee (           |
(_.__._)         /
  `--',        ,'
   jgs )_|--')_|
       ""'   ""'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
* lions *  11/96
             ,%%%%%%%%,
           ,%%/\%%%%/\%%
          ,%%%\c "" J/%%%
 %.       %%%%/ o  o \%%%
 `%%.     %%%%    _  |%%%
  `%%     `%%%%(__Y__)%%'
  //       ;%%%%`\-/%%%'
 ((       /  `%%%%%%%'
  \\    .'          |
   \\  /       \  | |
    \\/         ) | |
 jgs \         /_ | |__
     (___________)))))))

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
                          ,%%%%%%%,
                        ,%%/\%%%%/\%,
                       ,%%%\c "" J/%%,
  %.                   %%%%/ d  b \%%%
  `%%.         __      %%%%    _  |%%%
   `%%      .-'  `"~--"`%%%%(=_Y_=)%%'
    //    .'     `.     `%%%%`\7/%%%'____
   ((    /         ;      `%%%%%%%'____)))
   `.`--'         ,'   _,`-._____`-,
jgs  `\"\"\"`._____  `--,`          `)))
                `~"-)))

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
         ,%%%%%%%,
       ,%%/\%%%%/\%,
      ,%%%\c "" J/%%,
      %%%%/ d  b \%%%
      %%%%    _  |%%%
      `%%%%(=_Y_=)%%'
   jgs `%%%%`\7/%%%'
         `%%%%%%%'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
~  OLD MACDONALD HAD A FARM.............eieio!  ~

        , .    .--.
        _|__  |____|
       /    \ |____|
     /   []   |____|
    |__________|  |
    |   ____   |  |        _
    |  |\  /|  |  |      _[_]_
    |  | \/ |  |  |       c")
    |  | /\ |  |  |      ,(_)'
    |__|/__\|__|__|       -"-

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
and on his farm there was a pig......eieio


           ||            ||   (\../)   ||           ||
          _||____________||____(oo)____||___________||_
          -||------------||---"----"---||-----------||-
          _||____________||__@( __ )___||___________||_
          -||------------||----"--"----||-----------||-
           ||            ||            ||           ||jgs
        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
**I saw a similar pig somewhere and then made this one...

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
and on his farm there was a rooster......eieio

         ,   #
        (\\_(^>
        (_(__)`
           ||
          _||___
          -||---
          _||___
          -||---
           ||
        ^^^^^^^^^^

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
and on his farm there were some ducks....eieio
 --         _                          _
        ,__(^<        >@)_,           (')<       >O___,
        \___)          (_>)          <~_)         (_=/
          ||            ||            ||           ||
         _||____________||____________||___________||_
         -||------------||------------||-----------||-
         _||____________||____________||___________||_
         -||------------||------------||-----------||-
          ||            ||            ||           ||
       ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
and on his farm there was a cow......eieio

                                       __.----.___
           ||            ||  (\(__)/)-'||      ;--` ||
          _||____________||___`(QQ)'___||______;____||_
          -||------------||----)  (----||-----------||-
          _||____________||___(o  o)___||______;____||_
          -||------------||----`--'----||-----------||-
           ||            ||       `|| ||| || ||     ||jgs
        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
and on his farm there was a sheep......eieio

                              {^--^}.-._._.---.__.-;
           ||            ||   {6 6 }.')' (  )  ).-`  ||
          _||____________||___( v  )._('.) ( .' )____||_
          -||------------||----`..''(.'  (   ) .)----||-
          _||____________||______#`(.'( . ( (',)_____||_
          -||------------||-------'\_.).(_.). )------||-
           ||            ||        `W W     W W      ||jgs
        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
Put them all together and you have:

   ,   #                                                     _
  (\\_(^>                            _.                    >(')__,
  (_(__)           ||          _.||~~ {^--^}.-._._.---.__.-;(_~_/
     ||   (^..^)   ||  (\(__)/)  ||   {6 6 }.')' (. )' ).-`  ||
   __||____(oo)____||___`(QQ)'___||___( v  )._('.) ( .' )____||__
   --||----"- "----||----)  (----||----`-.''(.' .( ' ) .)----||--
   __||__@(    )___||___(o  o)___||______#`(.'( . ( (',)_____||__
   --||----"--"----||----`--'----||-------'\_.).(_.). )------||--
     ||            ||       `||~|||~~|""||  `W W    W W      ||jgs
   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
"My Barnyard" * Joan Stark * spunk1111@juno.com * spunk1111@aol.com

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
** pig **  10/96

        (\____/)
        / @__@ \ 
       (  (oo)  )
        `-.~~.-'
         /    \ 
       @/      \_
      (/ /    \ \)
  jgs  WW`----'WW

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
** pigs **  10/96
                                   __
                           _...,_ (, )
   ,        ,     _..---'"'      `-./
   :`.----.':_.-'"                  `,
   : ^    ^ :                         ;
  :  6    6  :                        ;
  :          :             .          ;
  :    __    :            :          ;
   `:'.--.`:'   .         `.        ;
    : o  o :  ;`-.___       `.    .'`.
     `----':  :  :   ```"''"'``.  `.  ;
 jgs       :  :  :            .'  .' .'
          .' .'_.'          .'  .'_.'
         `---'             `---'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
                    __
            _,..,_ (, )
         .,'      `,./
       .' :`.----.': `,
      :   : ^    ^ :   ;
     :   :  6    6  :   ;
     :   :          :   ;
     :   :    __    :   ;
      :   `:'.--.`:'   ;
       `.  : o  o :  .'
   jgs  :   `----'   :
        : .  :'`:  . :
        `.:.'    `.:.'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
* pigs * 11/96

      __,___@
     [_'^   )
       `//-\\ 
       ^^  ^^
     @___,__
jgs  (   ^'_]
     //-\\'
     ^^  ^^

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
Boar
          _,-\"\"\""-..__
     |`,-'_. `  ` ``  `--'\"\"\".
     ;  ,'  | ``  ` `  ` ```  `.
   ,-'   ..-' ` ` `` `  `` `  ` |==.
 ,'    ^    `  `    `` `  ` `.  ;   \ 
`}_,-^-   _ .  ` \ `  ` __ `   ;    #
   `"---"' `-`. ` \---""`.`.  `;
              \\` ;       ; `. `,
               ||`;      / / | |
  jrei        //_;`    ,_;' ,_;"

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
Boar
          _,-\"\"\""-..__
     |`,-'_. `  ` ``  `--'\"\"\".
     ;  ,'  | ``  ` `  ` ```  `.
   ,-'   ..-' ` ` `` `  `` `  ` |==.
 ,'    ^    `  `    `` `  ` `.  ;   \ 
`}_,-^-   _ .  ` \ `  ` __ `   ;    #
   `"---"' `-`. ` \---""`.`.  `;
              \\` ;       ; `. `,
               ||`;      / / | |
  jrei        //_;`    ,_;' ,_;"

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
@@ A Herd of Sheep - Who's the Black Sheep in the Family? @@  11/96

        _       _       _       _       _       _       _       _
     _-(_)-  _-(_)-  _-(_)-  _-(_)-  _-(_)-  _-(_)-  _-(_)-  _-(_)-
   `(___)  `(___)  `(___)  `(___)  `(___)  `(___)  `(___)  `(___)
jgs // \\   // \\   // \\   // \\   // \\   // \\   // \\   // \\ 
       _       _       _       _       _       _       _       _
    _-(_)-  _-(_)-  _-(_)-  _-(")-  _-(_)-  _-(_)-  _-(_)-  _-(_)-
  `(___)  `(___)  `(___)  `%%%%%  `(___)  `(___)  `(___)  `(___)
   // \\   // \\   // \\   // \\   // \\   // \\   // \\   // \\ 
      _       _       _       _       _       _       _       _
   _-(_)-  _-(_)-  _-(_)-  _-(_)-  _-(_)-  _-(_)-  _-(_)-  _-(_)-
 `(___)  `(___)  `(___)  `(___)  `(___)  `(___)  `(___)  `(___)
  // \\   // \\   // \\   // \\   // \\   // \\   // \\   // \\ 
     _       _       _       _       _       _       _       _
  _-(_)-  _-(_)-  _-(_)-  _-(_)-  _-(_)-  _-(_)-  _-(_)-  _-(_)-
`(___)  `(___)  `(___)  `(___)  `(___)  `(___)  `(___)  `(___)
 // \\   // \\   // \\   // \\   // \\   // \\   // \\   // \\ 

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
     _.%%%%%%%%%%%%%
    /- _%%%%%%%%%%%%%
   (_ %\|%%%%%%%%%%%%
      %%%$$$$$$$$$$$%
        S%S%%%*%%%%S
    ,,,,# #,,,,,,,##,,,,,  b'ger

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
** worm in apple **  10/96
                           .
                         .OO
                       .OOOO
                      .OOOO'
                      OOOO'          .-~~~~-.
                      OOO'          /   (o)(o)
              .OOOOOO `O .OOOOOOO. /      .. |
          .OOOOOOOOOOOO OOOOOOOOOO/\    \____/
        .OOOOOOOOOOOOOOOOOOOOOOOO/ \\   ,\_/
       .OOOOOOO%%OOOOOOOOOOOOO(#/\     /.
      .OOOOOO%%%OOOOOOOOOOOOOOO\ \\  \/OO.
     .OOOOO%%%%OOOOOOOOOOOOOOOOO\   \/OOOO.
     OOOOO%%%%OOOOOOOOOOOOOOOOOOO\_\/\OOOOO
     OOOOO%%%OOOOOOOOOOOOOOOOOOOOO\###)OOOO
     OOOOOO%%OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
     OOOOOOO%OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
     `OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO'
   .-~~\OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO'
  / _/  `\(#\OOOOOOOOOOOOOOOOOOOOOOOOOOOO'
 / / \  / `~~\OOOOOOOOOOOOOOOOOOOOOOOOOO'
|/'  `\//  \\ \OOOOOOOOOOOOOOOOOOOOOOOO'
       `-.__\_,\OOOOOOOOOOOOOOOOOOOOO'
      jgs  `OO\#)OOOOOOOOOOOOOOOOOOO'
             `OOOOOOOOO''OOOOOOOOO'
               `\"\"\"\"\"\"'  `\"\"\"\"\"\"'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
   -=,
 ,.__(^,
 `)_,._\ 
 "'    `" pb

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
                       _,;
                    ,-','         |\ 
                   ( (          _/ |
                    \ \     ,-''_,'
                |`-._\ `.-,' ;',--'\  _...._
                `.__/         / _,-'-'    , `.
                    ),    ()   `-'     ,      \ 
                    ;  "    ;   ,         ,    :
                  ,'      ,'       ,           :
                 (_)  __,'    ,     ,      ,   :
                  `''   \ _. ;         ,   ,   |
                         . -'     ,            \ 
     antelope            \    ,         ,      \ 
     Sitatunga            .         ,   _.. ,  \ 
(Tragelaphus spekei)      ' .. ,'    _,'   \   |
                           \` '    ;'\  '   \  \ 
                           ;`--|  ;   \  \   \  \ 
                          ;  ; ;  ;    '  :   .  `,
                          ;  ; ;  |    :  ;    \  ;
                         ;  ;  ;  ;    ;  ;     : ;
                         ;  ; ;  ;     ; ;      ; ;
                        ;  ;  ;  ;    ; ;       ; ;
                        ; ;   ; ;    ; ;        ; ;
                       ; ;    ; ;   ;_|         ; ;
                       ; ;   ; ;               /_ |
                      ; ;    ; ;
                jrei /__:   ;_ |

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
Armadillo

           .::7777::-.
          /:'////' `::>/|/             ,.-----__
        .',  ||||   `/( e\          ,:::://///,:::-.
    -==~-'`-Xm````-mr' `-_\        /:''/////// ``:::`;/|/
                                  /'   ||||||     :://'`\ 
                     ,          .' ,   ||||||     `/(  e \ 
         \/               -===~__-'\__X_`````\_____/~`-._ `.
                   .,                 ~~        ~~       `~-'
                       _____               /`
       '\/          ,::////;::-.          \|      o
                   /:'///// ``::>/|/            \/
                 .',  ||||    `/( e\ 
             -==~-'`-Xm````-mm-' `-_\      \,     Seal do Mar

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
                                            .'\ 
                            .-.            /   ;
                          .' /            |  | |
  -.._         ,-. ,-._.-' .'             \  ' .-'"-._
      `'--.._,/_. `y  \ _.'        ________`;/ _.,--  /
              _ |  |   |t;-""''"~`_.-----""'-f_      /
 _   __..--~~;|7   ;   '__ ..__   `'-._        `'--'`_.,,.__
  `'-,_\_    |'    /  /        `''---._L-._       .'`_.-'   /
       `"\   | `'-'`-'                  `".7;.,_ /_ '      /
          `  ;   |    _  .-.      .-._       `~;f;```'._,-'
             |   |   ( `"|  `.__.-' | \      .'/|  '-.  \ 
             ;   ;._  > /  _  \     /_/     / ;  \    `. |
          ,-'`     _`',/  /`.  `:--'_      ;  |   |-._   ;
        /`       .'_\-._ f.  `.  \_/ `\_   |  |   /   `'-;
       ;mx      / /| \ \\  `.  \  `  _/ |  |    ,'
      ;         '- \  ` |    \  \   '  _7  |_.-'
      |             `>  /     ;  `'"---'
      |            .'  '      ;
      ;           .   /      ;
       \          ;  ;      .
        \         |  |     / __     _  ___   _ _   _ _    ___
         ;        ;  |_  ,'  \ \ /\// '_| \ | '_`.| '_`. '_| \ 
          ;      .'   ` /     \ '  / //_| | | || || || |//_| |
        _  |        __,'       '/\/  \,__._>|_||_||_||_|\,__._>
     /`  `'.        ''`'--._       _   _   ___   _ _    ___
    | |     \               `.    | | | | '_| \ | '_`. / .-`
    \ '.__\ '                 `.  | |_| |//_| | | || ||  |_-.
     ;.                         \ |_|-|_|\,__._>|_||_| \___,/
    /                      ____  '._   ___  _  _  ___   ___
    |          .-.    -.-'`    `'._/  /.-.\| | ||[   ] '-. \ 
   -;.        /    \ _ '        _._7  \`_'/| |_|| | |    /_/
   / \.     (`\  o  |c       _.'       ___  \__.' |_|   (_)
      `.,   |  `-.o_\    _.-'         `--`
        /|'-'\_7,_,' `-'`

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(land)
""", 
"""
 , , ,  p   p
      ,-`````-.__
~~~~ <|@@DWB@@|_:)
      `-.....-`
 ` ` `  b   b

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(water)
""", 
"""
     **whale**
               __   __
              __ \ / __
             /  \ | /  \ 
                 \|/
            _,.---v---._
   /\__/\  /            \ 
   \_  _/ /              \ 
     \ \_|           @ __|
  hjw \                \_
  `97  \     ,__/       /
     ~~~`~~~~~~~~~~~~~~/~~~~

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(water)
""", 
"""
                      . .
                    '.-:-.`
                    '  :  `
                 .-----:
               .'       `.
         ,    /       (o) \ 
     jgs \`._/          ,__)
     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(water)
""", 
"""
     .-'
'--./ /     _.---.
'-,  (__..-`       \ 
   \          .     |
    `,.__.   ,__.--/
      '._/_.'___.-`

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(water)
""", 
"""
                                  /^^^/           /]
                                 /   ]           / ]
      O                  _______/    ]___       /  ]
                        /                \_____/   /
   O                  _/   [@]  \ \                \ 
           ___//_    /..         | |                ]
    o     /o )   \/   VVVvvv\    | |         _/\    ]
      O<  )___\\_/\         |               /    \  ]
                     AAA^^^^^              /       \]
                      \_________\   \_____/
                               \    \ 
                                 \____\ 

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(water)
""", 
"""
       \/)/)
     _'  oo(_.-.
   /'.     .---'
 /'-./    (
 )     ; __\ 
 \_.'\ : __|
      )  _/
     (  (,.
   mrf'-.-'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(water)
""", 
"""
     .``-,_
    /o)''..`.
  _.`._,,,:_;:
  '.` /--/--/
      |-':--|
      |'-"--|fsr
      \--;'-;
       '._;--\ 
       _  \._|
      ;,'_/'/
      '.__.'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(water)
""", 
r"""
From: spunk1111@aol.com (Spunk1111)
Newsgroups: alt.ascii-art
Subject: [PIC]   seahorse...
Date: 25 Aug 1997 00:20:21 GMT

                        ,
                   ,   /^\     ___
                  /^\_/   `...'  /`
               ,__\    ,'     ~ (
            ,___\ ,,    .,       \ 
             \___ \\\ .'.'   .-.  )
               .'.-\\\`.`.  '.-. (
              / (==== ."".  ( o ) \ 
            ,/u  `~~~'|  /   `-'   )
           "")^u ^u^|~| `\"\"\".  ~_ /
             /^u ^u ^\~\     ".  \\ 
     _      /u^  u ^u  ~\      ". \\ 
    ( \     )^ ^U ^U ^U\~\      ". \\ 
   (_ (\   /^U ^ ^U ^U  ~|       ". `\ 
  (_  _ \  )U ^ U^ ^U ^|~|        ". `\.
 (_  = _(\ \^ U ^U ^ U^ ~|          ".`.;
(_ -(    _\_)U ^ ^ U^ ^|~|            ""
(_    =   ( ^ U^ U^ ^ U ~|
(_ -  ( ~  = ^ U ^U U ^|~/
 (_  =     (_^U^ ^ U^ U /
  (_-   ~_(/ \^ U^ ^U^,"
   (_ =  _/   |^ u^u."
    (_  (/    |u^ u.(
     (__/     )^u^ u/
             /u^ u^(
            |^ u^ u/
            |u^ u^(       ____
            |^u^ u(    .-'    `-,
             \^u ^ \  / ' .---.  \ 
       jgs    \^ u^u\ |  '  `  ;  |
               \u^u^u:` . `-'  ;  |
                `-.^ u`._   _.'^'./
                   "-.^.-```_=~._/
                      `"------"'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(water)
""", 
"""
                   d888b
                 888888888b
             _d8888888888888
            (+ 8888888888888
         _.88888888888888888b
     .d8888888P'    d88888888
   888888P''       d88888888P
                   888888888
                  d888888888
                  8888888888
                 d8888888888b .8.
                 q88888888888 888
                  q88888888888888b
                   q88888888888888
                    888888888888'
                     q8888888888b
                        ``q888888b
                           `q88888
                             q8888b
                              q88888
                               q88888
                                q8888b
                           d888b q8888
                          888/\8b/888P
                          88:F_P:8888
                          `888888888P
                             ``''''

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(water)
""", 
"""
Lobster
                          ,.---.
                ,,,,     /    _ `.
                 \\\\   /      \  )
                  |||| /\/``-.__\/
                  ::::/\/_
  {{`-.__.-'(`(^^(^^^(^ 9 `.========='
 {{{{{{ { ( ( (  (   (-----:=
  {{.-'~~'-.(,(,,(,,,(__6_.'=========.
                  ::::\/\ 
                  |||| \/\  ,-'/\ 
   jgs           ////   \ `` _/  )
                ''''     \  `   /
                          `---''

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(water)
""", 
"""
@@ shell- whelk @@  11/96

       /\ 
      {.-}
     ;_.-'\ 
    {    _.}_
     \.-' /  `,
      \  |    /
       \ |  ,/
    jgs \|_/

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(water)
""", 
"""
@@ shell- ark @@  11/96

           _.---._
       .'"".'/|\`.""'.
      :  .' / | \ `.  :
      '.'  /  |  \  `.'
       `. /   |   \ .'
    jgs  `-.__|__.-'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(water)
""", 
"""
@@ shell- clam @@  11/96

           _.---._
       .:":_'-.-`_:":.
      :`.`._'-.-'_.'.':
      '`.`._`-.-'_.'.''
       `.`-.`-.-'.-'.'
    jgs  `._`-.-'_.'
            `'''`

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(water)
""", 
"""
        ___
       / o \ 
  __   \   /   _
    \__/ | \__/ \ 
   \___//|\\___/\ 
    ___/ | \___  Carl Pilcher
         |     \ 
        /

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(water)
""", 
"""
                                              ,
                                            ,o
                                            :o
                   _....._                  `:o
                 .'       ``-.                \o
                /  _      _   \                \o
               :  /*\    /*\   )                ;o
               |  \_/    \_/   /                ;o
               (       U      /                 ;o
                \  (\_____/) /                  /o
                 \   \_m_/  (                  /o
                  \         (                ,o:
                  )          \,           .o;o'           ,o'o'o.
                ./          /\o;o,,,,,;o;o;''         _,-o,-'''-o:o.
 .             ./o./)        \    'o'o'o''         _,-'o,o'         o
 o           ./o./ /       .o \.              __,-o o,o'
 \o.       ,/o /  /o/)     | o o'-..____,,-o'o o_o-'
 `o:o...-o,o-' ,o,/ |     \   'o.o_o_o_o,o--''
 .,  ``o-o'  ,.oo/   'o /\.o`.
 `o`o-....o'o,-'   /o /   \o \.                       ,o..         o
   ``o-o.o--      /o /      \o.o--..          ,,,o-o'o.--o:o:o,,..:o
                 (oo(          `--o.o`o---o'o'o,o,-'''        o'o'o
                  \ o\              ``-o-o''''
   ,-o;o           \o \ 
  /o/               )o )  Carl Pilcher
 (o(               /o /                |
  \o\.       ...-o'o /             \   |
    \o`o`-o'o o,o,--'       ~~~~~~~~\~~|~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      ```o--'''                       \| /
                                       |/
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                                       |
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/other%20(water)
""", 
"""
          _                    _
        ,':`.    ,-------.   ,' `.
       ;:::::`,='   ,--.  `,'.    `.
      /:::/(,:__`    ___      )     \______
     ;:::::/( O )  ,' O )    /      /      `-.
    ;:::::( _`-'  ,'---:.   /      /          `.
    `-,---:-. `.         ` (      /  .:::.    .::.
     /_   _`.`      `._     \   _/   :::::   ;:::::
    /(_) (_) )       //--.   `-'    ::::'   :::::::.
   (        / _____,' ;   `      )  ::::    ::::::::)
    `.____,' (  _,-. /          /    `:::    `::::: \\,=.
     :        \(    /          /                   /())
      \        `---'         ,'    .::.           /
       `-.     `---'              :::::          /
          `--.      __,'         ;:::;      |   (
              `----<______.- _,  `::'     _,|    |
                         ) \<        |_,-)  /`.  |
                        /   /----(    :  | (  | :
        -hrr-          /  ,'      \   | / ,'  | |
                     ,' ,'         \  \`^"   ,' ;
                    / ,/            \  \    `^"
                   /)'               \^'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/pigs
""", 
"""
                                  _
                                 ( `.
                   _,--------.__  ))\`.
               _,-"   ,::::.    `(( (  \___
             ,'      .:::::'      \`-\ |   `-.
           ,'     ___                         \ 
          /     -'   `-.               .    ;; \ 
         :::          : \    :         ~)       )-._
         ;::          :: |   .      .  :       /::._)
        ( `:          ;  :  /: .    (  :__ .,~/_.-'
        /__ :        .__/_ (:' ,--.  `./o `.|'
       ((_\`.    `:.      `-.._    `.__`._o )
  -hrr- `-'  `""`.____,-.___/`_\______ \"\"\""`.
                            `-`       `-. ,\_\ 
                                         `-'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/pigs
""", 
"""
                         /\ 
                        /  `.
                      ,'     `.
       /`.________   (         :
       \          `. _\_______  )
        \ `.----._  `.        "`-.
         )  \     \   `       ,"__\ 
         \   \     )    ,--    (/o\\ 
     (  _ `.  `---'     ,--.    \ _)).
      `(-',-`----'     ( (O \    `--,"`-.
        `/              \ \__)    ,'   O )
        /                `--'     (  O  ,'
       (                           `--,'
        \                    `==  _.-'
         \              .____.-;-'
   -hrr-  ) `._               /
         (    |`-._\    | ,' /
          `.__|__/ "\   |'  /
                     `._|_,'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/pigs
""", 
"""
   ,.   ,.
   \.\ /,/
    Y Y f
    |. .|
   ("_, l
    ,- , \ 
   (_)(_) Y,.
    _j _j |,'  Philip Kaulfuss
   (_,(__,'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
,.
\ \   ,--.
 \.Y_f,,\ \ 
  Y._.f  `'
  l._,j
  f`-'`---.''.
  |..|  \  )'
  ||||--')))  Philip Kaulfuss
 (_)(_) ((_)

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
    ___
  ,'_  "`-.      ,-'""`-.
 ('"/"-.   \    /  ,-,.  \ 
  `'    \  ,-'-/    /  `-'
        ,-'-.      /
     __ ("|")     f
    (_)`-"---.    |
     l   ---.     j
      `---'     ,'
          \    f
           )   l
        __f _   Y
     ,'",-'"_"  l
    (,,(,,,' `   Y
         |       l
         |        \,';,
         l    ,    Y, ;
         (`._(     ),'  Philip Kaulfuss
          `.  `.  (
        ,--',--'   )
       (,,,(,,,---'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""",
"""
         ,
        /|      __
       / |   ,-~ /
      Y :|  //  /
      | jj /( .^
      >-"~"-v"
     /       Y
    jo  o    |
   ( ~T~     j
    >._-' _./
   /   "~"  |
  Y     _,  |
 /| ;-"~ _  l
/ l/ ,-"~    \ 
\//\/      .- \ 
 Y        /    Y    -Row
 l       I     !
 ]\      _\    /"\ 
(" ~----( ~   Y.  )
~~~~~~~~~~~~~~~~~~~~~~~~~~

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
       __
      / \`\          __
      |  \ `\      /`/ \ 
      \_/`\  \-"-/` /\  \ 
           |       |  \  |
           (d     b)   \_/
           /       \ 
       ,".|.'.\_/.'.|.",
      /   /\' _|_ '/\   \ 
      |  /  '-`"`-'  \  |
      | |             | |
      | \    \   /    / |
 jgs   \ \    \ /    / /
        `"`\   :   /'"`
            `""`""`

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
                              .=""--._
                 __..._    ,="_`/.--""
            ..-""__...._\"\"\"       `^"\ 
          .'  ,/_,.__.- _,       _  .`.
        .'       _.' .-';       /_\ \o|_
      .'       -" .-'  /        `o' /   \,-
      `\"\"\"""----""    (        `.--'`---'='
                       `..     .'.`-..-/`\ 
                          `";`7 'j`"--'
                          _.| |  |
                       .-'    ;  `.
                    .-'  .-   :`   ;
                 .-'_.._7___ _7   ;|.---.
                (           `"\  /--..r=`)
                 \__..--"7'`. ,`7     `}\'
       __.    .-"       /    J/}/
   .-""   \.-"        .'     `;
  :      .'         .'       ;
  ;     /          :         |       .-._
  `.   :           |         ;-.    /`. `/
    `--|           ;        /   \  ;`. ` :
      _;           ;      .'     : :  .-':
    .' \          ;  _.--'       :/ .'  /
    |  ,__     .-'\"\"\"""--.       7 /   /
    :    \`\"\"\""           `.    ' /   /
     :    J__..._           `.   ;  .'
      \    -. `-.\            `,J.-'
       `._   `._.'                   fsc
          `\"\"\""

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
         / \ 
        / _ \ 
       | / \ |
       ||   || _______
       ||   || |\     \ 
       ||   || ||\     \ 
       ||   || || \    |
       ||   || ||  \__/
       ||   || ||   ||
        \\_/ \_/ \_//
       /   _     _   \ 
      /               \ 
      |    O     O    |
      |   \  ___  /   |
     /     \ \_/ /     \ 
    /  -----  |  --\    \ 
    |     \__/|\__/ \   |
    \       |_|_|       /
     \_____       _____/
           \     /
           |     |

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
    /| |\ 
   ( |-| )
    ) " (
   (>(Y)<)
    )   (
   /     \ 
  ( (m|m) )  hjw
,-.),___.(,-.`97
`---'   `---'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
       _
      (\\ 
       \||
     __(_";
    /    \ 
   {}___)\)_
          vwc

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
 (\ 
  \\_ _/(\ 
    0 0 _\)___
  =(_T_)=     )*
    /"/   (  /
   <_<_/-<__|

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
           /\ /|
          |||| |
           \ | \ 
       _ _ /  @ @
     /    \   =>X<=
   /|      |   /
   \|     /__| |
     \_____\ \__\ 

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
   ***
  ** **
 **   **
 **   **         ****
 **   **       **   ****
 **  **       *   **   **
  **  *      *  **  ***  **
   **  *    *  **     **  *
    ** **  ** **        **
    **   **  **
   *           *
  *             *
 *    0     0    *
 *   /   @   \   *
 *   \__/ \__/   *
   *     W     *
     **     **
       *****

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
           //
         _//
        .. ~~-_
   ___m<___m___~.___            Rabbit spying over a wall...
   _|__|__|__|__|__|
   |__|__|__|__|__|_

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
* tiny rabbit* 11/96

            \\ 
             \\_
          .---(')
   jgs  o( )_-\_

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
* tiny rabbit* 11/96

            \\ 
             \\_
          .---(')
   jgs  o( )_-\_

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
* tiny rabbit* 11/96

            \\ 
             \\_
          .---(')
   jgs  o( )_-\_

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
         \\ 
          \\_
           (_)
          / )
   jgs  o( )_\_

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
         \\ 
          \\_
           (')
   jgs    / )=
        o( )_

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
         \\ 
          \\_
           (')
   jgs    / )=
        o( )_

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
  //
 (")
 UU\    Little White Rabbit
 <><>*

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
  //
 ('>
 /rr
*\))_   Rabbit  -Neil Smith-

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
   _     _
  ( |\  //|
   \|\\//\|
     /66\ 
    ((_v.)
     > "<       mic

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
             \\ 
        ,-~~~-\\_
       (        .\    -Rudrik GreyShadow-
\    / @\___(__--'
 \  /
 bink!

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
     \\ 
      \\_
   _-~~ .\ 
 ,~   )___>
@~    /    Chris Baird
 \____)

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
@@ bunny rabbit w/carrot @@  11/96

                 \     /
                 \\   //
                  )\-/(
                  /e e\ 
                 ( =T= )
                 /`---'\ 
            ____/ /___\ \ 
       \   /   '''     ```~~"--.,_
    `-._\ /                       `~~"--.,_
   ------>|                                `~~"--.,_
    _.-'/ \                            ___,,,---""~~``'
       /jgs\____,,,,....----\"\"\""~~~~````

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
                    ____     ____
                  /'    |   |    \ 
                /    /  |   | \   \ 
              /    / |  |   |  \   \ 
             :   /   |  \"\"\""   |\   \       A-ha! There is nothing better
             | /   / /^\    /^\  \  _|         than eating a BIG BIG carrot!!
              ~   | |   |  |   | | ~
                  | |__O|__|O__| |
                /~~      \/     ~~\ 
               /   (      |      )  \ 
         _--_  /,   `\___/^\___/'   \  _--_
       /~    ~\ / -____-|_|_|-____-\ /~    ~\ 
     /____--------/~~~~\---/~~~~\ -----------_____
--~~~          ^ |     |   |     |  -     :       ~:~-_     ___-----~~~~~~~~|
   /             `^-^-^'   `^-^-^'                  :  ~\ /'   ____/--------|
       --                                            ;   | /~~~------~~~~~~~~~|
 ;                                    :              :   | ----------/--------|
:                     ,                           ;   .  |---\\--------------|
 :     -                          .                  : : |______________-__|
  :              ,                 ,                :   /'~----___________|
__  \\\        ^                          ,, ;; ;; ;._-~
  ~~~-----____________________________________----~~~    jurcy

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
     _       _
    / \     / \ 
   {   }   {   }
   {   {   }   }
    \   \ /   /
     \   Y   /
     .-"`"`"-.
   ,`         `.
  /             \ 
 /               \ 
{     ;"";,       }
{  /";`'`,;       }
 \{  ;`,'`;.     /
  {  }`""`  }   /}
  {  }      {  //  cyd
  {||}      {  /
  `"'       `"'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
       /\      |\ 
      |  \    / |
      |   \  |  /
       \  _|/_ |
        /      \ 
       _|       |_
      / /(|   |)\ \ 
    /  /    _    \  \ 
   /  |   /   \   |  \ 
  /    \__\___/__/    |\ 
 |                    | \ 
 |                    |  |
  \    \            //   |
   |     \ ____  __//    |
   |               /    / -Beate Herrmann-
  /______wwww  wwww  __/

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
    \(,%%*%,_                      -%*%%,)/
  %%/*(                       /)   /)   )*\%%
 %% )\|                      (/   (/    |/( %%
  _/ #)                    __/') ('\__  (# \_
 .) ,/                   _/  /     \  \_ \, (.
 /)#(_,,,,,,,,,,,,,,,,,,,\,((,,,,,,,)),/,_)#(\ 
 b'ger

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
                     :I. ..
                    :III/ I.
                   : III  II
                  :  III .II
                  : .III III
                  : III' III
                  : III  II'
                  : `I/__L_
                ./'        ~~-.
               ."   -~~-       `.
               :    .==.         :
               |    `..b'      ___:
               |           __.`\__/__
                `.       ----   _i_----
                / `-........:`----'
              /'    ,MMMMMMM.
            :'     .MMMMMMMMm.
           :'      mMMMMMMMMMm
          /:       MMMMMMMMMMM
        /' :       MMMMMMMMMMM
      /"           `MMMMMMMMM'
     :      \       `MMMMMMM'\ 
    :'       `:      MMMMMMM: `\ 
    :         `:     `MMMMM':   `:
    :      mMMMm      MMMM' :    :
    :     mMMMMMMm    mMMm  :    :
     \    `MMMMMMm    mMMm  :   /
    /~~~   MMMMMMm    mJVm  : /'___
  :'| |   /`JMMMMm . .m96m  \      \ 
   ~~~~~~~        \_:_|   L_/~~~~~~
       Jeff Verzak

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
                                         ;\ \_            _,-_,'
                                         ::\_ \_        _/  ;;
                                         `;;;\  \_    _/  ,;;
                    _,-'\"\"\"\"\"\""-.         `.;;;   :  /   ;:;
                _,-'   ;"  " ;" `""`.__    :;;;: -----. /./
             ,-'          ;  " ";  "" ;`-._`.;;;'   .  ` (
            /;;'',  "-._   ;; "  "";   ;     \,'/\ . .  `.
         ,-';;;; `, ,`, `-.   ;"   ""   ;    ' (O ) .    (O)
        /;;;;;;;  ` ` , ,  `.  ;" \"\"\"  ;   .'   \/   .   `.;
      ,;; ;;;;;;;;  `,` ` , ,`,    '"  ;  ; ;       ; :     `.
      :;;;;;;;;;;;;;,`,  ,`,` ;  "; "   : ;: .  ...'___`... ;;
 ;`._ ;;;;; ;;;;;  ,` ` ,`,`, ' ;"  ""  : `.` .`.  ( V )  .'.
 :"",``;;;;;;;;;  ,``,  ` ` ,'   \"\"\""   ;   `-.__`._`|'_.'_-'
  `;", `-.;;;;;   ` ,`  _,-'_,-'~~~~~`-. ;":     `--~"~--'
   `-."_,--`._ _____`,-'  ~`-._         `-._::::  `._  `-.__
      ~~      `-.______,-._)_)_)            `-._:::: `-.____`--,
                 ~~~~~~   ~ ~ ~                 `-. _______-`;~
                                                   `~~~~~~~~~

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
 {&oooa,                                           ,aooo&}
 iooooooooooo                                  ooooooooooi
 qoo        ooooo ,                      ,  ooooo    oooop
 .oo   #,.           o                 o              ooo.
  oo   ^::::,           o           o         ,:#;     oo
   o     '::::,            o     o         ,::::,      o
    o       ;::::,           o o        ,:::::'       o
     o        ':::::,       o `      ,:::::'         o
       o        ';::::   o         ,:::::'         o
         o             o         ,:::::'         o
            o        o        ,:::::'          o
               o   o        ,:::::'          o
                 o       ,:::::'           o
                o      ,:::::'          o   o
               o      :::::;         o       o
              o                  o            o
             o                o                o
             o             o     o             o
             o          o           o          o
              o       o                o      o
               o   o                     o   o
                 oo    _              _   oo
               o      (0)            (0)     o
              o        -     ,o,      -       o
              o           `^OoooO^'           o This Bunny is
              o              'o'              o Really a Celtic
               o              |              o  Knot drawn By
                 o       ,o   |   o,       o    Lee Thompson-Herbert
                   o ,     ^oo^oo^     , o
                 o     o             o      o
               o         o         o          o
              o           o       o            o
             o             o    o              o
             o               o o               o
             o                o                o
              o             H   L             o
               o          U        O         o
                o             M             o
                 o o     G          V      o
                o  o          E          o  o
              o      o   !         E  o       o
           o           o             o           o
        o                o         o               o
      o                    o     o                   o
    o                        o o                      o
   o                       o     o                     o
  oo                    o           o                  oo
 oRUo                o                 o              oLoo
 oGSDo      ooooo                           ooooo    ooEoo
 o.KIRooooooo                                  ooooooooEoo
 ooooooo                                           ooooooo

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
       .
       |\ 
       ' `          __
        \ \     .-:'.-'
         ) )   / /
         \ '-'' '
         , '` -.\ 
        ./  O o  `_
         `---o--'.
          \ \|/ /     BUNNY
        .###._.'._     BOXING
       '#####'H   '
  === /'#####'HH,\ \==========
     (__.###'HHH `  )
         \ (   ) /'-'
          \-----/
          |  |  \ 
          `-- `--    kOs
          ( )  \ )
          | |  | |
          | |  | |
          '-'  `-`\.
         /  \  (    `-.
        (____)  `--._.'
        =====      ===

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
   __     __
  /_/|   |\_\ 
   |U|___|U|
   |       |
   | ,   , |
  (  = Y =  )
   |   `   |
  /|       |\ 
  \| |   | |/
 (_|_|___|_|_)
   '"'   '"'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rabbits
""", 
"""
 ~ an alligator ~  8/96

               _.'^^'.
    _      _.-' ((@)) '.   ./\/\/\/\/\/\,.---.__
 ..'o'...-'      ~~~    '~/\/\/\/\/\/\__.---.   `-._
:                          /\/\/\/\,-'              `-.__   jgs
^VvvvvvvvvvvVvVv                   |                     `-._
  ;^^^^^^^^^^^`      /             `\        /               `-._
   ```````````````'.`                `\     (                    `'-._
            .-----'`   /\              `\    )--.______.______._______`/
           (((------'``  `'--------'`(((----'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/aligators
""", 
"""
~ crocodile ~ 9/96

                     _.---._     .---.
            __...---' .---. `---'-.   `.
        .-''__.--' _.'( | )`.  `.  `._ :
      .'__-'_ .--'' ._`---'_.-.  `.   `-`.
             ~ -._ -._``---. -.    `-._   `.
                  ~ -.._ _ _ _ ..-_ `.  `-._``--.._
                               -~ -._  `-.  -. `-._``--.._.--''.
                                    ~ ~-.__     -._  `-.__   `. `.
                                      jgs ~~ ~---...__ _    ._ .` `.
                                                      ~  ~--.....--~

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/aligators
""", 
"""
            .-._   _ _ _ _ _ _ _ _
 .-''-.__.-'00  '-' ' ' ' ' ' ' ' '-.
'.___ '    .   .--_'-' '-' '-' _'-' '._
 V: V 'vv-'   '_   '.       .'  _..' '.'.
   '=.____.=_.--'   :_.__.__:_   '.   : :
           (((____.-'        '-.  /   : :
 snd                         (((-'\ .' /
                           _____..'  .'
                          '-._____.-'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/aligators
""", 
"""
                                             ___.-----.______
                                   ___.-----'::::::::::::::::`---.___
                _.--._            (:::;,-----'~~~~~`----::::::::::.. `-.
   _          .'_---. `--.__       `~~'                 `~`--.:::::`..  `..
  ; `-.____.-' ' {0} ` `--._`---.____                         `:::::::: : ::
 :_^              ~   `--.___ `----.__`----.____                ~::::::.`;':
  :`--.__,-----.___(         `---.___ `---.___  `----.___         ~|;:,' : |
   `-.___,---.____     _,        ._  `----.____ `----.__ `-----.___;--'  ; :
                  `---' `.  `._    `))  ,  , , `----.____.----.____   --' :|
                        / `,--.\    `.` `  ` ` ,   ,  ,     _.--   `-----'|'
 _.~~~~~~._____    __./'_/'     :   .:----.___ ` ` ` ``  .-'      , ,  :::'
                 ///--\;  ____  :   :'    ____`---.___.--::     , ` ` ::'
                 `'           _.'   (    /______     (   `-._   `-._,-'
    ()  ()                 .-' __.-//     /_______---'       `-._   `.
  * *(o)'      ~~~        /////    `'       ~~~~~~      ~~ ______;   ::.
  `\ )( /*                `'`'                            /_______   _.'
    {()}      ,     ~~~                  ~~~~~~~~           /___.---'  --__
     !|       `                                              ~~~
  ~~~~~~~~
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/aligators
""", 
"""
        ('(
          \ \                    " Help !!!   Alligators...."
       d@b | |
       @@@@' |
   ('(  Y@P   `--..
    \ `--'      .' `.
     `---....__/    |
               /   . \                     /^^^^\ 
             /  .'\  \       /^^\________/0     \ 
              \  \  \  \     (                    `~+++,,_____,,++~^^^^^^^
  -unknown-    \  \  \__\  ...V^V^V^V^V^V^\...............................
               _`--` `--'     Allen Mullen
              `---'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/aligators
""", 
"""
           _
            \ 
             \         ___  ___  ___  _ _  ___   _  ___  _ _ _  _  _ _
             |\       / __>|_ _|| __>| | || __> | || . \| | | || || \ |
             /|       \__ \ | | | _> | ' || _>  | ||   /| | | || ||   |
            /'|       <___/ |_| |___>|__/ |___> |_||_\_\|__/_/ |_||_\_|
          ,' //                         We will
        ,'..`/                         Miss You
       /   '/                Still I want to see the Video             _...._.---._
     /:   ,'                                                         .' ,--. ,--.  \ 
   ,'    ,                                                           | /... /...|  |,..._
  ,'    /                                   _..---------..__         \.\_O_/  O /  '     \ 
 .'  _, /                 .---..._       ,-'  __.-.....__   '-  ___.-----._'---'     ,'  |
 |-`'  (                  |       `--..,'_,-''   '.     `''"-._( .-.'.--.         _.'   /
 |      \                 |  ,.__     /,'  |      |      \     \ | / |  /      ,,'  __ /
 |     .`.               /  .'  _)--..'    |       |     '\     \`  ..--:`     _.--' \ 
 |   .'  .-.__           |  |,-' _.-\      |       |      |     |`\''''''''_.-'   ,' (__...'
  \         ,-`''-- =--::|   \-'|    |     |       |      |     | `'.....-' .,:-'  |  \ 
   `.    ,  /  /     '`. |   |  |    |     |       |      |     |  \__.-` `..      \   \ 
    '.  /  /  /         '|   |  |    [     |       |       |    |    ,       '._    |  |fsr
      `.  /  | .--------'    `-. |   '     |       |       |    |,L______       `--..   \ 
        ``.  | \               |-^---''".  |      |       .'    |.'      ``-..._         \ 
           `.-..\.__...---....,'-.....--'`'"-........_____|.. `'                `'`--..../

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/aligators
""", 
"""
     _
   .~q`,
  {__,  \ 
      \' \ 
       \  \ 
        \  \ 
         \  `._            __.__
          \    ~-._  _.==~~     ~~--.._
           \        '                  ~-.
            \      _-   -_                `.
             \    /       }        .-    .  \ 
              `. |      /  }      (       ;  \ 
                `|     /  /       (       :   '\ 
                 \    |  /        |      /       \    -r.millward-
                  |     /`-.______.\     |^-.      \ 
                  |   |/           (     |   `.      \_
                  |   ||            ~\   \      '._    `-.._____..----..___
                  |   |/             _\   \         ~-.__________.-~~~~~~~~~'''
                .o'___/            .o______}

Brachiosaur


            " Briachiosaurus had little to do,
              But stand with its head in the treetops and chew,
              It nibbled the leaves that were tender and green,
              It was a perpetual eating machine."
                                       -- Jack Prelutsky

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/dinosaurs
""", 
"""
                                                              __
                    HOW DINOSAURS BECAME EXTINCT!       _   .'.-'.
                                                      .'-'. ||  ||
                                                  _   || || :\_.'/
                               .-.       ___    .'-.\ :\_'/  `-'`
                              _L o|_.-'``   '-. ;\_'/  `-`
                            _f o\-'          /_. `-`
                        ,-'` '-'              /
                       /                    .'
                      |                   .'                .--.
                       \              _.-'                  `-' |
                        |        __.-'                     .- '`
                       ,-.     "`|                        |
                      /  |       |                         '-.
                      \_ |       |              _  .-.      _ "
                       /`|       |             ' . ' |  _.-"7P`
                      |  |       ;              \ \| |-' _.-"`
                      \_ |        ;           _,-'`| |.-'
                       /`|        |          ()_,.-j f.-.
                      |  |        |           .'`) (_.-.j
                      \_ ;        ;          (  <   (__.'
                       / '        ;           \  '    /
                      |   |        \          /      ;
                       \_ |         `'--.___.'       |
                      /` .'                          ;
                      \.'                  _        /
                      /                     `.    .'
                    .'                        \.-'
                   /                           `.
                  ;                              \ 
                  |                               '
                  '         /                      \ 
                 ;         /                        \ 
                 |        Y                          ;
                 ;         \                          .
                 '        t-'                         ;
                  \  \  \  \                          ;
                  7`._f_.`-'                          |
                  \_|                                 |
                  /`|                                 ;
                  \_;                                 '
     .-.          f  '                               /
  .'  ,-`          \_|                              /
 /   |     _  __ .-7 /                            .'
 |    `-.r'_'Y__\L.-'                          _.'
 '                        ;              _..--' |
  `.                      ,              |      '.
    `-._                 /|              '.       \mx________
        `'"--..._____..-' '--...__         \------'
  _______________________________ `'-------'__________

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/dinosaurs
""", 
"""
                                            (:;( :;;::..      ..  )
       ...::::....   ..          ___________ ((            :;;:  )
                              ,'" .       . "`.( :;; : ; ;;: ;;.:)       ..
            ____,----'''""``-/                 \     ;  : ___  : )  .
      --=;""              ,-'"`'""`.    .       |_;; |,',' __`.;; )
  ..      `\"\"\"---.._____,(_,-. ,'"`.        .   j_`.)|;/ ,';;`.)  )
                         _|o_,|o   |           /__\     /,--._ ' )    ..::..
               _,----'\"\"\"      `._,'          |';;;j   (/  __ \ )
       _     ,'        .               .      |'`;;      ,'o;`/|
 --=;'" `;=-/.    .                           | ( ;-----;;;;) )j
  .. "`-'  (____________,,---')    .          |  j     . l)  o        _,--._
             l__ \/  \/                       | j . :  :. l   .  _,-'"__    `-._
               \    .     .          .    .   |/  :     ;. \      \"\"\""  \"\"\"\"\"\"'
         ..     `._                           |: .;  .  :;. \ 
                   `"----......._          .  |; :;  :  ::;. \            .
                                 `.   .       |; ;; .:  ; :;; \      ...
                       ..         j           l:.;  :; . ;  :;.`.
__                               /             \:: .;: :  ;; :;. `.     _____,
  ```-----....._________________f     (  .  \   |__;:_______;,,,,--`--'';;;;::
  .    .  .  .  .....:::::::;;;;|      \     |  |;;;;;;;;;;;;;;;;;;::::::::::.
         .  .   . .  .....:::::;|   .   )    j  |:::::::::::::::::::::::::.. .
    .        .     .  . . ...:::|      /    /   |:::::::::::::::::::::... . .
               .    .  . .   ...j     /    /    |:::::::::::::::.... . .
        .          .       .  .f . ,-'  . /     |................ . .     .
  .                    .    .  |  / ,   ,'  .   |. . . . . . . . .     .
        .                    . | (_/| | l       |.   .   .   .    .
               .           .   |  V l_j\_)      |  .       .              .
    .                          | .   V  V.      |                 .
                    .          |                |     -=> Philip Kaulfuss <=-

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/dinosaurs
""", 
"""
              _/\|\_\_
            _| .-     \___
    ________\ /    )     o`o__________  [nabis]
            </ ) _/_ )-.___/
           /  /\(  (/
           | (__`'` '`
            '--.)

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/dinosaurs
""", 
"""
               __
              / _)
     _/\/\/\_/ /
   _|         /
 _|  (  | (  |
/__.-'|_|--|_|

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/dinosaurs
""", 
"""
               __
              / _)
     _.----._/ /
    /         /
 __/ (  | (  |
/__.-'|_|--|_|

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/dinosaurs
""", 
"""
            __
           / _)
    .-^^^-/ /
 __/       /
<__.|_|-|_|

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/dinosaurs
""", 
"""
      .----.
     .'  \__ '.
    |   __|  _ :
    V\/(0I0\/ |/
       \ : /  '
       (oYo)
       /` `\__
     _|  _ Vuu: ,
    |uV\/ \| \_/|
    :      /\   :
snd  \   -'    /
      '-.___.-'  <>
     =        <;

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/dinosaurs
""", 
"""
                                            (:;( :;;::..      ..  )
       ...::::....   ..          ___________ ((            :;;:  )
                              ,'" .       . "`.( :;; : ; ;;: ;;.:)       ..
            ____,----'''""``-/                 \     ;  : ___  : )  .
      --=;""              ,-'"`'""`.    .       |_;; |,',' __`.;; )
  ..      `\"\"\"---.._____,(_,-. ,'"`.        .   j_`.)|;/ ,';;`.)  )
                         _|o_,|o   |           /__\     /,--._ ' )    ..::..
               _,----'\"\"\"      `._,'          |';;;j   (/  __ \ )
       _     ,'        .               .      |'`;;      ,'o;`/|
 --=;'" `;=-/.    .                           | ( ;-----;;;;) )j
  .. "`-'  (____________,,---')    .          |  j     . l)  o        _,--._
             l__ \/  \/                       | j . :  :. l   .  _,-'"__    `-.
               \    .     .          .    .   |/  :     ;. \      \"\"\""  \"\"\"\"\"\"'
         ..     `._                           |: .;  .  :;. \ 
                   `"----......._          .  |; :;  :  ::;. \            .
                                 `.   .       |; ;; .:  ; :;; \      ...
                       ..         j           l:.;  :; . ;  :;.`.
__                               /             \:: .;: :  ;; :;. `.     _____,
  ```-----....._________________f     (  .  \   |__;:_______;,,,,--`--'';;;;::
  .    .  .  .  .....:::::::;;;;|      \     |  |;;;;;;;;;;;;;;;;;;::::::::::.
         .  .   . .  .....:::::;|   .   )    j  |:::::::::::::::::::::::::.. .
    .        .     .  . . ...:::|      /    /   |:::::::::::::::::::::... . .
               .    .  . .   ...j     /    /    |:::::::::::::::.... . .
        .          .       .  .| . ,-'  . /     |................ . .     .
  .                    .    .  |  / ,   ,'  .   |. . . . . . . . .     .
        .                    . | (_/| | l       |.   .   .   .    .
               .           .   |  V l_j\_)      |  .       .              .
    .                          | .   V  V.      |                 .
        "Dino"      .          |                |     -=> Philip Kaulfuss <=-

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/dinosaurs
""", 
"""
                              *                    .-=-.               *
              *   .                 +           .-"     "-.                   *
    +.                `   +                    :           :
             ,                             '  :             :         *       *
                      *           ,           :             :
       ,                   -              ,    :           :
                                                '.       .'     +
                                                  '-._.-'              '
                       `            `

                                                                  ./=/-.\ 
      ,.=.__'i '=\._  /-' -.._.i'- .__=^.^/+._ =\._  /=,__.-=/..-'        '-.
  .-'\=    '=.  .-' '/       ._y._     ./     _ ._.-' '            ._            - .
 '                  .._+  .=\  ._=/   \=. \=.  '                    \'-. ._=/'-..
     '.__/='     .-t    '-.'       /-         '-      .-'""-.    /\=..-/=  p ._"
              \.=   '\=.                           .-'       :     '. . /()'. -\ 
      =/    ='             _.--.._               .'         o o     =/()   : \=.-=
    .'  '-/'           .--'       '--..       .-'   ..--._     :   /=   \ / ()=\  '
                     .'                '-.._.'    .'      '_   :  =/()  : :  ()\=
                   .'                           .'          :__.   '    \ /
                  :                          .-'                       :   :
                 :                        .-'                           \ /
          /=,.   :                       :             .,\=      .; i   : :
  fsc            :                     .'          ,--'      /=-.    .  \ /
           'j    '     _            .-:    ,-=/        =\.          t  :   :
             '.   \  !  :--..__.   : !                                  \ /
              :    :  :  '.     \  ! '-.      .'\           ,f'         : :
          ,\=.'    :.  '.u'      i  '-.u                   '   :=/      \ /    o
   .               '.uuu'         '.uu'              .-=/           .  :   :  '|v'
 /' '.-;\.  ,-/=                                                  '\|.- \ /
                        .=       \=,_      /[-'            '/=              ()
                    .-'/   /='  '[       '

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/dinosaurs
""", 
"""
                              *                    .-=-.               *
              *   .                 +           .-"     "-.                   *
    +.                `   +                    :           :
             ,                             '  :             :         *       *
                      *           ,           :             :
       ,                   -              ,    :           :
                                                '.       .'     +
                                                  '-._.-'              '
                       `            `

                                                                  ./=/-.\ 
      ,.=.__'i '=\._  /-' -.._.i'- .__=^.^/+._ =\._  /=,__.-=/..-'        '-.
  .-'\=    '=.  .-' '/       ._y._     ./     _ ._.-' '            ._            - .
 '                  .._+  .=\  ._=/   \=. \=.  '                    \'-. ._=/'-..
     '.__/='     .-t    '-.'       /-         '-      .-'""-.    /\=..-/=  p ._"
              \.=   '\=.                           .-'       :     '. . /()'. -\ 
      =/    ='             _.--.._               .'         o o     =/()   : \=.-=
    .'  '-/'           .--'       '--..       .-'   ..--._     :   /=   \ / ()=\  '
                     .'                '-.._.'    .'      '_   :  =/()  : :  ()\=
                   .'                           .'          :__.   '    \ /
                  :                          .-'                       :   :
                 :                        .-'                           \ /
          /=,.   :                       :             .,\=      .; i   : :
  fsc            :                     .'          ,--'      /=-.    .  \ /
           'j    '     _            .-:    ,-=/        =\.          t  :   :
             '.   \  !  :--..__.   : !                                  \ /
              :    :  :  '.     \  ! '-.      .'\           ,f'         : :
          ,\=.'    :.  '.u'      i  '-.u                   '   :=/      \ /    o
   .               '.uuu'         '.uu'              .-=/           .  :   :  '|v'
 /' '.-;\.  ,-/=                                                  '\|.- \ /
                        .=       \=,_      /[-'            '/=              ()
                    .-'/   /='  '[       '

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/dinosaurs
""", 
"""
  *                               *     _
       /\     *            ___.       /  `)
   *  //\\    /\          ///\\      / /
     ///\\\  //\\/\      ////\\\    / /     /\ 
    ////\\\\///\\/\\.-~~-.///\\\\  / /     //\\ 
   /////\\\\///\\/         `\\\\\\/ /     ///\\ 
  //////\\\\// /            `\\\\/ /     ////\\ 
 ///////\\\\\//               `~` /\    /////\\ 
////////\\\\\/      ,_____,   ,-~ \\\__//////\\\ 
////////\\\\/  /~|  |/////|  |\\\\\\\\@//jro/\\ 
//<           / /|__|/////|__|///////~|~/////\\ 

~~~     ~~   ` ~   ..   ~  ~    .     ~` `   '.
~ _  -  -~.    .'   .`  ~ .,    '.    ~~ .  '.

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/dinosaurs
""", 
"""
                                _._
                              _/:|:
                             /||||||.
                             ||||||||.
                            /|||||||||:
                           /|||||||||||
                          .|||||||||||||
                          | ||||||||||||:
                        _/| |||||||||||||:_=---.._
                        | | |||||:'''':||  '~-._  '-.
                      _/| | ||'         '-._   _:    ;
                      | | | '               '~~     _;
                      | '                _.=._    _-~
                   _.~                  {     '-_'
           _.--=.-~       _.._          {_       }
       _.-~   @-,        {    '-._     _. '~==+  |
      ('          }       \_      \_.=~       |  |
      `,,,,,,,'  /_         ~-_    )         <_oo_>
        `-----~~/ /'===...===' +   /
               <_oo_>         /  //
                             /  //
                            <_oo_>      "Dimetrodon"
Rodman

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/dinosaurs
""", 
"""
                                  ___......__             _
                              _.-'           ~-_       _.=a~~-_
      --=====-.-.-_----------~   .--.       _   -.__.-~ ( ___==>
                    '''--...__  (    \ \\\ { )       _.-~
                              =_ ~_  \\-~~~//~~~~-=-~
                               |-=-~_ \\   \\ 
                               |_/   =. )   ~}
                               |}      ||
                              //       ||
                            _//        {{
       "Hypsilophodon"   '='~'          \\_
                                         ~~'
Rodman

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/dinosaurs
""", 
"""
                           /~~~~~~~~~~~~\_
       _+=+_             _[~  /~~~~~~~~~~~~\_
      {''|''}         [~~~    [~   /~~~~~~~~~\_
       ''':-'~[~[~'~[~  ((++     [~  _/~~~~~~~~\_
            '=_   [    ,==, ((++    [    /~~~~~~~\-~~~-.
               ~-_ _=+-(   )/   ((++  .~~~.[~~~~(  {@} \`.
                       /   }\ /     (     }     (   .   ''}
                      (  .+   \ /  //     )    / .,  ''''/
                      \\  \     \ (   .+~~\_  /.= /'''''
                      <'_V_'>      \\  \    ~~~~~~\\  \ 
                                    \\  \          \\  \ 
                                    <'_V_'>        <'_V_'>   "Ankylosaur"
Rodman

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/dinosaurs
""", 
"""
                            .       .
                           / `.   .' \ 
                   .---.  <    > <    >  .---.
                   |    \  \ - ~ ~ - /  /    |
                    ~-..-~             ~-..-~
                \~~~\.'                    `./~~~/
                 \__/                        \__/
                  /                  .-    .  \ 
           _._ _.-    .-~ ~-.       /       }   \/~~~/
       _.-'q  }~     /       }     {        ;    \__/
      {'__,  /      (       /      {       /      `. ,~~|   .     .
       `''''='~~-.__(      /_      |      /- _      `..-'   \\   //
                   / \   =/  ~~--~~{    ./|    ~-.     `-..__\\_//_.-'
                  {   \  +\         \  =\ (        ~ - . _ _ _..---~
                  |  | {   }         \   \_\ 
                 '---.o___,'       .o___,'     "Stegosaurus"
Rodman

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/dinosaurs
""", 
"""
                                 <\              _
                                  \\          _/{
                           _       \\       _-   -_
                         /{        / `\   _-     - -_
                       _~  =      ( @  \ -        -  -_
                     _- -   ~-_   \( =\ \           -  -_
                   _~  -       ~_ | 1 :\ \      _-~-_ -  -_
                 _-   -          ~  |V: \ \  _-~     ~-_-  -_
              _-~   -            /  | :  \ \            ~-_- -_
           _-~    -   _.._      {   | : _-``               ~- _-_
        _-~   -__..--~    ~-_  {   : \:}
      =~__.--~~              ~-_\  :  /
                                 \ : /__
                                //`Y'--\\ 
                               <+       \\ 
                                \\      WWW      "Pterodactyl"
                                '
Rodman

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/dinosaurs
""", 
"""
                           _
                        __~a~_
                        ~~;  ~_
          _                ~  ~_                _
         '_\;__._._._._._._]   ~_._._._._._.__;/_`
         '(/'/'/'/'|'|'|'| (    )|'|'|'|'\'\'\'\)'
         (/ / / /, | | | |(/    \) | | | ,\ \ \ \)
        (/ / / / / | | | ~(/    \) ~ | | \ \ \ \ \)
       (/ / / / /  ~ ~ ~   (/  \)    ~ ~  \ \ \ \ \)
      (/ / / / ~          / (||)|          ~ \ \ \ \)
      ~ / / ~            M  /||\M             ~ \ \ ~
       ~ ~                  /||\                 ~ ~
                           //||\\ 
                           //||\\ 
                           //||\\ 
                           '/||\'        "Archaeopteryx"
Rodman

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/dinosaurs
""", 
"""
                                         _..-=~=-._
                                    _.-~'          ~.
                        __..---~~~~~                 ~.
                   _.-~~                      _.._     ~.
               _ -~_                         /    \      ;
              ( ` '@)                       {      |      :
              /                             |      |      :
             /     /}         (  )          |      |     .-
            /     //-=-~-_-_  |  |          \      ;    .'
           /     //     | =._-|  }/ / / /_.==\     ; _.'   *
          ( oo  //|     = )  ~| /.__..-='|    \    :'     **
           ====||*|    / /    + )    \   |_.-~`\   :      |**
              |*| *   / /    / /      \  |     ([ ])     /|||(
          *    |*    /_/    / /       (  ]     `/ \'     /|||_
         **(*   |   (((|   /_/      __/_/__    -| |--    _|_|__
         *|\|             (((|      -----     __|_|__
      __/||||__            '''                 -----
        _||_|__                                           "Maiasaur"
Rodman

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/dinosaurs
""", 
"""
                       _..--+~/@-~--.
                   _-=~      (  .   '
                _-~     _.--=.\ \''''
              _~      _-       \ \_\ 
             =      _=          '--'
            '      =                             .
           :      :       ____                   '=_. ___
      ___  |      ;                            ____ '~--.~.
           ;      ;                               _____  } |
        ___=       \ ___ __     __..-...__           ___/__/__
           :        =_     _.-~~          ~~--.__
      _____ \         ~-+-~                   ___~=_______
           ~@#~~ == ...______ __ ___ _--~~--_                  "Pleisiosaur"
Rodman

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/dinosaurs
""", 
"""
         _
       .~q`,
      {__,  \ 
          \' \ 
           \  \ 
            \  \ 
             \  `._            __.__
              \    ~-._  _.==~~     ~~--.._
               \        '                  ~-.
                \      _-   -_                `.
                 \    /       }        .-    .  \ 
                  `. |      /  }      (       ;  \ 
                    `|     /  /       (       :   '\ 
                     \    |  /        |      /       \ 
                      |     /`-.______.\     |~-.      \ 
                      |   |/           (     |   `.      \_
                      |   ||            ~\   \      '._    `-.._____..----..___
                      |   |/             _\   \         ~-.__________.-~~~~~~~~~'''
      "Brachiosaur" .o'___/            .o______}
Rodman

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/dinosaurs
""", 
"""
                _
               //
              //
           __/(
       _.~-a  ~-.
      {_____)    `.           _..=~~~~=._
            ~-_    \      _.=~           '=.
               \    `._.=~            .=.   :=._
                -         __         (   \   : \)
                 ~.      (  }       (     |   : :
                   `:     \ \        \    |\   ; :
                     \     \ }        \   / |  ;  }
                      `-.__//__.==~~=._\ (_/  ;  ;
                          //           | |/  ;  ;
                         {{       _____|_/ ;   ;        *     ___
                          `      ---- _=.=`   ~ _____   ||*    ____
                                  __:='    .='     ___\\||/___
      "Parasaurolophus"       ..:~____.==''
Rodman

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/dinosaurs
""", 
"""
                                             .--.
                                            {(~~)}
                           __..._         _.''''a`,._
                       _.-'      '~-._.-~~     (  .__}
                    _-~                       _.`--j|
                 _-~     _         /~\    _.-~     &|
              _-~     ,-~ ~-.      \\ ) .~
            .'       {       )      \\|'
          .'         {       /  _.-' |:
        .'            \     /.-'     \\ 
      .'        __.-~.=\   /          `}
      ;      _.-~   / ./ |  }
      {    _.'     / /   | /
      {    =      {=+__  | :
      :   :_      `-- = \,_`-,.
       `.   '=,_
          '-.___'_::='         "Corythosaur"
Rodman

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/dinosaurs
""", 
"""
                            __.--'~~~~~`--.
         ..       __.    .-~               ~-.
         ((\     /   `}.~                     `.
          \\\  .{     }               /     \   \ 
      (\   \\~~       }              |       }   \ 
       \`.-~ -@~     }  ,-,.         |       )    \ 
       (___     ) _}  (    :        |    / /      `._
        `----._-~.     _\ \ |_       \   / /-.__     `._
               ~~----~~  \ \| ~~--~~~(  + /     ~-._    ~-._
                         /  /         \  \          ~--.,___~_-_.
                      __/  /          _\  )
                    .<___.'         .<___/    "Triceratops"
Rodman

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/dinosaurs
""", 
"""
@@ gecko/skink @@  11/96
       __  ,
      (' \ \ 
       \ \\/
     '\/\ \\ 
         \ \\/\,
          \ \\ 
          /\ \\ 
          \ `\\\ 
          '   `\\ 
     jgs        \\ 
                 \\ 
                  \\    ,
                   `---'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/lizards
""", 
"""
       __ \/_
      (' \`\ 
   _\, \ \\/
    /`\/\ \\ 
         \ \\ 
          \ \\/\/_
          /\ \\'\ 
        __\ `\\\ 
         /|`  `\\ 
                \\ 
   jgs           \\ 
                  \\    ,
                   `---'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/lizards
""", 
"""
         _
        : `            _..-=-=-=-.._.--.
         `-._ ___,..-'" -~~`         __')
 jgs         `'"---'"`>>"'~~"~"~~>>'`
 =====================```========```========

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/lizards
""", 
"""
    0--0^^^^^^^^^^^^\________
    \__/||-------||---------~  Glo Pearl
        ``       ``

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/lizards
""", 
"""
                                           ^      ^     ^
                                           ) '.   ) '.  ) '.   ^
                                     ^.   / _..;--\"\"\"""---..;  ) '.
                                )\   ) ';-""                 "-""--.._
                            )\_/..'-""                                ".
                   __...---\"\"\"                                     ()   "
        ___...---""                                        .             )
 .--\"\"\""                      .     ,                       )       _..-"
(_______________________d"".  "d   ,db_________..--".      /___r".""______
                        b,  \  P  ,d'               L     (  d'  ;  AZC
                         Y,  \/   p'                 '.    'P" ,P'
                         .p      /                     b,      <_
                       _-"      <_                     "b        '-_
                    .-'   .       '-_                  d"     _.._  )
                  ."  _.-"d  d*-.._  )                d" d\   \   ""
                   "-"   P' d'     ""                d" ,P P   b
                        d' P"                        ; d"  'Y, 'b
                       '_."                           "     'b._'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/lizards
""", 
"""
                                           ^      ^     ^
                                           ) '.   ) '.  ) '.   ^
                                     ^.   / _..;--\"\"\"""---..;  ) '.
                                )\   ) ';-""                 "-""--.._
                            )\_/..'-""                                ".
                   __...---\"\"\"                                     ()   "
        ___...---""                                        .             )
 .--\"\"\""                      .     ,                       )       _..-"
(_______________________d"".  "d   ,db_________..--".      /___r".""______
                        b,  \  P  ,d'               L     (  d'  ;  AZC
                         Y,  \/   p'                 '.    'P" ,P'
                         .p      /                     b,      <_
                       _-"      <_                     "b        '-_
                    .-'   .       '-_                  d"     _.._  )
                  ."  _.-"d  d*-.._  )                d" d\   \   ""
                   "-"   P' d'     ""                d" ,P P   b
                        d' P"                        ; d"  'Y, 'b
                       '_."                           "     'b._'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/lizards
""", 
"""
    _.-~~-.__
 _-~ _-=-_   ''-,,
('___ ~~~   0     ~''-_,,,,,,,,,,,,,,,,
 \~~~~~~--'                            '''''''--,,,,
  ~`-,_      ()                                     '''',,,
       '-,_      \                           /             '', _~/|
  ,.       \||/~--\ \_________              / /______...---.  ;  /
  \ ~~~~~~~~~~~~~  \ )~~------~`~~~~~~~~~~~( /----         /,'/ /
   |   -           / /                      \ \           /;/  /
  / -             / /                        / \         /;/  / -.
 /         __.---/  \__                     /, /|       |:|    \  \ 
/_.~`-----~      \.  \ ~~~~~~~~~~~~~---~`---\\\\ \---__ \:\    /  /
                  `\\\`                     ' \\' '    --\'\, /  /
                                               '\,        ~-_'''"

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/lizards
""", 
"""
                       )/_
             _.--..---"-,--c_
        \L..'           ._O__)_
,-.     _.+  _  \..--( /           a:f
  `\.-''__.-' \ (     \_
    `'''       `\__   /\ 
                ')

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/lizards
""", 
"""
            /^\/^\ 
          _|__|  O|
 \/     /~     \_/ \ 
  \____|__________/  \ 
         \_______      \ 
                 `\     \                 \ 
                   |     |                  \ 
                  /      /                    \ 
                 /     /                       \\ 
               /      /                         \ \ 
              /     /                            \  \ 
            /     /             _----_            \   \ 
           /     /           _-~      ~-_         |   |
          (      (        _-~    _--_    ~-_     _/   |
           \      ~-____-~    _-~    ~-_    ~-_-~    /
             ~-_           _-~          ~-_       _-~   - jurcy -
                ~--______-~                ~-___-~

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/snakes
""", 
"""
@@ snake @@  11/96
                          _,..,,,_
                     '``````^~"-,_`"-,_
       .-~c~-.                    `~:. ^-.
   `~~~-.c    ;                      `:.  `-,     _.-~~^^~:.
         `.   ;      _,--~~~~-._       `:.   ~. .~          `.
          .` ;'   .:`           `:       `:.   `    _.:-,.    `.
        .' .:   :'    _.-~^~-.    `.       `..'   .:      `.    '
       :  .' _:'   .-'        `.    :.     .:   .'`.        :    ;
  jgs  :  `-'   .:'             `.    `^~~^`   .:.  `.      ;    ;
        `-.__,-~                  ~-.        ,' ':    '.__.`    :'
                                     ~--..--'     ':.         .:'
                                                     ':..___.:'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/snakes
""", 
"""
   _________         _________
  /         \       /         \   Normand
 /  /~~~~~\  \     /  /~~~~~\  \  Veilleux
 |  |     |  |     |  |     |  |
 |  |     |  |     |  |     |  |
 |  |     |  |     |  |     |  |         /
 |  |     |  |     |  |     |  |       //
(o  o)    \  \_____/  /     \  \_____/ /
 \__/      \         /       \        /
  |         ~~~~~~~~~         ~~~~~~~~
  ^

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/snakes
""", 
"""
                          ____
 ________________________/ O  \___/
<_____________________________/   \ 

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/snakes
""", 
"""
                           ____
  ________________________/ O  \___/
 <_/_\_/_\_/_\_/_\_/_\_/_______/   \ 

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/snakes
""", 
"""
                           ____
  ________________________/ O  \___/
 <%%%%%%%%%%%%%%%%%%%%%%%%_____/   \ 

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/snakes
""", 
"""
                           ____
  ________________________/ O  \___/
 <_O_O_O_O_O_O_O_O_O_O_O_O_____/   \ 

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/snakes
""", 
"""
                           ____
  ________________________/ O  \___/
 <_8_8_8_8_8_8_8_8_8_8_8_8_____/   \ 

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/snakes
""", 
"""
                           ____
  ________________________/ O  \___/
 <888888888888888888888888_____/   \ 

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/snakes
""", 
"""
fluteplayer + snake
        ___
      ,'._,`.
     (-.___.-)
     (-.___.-)
     `-.___.-'
      ((  @ @|              .            __
       \   ` |         ,\   |`.    @|   |  |      _.-._
      __`.`=-=mm===mm:: |   | |`.   |   |  |    ,'=` '=`.
     (    `-'|:/  /:/  `/  @| | |   |, @| @|   /---)W(---\ 
      \ \   / /  / /         @| |   '         (----| |----) ,~
      |\ \ / /| / /            @|              \---| |---/  |
      | \ V /||/ /                              `.-| |-,'   |
      |  `-' |V /                                 \| |/    @'
      |    , |-'                                 __| |__
      |    .;: _,-.                         ,--""..| |..""--.
      ;;:::' "    )                        (`--::__|_|__::--')
    ,-"      _,  /                          \`--...___...--'/
   (    -:--'/  /                           /`--...___...--'\ 
    "-._  `"'._/                           /`---...___...---'\ 
        "-._   "---.                      (`---....___....---')
         .' ",._ ,' )                     |`---....___....---'|
         /`._|  `|  |                     (`---....___....---')
        (   \    |  /                      \`---...___...---'/
         `.  `,  ^""                        `:--...___...--;'
           `.,'               hh              `-._______.-'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/snakes
""", 
"""
               ______
          _.-""      ""-._
       .-'                `-.
     .'      __.----.__      `.
    /     .-"          "-.     \ 
   /    .'                `.    \ 
  J    /                    \    L
  F   J                      L   J
 J    F                      J    L
 |   J                        L   |
 |   |                        |   |
 |   J                        F   |
 J    L                      J    F
  L   J   .-\"\"\""-.           F   J
  J    \ /        \   __    /    F
   \    (|)(|)_   .-'".'  .'    /
    \    \   /_>-'  .<_.-'     /
     `.   `-'     .'         .'
       `--.|___.-'`._    _.-'
           ^         \"\"\""

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/snakes
""", 
"""
                               ___-------___
                           _-~~             ~~-_
                        _-~                    /~-_
     /^\__/^\         /~  \                   /    \ 
   /|  O|| O|        /      \_______________/        \ 
  | |___||__|      /       /                \          \ 
  |          \    /      /                    \          \ 
  |   (_______) /______/                        \_________ \ 
  |         / /         \                      /            \ 
   \         \^\\         \                  /               \     /
     \         ||           \______________/      _-_       //\__//
       \       ||------_-~~-_ ------------- \ --/~   ~\    || __/
         ~-----||====/~     |==================|       |/~~~~~
          (_(__/  ./     /                    \_\      \.
                 (_(___/                         \_____)_)-jurcy

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/turtles
""", 
"""
                       ____,------------------,______
                   ___/    \            /            \_____
                __/         \__________/              \___ \___
  ,^------.____/\           /          \              /   `----\_
  | (O))      /  \_________/            \____________/         \ \ 
  \_____,--' /   /         \            /            \          \ \ 
    \___,---|___/_______,---`----------'----,_________\__________\_\ 
              /  :__________________________/  :___________________/
             /   :          /   :          /   :          /   :
            /    :         /    :         /    :         /    :
        (~~~     )     (~~~     )     (~~~     )     (~~~     )
         ~~~~~~~~       ~~~~~~~~       ~~~~~~~~       ~~~~~~~~

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/turtles
""", 
"""
              __....__
         .-~~/  \__/  \~~-.
        /_/``\__/  \__/``\_\.--.
       /  \__/  \__/  \__/  \   o`.
   `==/\__/__\__/__\__/__\__/\`'--'
 jgs  ~/__/__/^^^^^^^^\__\__\~

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/turtles
""", 
"""
          _  .----.
         (_\/      \_,
    jgs    'uu----uu~'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/turtles
""", 
"""
                     .-.-.-._
                   .~\ /~\_/ \.
                 .~\_/~\_/ \_/~\.
               .~\_/ \_/ \_/ \_/~\ 
    .----.    /\_/ \_/ \_/ \_/ \_/\ 
   (o)(o)`\_ /_/ \_/ \_/ \_/ \_/ \_\ 
   |      , |/ \_/ \_/ \_/ \_/ \_/ \\.  _.;
    \ "  /  |\_/ \_/ \_/ \_/ \_/ \_/~\"'_.'
     `--'`--\/_\-/-\_/-\-/ \_/-\_/_\.-""
              /~/\"\"\"| |\"\"\"""| |'"\~\ 
   jgs      _/ /   _| |    _| |   \ \ 
           (___|  (___|   (___|  (___|

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/turtles
""", 
"""
                   __.--'\"\"\"\"\"\"--._
               _.-'     \ ___ /    `-._
  .---.     .-'   \ ___/       \     / `-.
 /  () \  .'      /              ---      `.
|___    \/   \___/      \      /      \   / \ 
 \       `                ----               |`-._
  `--.    \ /     \     /       \     /    .'_.-'
      `-.__\       ---             --   .-'
           /`-._ /      \       /   _.-' \ 
         _/   / `------.______.----'  \   \ 
        ////.'                        ////'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/reptiles/turtles
""", 
"""
          _-~~~-_       _-~~~-_
        /~       ~\    :    ,  \ 
       '           ~   ,   |:  :
      {      /~~\  :--~\"\"\""\.:  :
       \    (... :   /^\  /^\\ ;
        ~\_____     |   | | |:~
              /     |__O|_|O|;
             (     /       O \ 
              \   ( `\_______/)
               `\  \         /
                 )  ~-------~'\ 
                /              \ 
               :               ||
               |  |            ||
               |  |.======[]==+'|
              (~~~~)       |   |~)
              /    \       |   | \ 
  ~\          \___/)______/^\__|_/
    `\\      //    |  |      | |
      `\\__//'     |  |      | |
         ~~       (~~~~)    (~~~)
                 /     =\..'    =_
                |__________)________)-jurcy

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rodents/mice
""", 
"""
        ()()         ____
        (..)        /|o  |
        /\/\       /o|  o|
       c\db/o...  /o_|_o_|   -Row

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rodents/mice
""", 
"""
~ a little standing mouse ~  9/96

     .--,       .--,
    ( (  \.---./  ) )
     '.__/o   o\__.'
        {=  ^  =}
         >  -  <
        /       \ 
       //       \\ 
      //|   .   |\\ 
      "'\       /'"_.-~^`'-.
         \  _  /--'         `
   jgs ___)( )(___
      (((__) (__)))

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rodents/mice
""", 
"""
   <'`,,-,,)-----

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rodents/mice
""", 
"""
     ---(___C'>

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rodents/mice
""", 
"""
  _____(,__,c'>

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rodents/mice
""", 
"""
   ___(m-mC'>

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rodents/mice
""", 
"""
    _()______
  /_'_/   /  `\            ,
     /'---\___/~~~~~~~~~~~~   jgs
    ~     ~~

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rodents/mice
""", 
"""
    ()-()
     \"/  jgs
      `

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rodents/mice
""", 
"""
   ()-().----.          .
    \"/` ___  ;________.'  jgs
     ` ^^   ^^

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rodents/mice
""", 
"""
     _  __
    (_)/   \ 
   <'_, ____)~~~~~~~     jgs
     ^^   ^^

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rodents/mice
""", 
"""
         ____()()
        /      @@
  `~~~~~\_;m__m._>o    jgs

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rodents/mice
""", 
"""
         _._
      .-'   `
    __|__
   /     \ 
   |()_()|
   \{o o}/   jgs
    =\o/=
     ^ ^

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rodents/mice
""", 
"""
* mouse w/cheese * 11/96

              (\-.
              / _`> .---------.
      _)     / _)=  |'-------'|
     (      / _/    |O   O   o|
 jgs  `-.__(___)_   | o O . o |
                    `---------'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rodents/mice
""", 
"""
        )
       (
     ()-()
    _(o o)_  Glo Pearl
     /\o/\ 

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rodents/mice
""", 
"""
**mice & moon**

  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  @@@@@@@@@@@@@@@@@@@@@@         @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  @@@@@@@@@@@@@@@@@@@@             @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  @@@@@@@@@@@@@@@@@@                 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  @@@@@@@@@@@@@@@@@                   @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  @@@@@@@@@@@@@@@@@                   @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  @@@@@@@@@@@@@@@@@@                 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  @@@@@@@@@@@@@@@@@@@@             @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  @@@@@@@@@@@@@@@@@@@@@@         @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  @@@@@@@@@@@@@@@@@ o @@@@@@@@ o @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  @@@@@@@@@@@@@@@ =/ \= @@@@ =/ \= @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  @@@@@@@@@@@@@@@ / " \ @@@@ / " \ @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  @@@@@@@@@@@@@@ /     \ @@ /     \ @@@@@@@@@@@@@@@@@@@@@@@@@@hjw@@@@
  @@@@@@@@@@@@@ /       \ */       \ @@@@@@@@@@@@@@@@@@@@@@@@@`97@@@@
  @@@@@@@@@@@@ |         ||         | @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  V#vvVVvv/y,~ \__\ /___/#v\__\ /__/~//y|#\\.vVvV/,y#||.,//vvVvVvV,,##
                   \\        //
                    \\      //
                     \\    //
                      \\  //
                       \\//
                        \y
                       //\\ 
                       \\//
                        \y
                       //\\ 
                       U  U

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rodents/mice
""", 
"""
      /\           /\ 
     ( \\_________// )
      \_\  o_ _o  /_/
        ( ===V=== )
        /  '-^-'  \ Hard
 ------""---------""--------
|                          |
|                          |
|                          |
|                          |
|                          |
 ---------------------------

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rodents/mice
""", 
"""
** squirrel **  10/96

     __  (\_
    (_ \ ( '>
      ) \/_)=
  jgs (_(_ )_

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rodents/other
""", 
"""
 _   m
( \ ( >o
 ( \/ V
  ( -.
   `--`

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rodents/other
""", 
"""
   ____
  (.   \ 
    \  |
     \ |___(\--/)
   __/    (  . . )
  "'._.    '-.O.'
       '-.  \ "|\ 
          '.,,/'.,,mrf

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rodents/other
""", 
"""
* rat *  11/96

         __             _,-"~^"-.
       _// )      _,-"~`         `.
     ." ( /`"-,-"`                 ;
    / 6                             ;
   /           ,             ,-"     ;
  (,__.--.      \           /        ;
   //'   /`-.\   |          |        `._________
     _.-'_/`  )  )--...,,,___\     \-----------,)
   ((("~` _.-'.-'           __`-.   )         //
     jgs ((("`             (((---~"`         //
                                            ((________________
                                            `----\"\"\""~~~~^^^```

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rodents/other
""", 
"""
Lemming
                  _
               _,/_\__
            .-',' \`-.'-.
         . ` .'    ;  `.  `.
        /   /      |    `.  '.
       /   |  __   |  __  \   \ 
      |_._ ;/`  `'-,-'  '-.|.-"\ 
     '-._ `'     _||   , . ,-"``
         '.-""-./  `)_,'`;'`7
                |  /<       '`\ 
               (`-'/| |\ ;._  7
                '-'\</`_`' _\ `>
                  \ `||_\ /_||_>
                   \ '\o7 'o/ |`-.      _.-.
                    ' \      /    ''|7-"    |
 "Hey, this is fun!  ' `.__.'  /`''-\j  _   /
  We should do it    ;        |       `-'`'`
  more often."       ;         \ 
                    /           `.
                   .'             `.
                  /                 \ mx
                 ;                   ;.-.
              .-.\                   /   |
             |   ``.               .'    /
             '.    7`-._       _.-'/  _.'
               `'-. `'  |"'-'`|  `' .'
                   `.__.'     `.__.'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rodents/other
""", 
"""
   (\~---.
   /   (\-`-/)
  (      ' ' )
   \ (  \_Y_/\ 
    ""\ \___//
       `w   "    -nathaN

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/rodents/other
""", 
"""
       ___ __
     _{___{__}\ 
    {_}      `\)
   {_}        `            _.-''''--.._
   {_}                    //'.--.  \___`.
    { }__,_.--~~~-~~~-~~-::.---. `-.\  `.)
     `-.{_{_{_{_{_{_{_{_//  -- 8;=- `
        `-:,_.:,_:,_:,.`\\._ ..'=- ,
            // // // //`-.`\`   .-'/
     jgs   << << << <<    \ `--'  /----)
            ^  ^  ^  ^     `-.....--'''

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/scorpions
""", 
"""
          ^^         |         ^^
          ::         |         ::
   ^^     ::         |         ::     ^^
   ::     ::         |         ::     ::
    ::     ::        |        ::     ::
      ::    ::       |       ::    ::
        ::    ::   _/~\_   ::    ::
          ::   :::/     \:::   ::
            :::::(       ):::::
                  \ ___ /
             :::::/`   `\:::::
           ::    ::\o o/::    ::
         ::     ::  :":  ::     ::
       ::      ::   ` `   ::      ::
      ::      ::           ::      ::
     ::      ::             ::      ::  R. Nykvist (Chuckles)
     ^^      ::             ::      ^^
             ::             ::
             ^^             ^^

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/spiders
""", 
"""
           ;               ,
         ,;                 '.
        ;:                   :;
       ::                     ::
       ::                     ::
       ':                     :
        :.                    :
     ;' ::                   ::  '
    .'  ';                   ;'  '.
   ::    :;                 ;:    ::
   ;      :;.             ,;:     ::
   :;      :;:           ,;"      ::
   ::.      ':;  ..,.;  ;:'     ,.;:
    "'"...   '::,::::: ;:   .;.;""'
        '\"\"\"....;:::::;,;.;\"\"\"
    .:::.....'"':::::::'",...;::::;.
   ;:' '""'"";.,;:::::;.'\"\"\"\"\"\"  ':;
  ::'         ;::;:::;::..         :;
 ::         ,;:::::::::::;:..       ::
 ;'     ,;;:;::::::::::::::;";..    ':.
::     ;:"  ::::::\"\"\"'::::::  ":     ::
 :.    ::   ::::::;  :::::::   :     ;
  ;    ::   :::::::  :::::::   :    ;
   '   ::   ::::::....:::::'  ,:   '
    '  ::    :::::::::::::"   ::
       ::     ':::::::::"'    ::
       ':       \"\"\"\"\"\""'      ::
        ::                   ;:
        ':;                 ;:"
-hrr-     ';              ,;'
            "'           '"
              '

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/spiders
""", 
"""
                         ,ood8888booo,
                      ,od8'         `8bo,
                   ,odP                 Ybo,
                 ,d8'                     `8b,
                ,oP                         Yo,
               ,8                             8,
               8Y                             Y8
               8l                   aba       l8
               Ya               ,ad'  8       aY
                Y8,           aY8,   ,P     ,8Y
                 Y8o          aP     8     o8Y
                  `Y8      ,aP'      8    8Y'
          ,arooowwwwwooo88P'        d'  aY'
       ,adP                        ,aa8P
      aP  a8a,                     d'
     $       Y          ,    ,    ,8
    $  $,    P     a8888b   daaa  8
   $  $ Y  aP 8  ad      8  8   8 `a
   $ $  8 8  d  P        d ,P   `8 8
   `$'  d 8  `8 ba       Y 8     `8 ba
        8  ba  8a$       8  ba    `8a$
         Yaa$             Yaa$
         Brent Hughes <bhughes@sms.business.uwo.ca>

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/wolves
""", 
"""
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@'~~~     ~~~`@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@'                     `@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@'                           `@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@'                               `@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@'                                   `@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@'                                     `@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@'                                       `@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@                                         @@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@'                                         `@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@                                           @@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@                                           @@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@                       n,                  @@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@                     _/ | _                @@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@                    /'  `'/                @@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@a                 <~    .'                a@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@                 .'    |                 @@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@a              _/      |                a@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@a           _/      `.`.              a@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@a     ____/ '   \__ | |______       a@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@a__/___/      /__\ \ \     \___.a@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@/  (___.'\_______)\_|_|        \@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@|\________                       ~~~~~\@@@@@@@@@@@@@@@@@@
~~~\@@@@@@@@@@@@@@||       |\___________________________/|@/~~~~~~~~~~~\@@@
    |~~~~\@@@@@@@/ |  |    | | by: S.C.E.S.W.          | ||\____________|@@

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/wolves
""", 
"""
         _
        / \      _-'
      _/|  \-''- _ /
 __-' { |          \ 
     /              \ 
     /       "o.  |o }
     |            \ ;
                   ',
        \_         __\ 
          ''-_    \.//
            / '-____'
           /
         _'
       _-'
by S. Whang <whang@toro.kuee.kyoto_u.ac.jp>

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/wolves
""", 
"""
               .+i+;I:
              :=..    t:
             =;+;:..   ii.
            +I::;=:;;+t=i;=.
            +;;;+;i.;;:It++i;             (c) Paul Fawcett 1994
          ;X  t+=+=;;i;=iItt+V
          :t  =ii+.=.;:=+ii++iIY
          :R   i=ti+=+;i+i=t=++:+Ii+==
          :R  .+iii==;;itt=++i=i::=YRBBBMRRVY+;
           ;+    +i+;+;+itiiitii+i+i .=iYVIi+iitI=;=
   +. ::.X:.;   .:=;+=i=ii++YYIIiiiIt.  ;YI::+:;=iit===;
  I;:. .  :+:YI;R..=;;=i+titIVItIYVYYYXVX=+:.....;;+t=+::=
  +i;.::......:;:=;;;;;=+iii=+=++ii++tttVI===;;;;::;;+;tti=
   tI+.::::.;::;:=+++i=+;i++ititttItIItt=;=t+==;:;::;:;=+IY=:
    :=i;::.::::;=:;++=i===;iiittitttttItt=;=;:;;...::;::;.;+ii:;
      :=+::.;+i+t++itiIIY=RRRXXV+VYi===:::;;:.:.........::;;;:;;;;:;;;;
          :tYti=;=+;+;=+++=;iIVRRRRVVRXRYYYV=;=::::..........:.:==+i==;;==;;:
            ;Xti;=;+i;+ti++=+tRBBBYBVRYXIVtYY++=..:........:.;;::==;::;.;;;
              YVi==;++:I;;ii+IRXIYIY=:;i;i;=;;;;;.........;:::;:;=;..:;::
              :=XI=+iItIiit=:IXRRIItiXiIYiIt;I==:.......:..:....;:........
              :BWRRV;YRIXY...+YRRVYVR+XIRItitI++=:.....;:.........:....:.::..
             ==+RWBXtIRRV+.+IiYRBYBRRYYIRI;VitI;=;..........:::.::;::::...;;;:.
                  Paul Fawcett <paulf@manor.demon.co.uk>

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/wolves
""", 
"""
*     *    *     /\__/\  *    ---    *
   *            /      \    /     \ 
        *   *  |  -  -  |  |       |*
 *   __________| \     /|  |       |
   /              \ T / |   \     /
 /                      |  *  ---
|  ||     |    |       /             *
|  ||    /______\     / |*     *
|  | \  |  /     \   /  |
 \/   | |\ \      | | \ \ 
      | | \ \     | |  \ \ 
      | |  \ \    | |   \ \ 
      '''   '''   '''    '''   Melissa

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/wolves
""", 
"""
* howling coyote/wolf * 11/96

               .-'''''-.
             .'         `.
            :             :
           :               :
           :      _/|      :
            :   =/_/      :
             `._/ |     .'
          (   /  ,|...-'
           \_/^\/||__
        _/~  `""~`"` \_
     __/  -'/  `-._ `\_\__
   /jgs  /-'`  `\   \  \-.\ 

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/wolves
""", 
"""
                                                                            ,aa,       ,aa
                                                                           d"  "b    ,d",`b
                                                                         ,dP a  "b,ad8' 8 8
                                                                         d8' 8  ,88888a 8 8
                                                                        d8baa8ba888888888a8
                                                                     ,ad888888888YYYY888YYY,
                                                                  ,a888888888888"   "8P"  "b
                                                              ,aad8888tt,8888888b (0 `8, 0 8
                          ____________________________,,aadd888ttt8888ttt"8"I  "Yb,   `Ya  8
                    ,aad8888b888888aab8888888888b,     ,aatPt888ttt8888tt 8,`b,   "Ya,. `"aP
                ,ad88tttt8888888888888888888888888ttttt888ttd88888ttt8888tt,t "ba,.  `"`d888
             ,d888tttttttttttttt888888888888888888888888ttt8888888888ttt888ttt,   "a,   `88'
            a888tttttttttttttttttttttttttt8888888888888ttttt88888ttt888888888tt,    `""8"'
           d8P"' ,tttttttttttttttttttttttttttttttttt88tttttt888tttttttt8a"8888ttt,   ,8'
          d8tb  " ,tt"  ""tttttttttttttttttttttttttttttttttt88ttttttttttt, Y888tt"  ,8'
          88tt)              "t" ttttt" \"\"\"  \"\"\"    "" tttttYttttttttttttt, " 8ttb,a8'
          88tt                    `"b'                  ""t'ttttttttttt"t"t   t taP"
          8tP                       `b                       ,tttttt' " " "tt, ,8"
         (8tb  b,                    `b,                 a,  tttttt'        ""dP'
         I88tb `8,                    `b                d'   tttttt        ,aP"
         8888tb `8,                   ,P               d'    "tt "t'    ,a8P"
        I888ttt, "b                  ,8'              ,8       "tt"  ,d"d"'
       ,888tttt'  8b               ,dP\"\"\"\"\"\"\"\"\"\"\"\"\"\"\""Y8        tt ,d",d'
     ,d888ttttP  d"8b            ,dP'                  "b,      "ttP' d'
   ,d888ttttPY ,d' dPb,        ,dP'      Normand         "b,     t8'  8
  d888tttt8" ,d" ,d"  8      ,d"'        Veilleux         `b     "P   8
 d888tt88888d" ,d"  ,d"    ,d"                             8      I   8
d888888888P' ,d"  ,d"    ,d"                               8      I   8
88888888P' ,d"   (P'    d"                                 8      8   8
"8P"'"8   ,8'    Ib    d"                                  Y      8   8
      8   d"     `8    8                                   `b     8   Y
      8   8       8,   8,                                   8     Y   `b
      8   Y,      `b   `b                                   Y     `b   `b
      Y,   "ba,    `b   `b,                                 `b     8,   `"ba,
       "b,   "8     `b    `""b                               `b     `Yaa,adP'
         \"\"\"""'      `baaaaaaP                                `YaaaadP"'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/wolves
""", 
"""
                                                                            ,aa,       ,aa
                                                                           d"  "b    ,d",`b
                                                                         ,dP a  "b,ad8' 8 8
                                                                         d8' 8  ,8P'Y8a 8 8
                                                                        d8baa8baP'    `Y8a8
                                                                     ,adP"'               Y,
                                                                  ,a8P"               a   `b
                                                              ,aadP"              (0  Y, 0 8
                          ____________________________,,aaddPP""'8'         I          "a  8
                    ,aad8PP\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"'        8,         `b,          "aP
                ,adP"                                             "a          "ba,.     d888
             ,dP"                                                   "a,           "a,   `88'
            a"                                                         "'           `""8"'
           d"                                                                        ,8'
          d"                                                                        ,8'
          8                                                                       ,a8'
          8                         b                                            aP"
          8                         `b                                         ,8"
         (8    b,                    `b,                 a,                   dP'
         I8    `8,                    `b                d'                 ,aP"
         8'     `8,                   ,P               d'               ,a8P"
        I8       "b                  ,8'              ,8             ,d"d"'
       ,8'        8b               ,dP\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"Y8           ,d",d'
     ,d"         d"8b            ,dP'                  "b,        ,P' d'
   ,d"         ,d' dPb,        ,dP'      Normand         "b,      8'  8
  d"         ,d" ,d"  8      ,d"'        Veilleux         `b      P   8
 d"        ,d" ,d"  ,d"    ,d"                             8      I   8
d"      ,dP' ,d"  ,d"    ,d"                               8      I   8
8,  ,ad8P' ,d"   (P'    d"                                 8      8   8
"YP"'"8   ,8'    Ib    d"                                  Y      8   8
      8   d"     `8    8                                   `b     8   Y
      8   8       8,   8,                                   8     Y   `b
      8   Y,      `b   `b                                   Y     `b   `b
      Y,   "ba,    `b   `b,                                 `b     8,   `"ba,
       "b,   "8     `b    `""b                               `b     `Yaa,adP'
         \"\"\"\"\"'      `baaaaaaP                                `YaaaadP"'

------------------------------------------------
Thank you for visiting https://asciiart.website/
This ASCII pic can be found at
https://asciiart.website/index.php?art=animals/wolves
"""
]

