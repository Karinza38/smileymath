This module has been designed for kids to practice elementary math operation. 
The tool is quite minimalist and the only gadget is the printing of an ascii art picture from one of the following theme: animals, star wars, Harry Potter.

The current the challenges categories are:
* adding two numbers
* subtracting two numbers
* complementing to 10
* multiplying
* dividing (with or without remainder)
* adding times
* subtracting times

You can define the number of challenges as well as a maximum time to respond. 


In the example section you can find how to start the tool with a GUI or how to start one or multiple sets of challenges. 

To start the GUI interface type in your console

```
smileymath
```

To start a specific program 
```
smileymath --ce1
smileymath --cm1
```

# Installation

```
pip3 install smileymath
```

