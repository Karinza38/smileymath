#!/usr/bin/python3

import argparse
import mymath.gui
import mymath.challenge


def gui():
  mymath.gui.MyMathTUI()
    

def ce1( ):
  challenge_nbr = 20
  args = { 'y' : [ 0, 20], 'x' : [ 0, 20 ], 'challenge_nbr' : challenge_nbr, \
         'ascii_fig' : "animals", 'timeout' : 7 }
  mymath.challenge.AdditionSet( **args )
  mymath.challenge.ComplementTo10Set(  **args )
  mymath.challenge.SubtractionSet( **args )

  args = { 'y' : [ 0, 3 ], 'x' : [ 0, 10 ], 'challenge_nbr' : challenge_nbr, \
         'ascii_fig' : "star wars", 'timeout' : 5 }
  mymath.challenge.MultiplicationSet( **args )

def cm1( ):
  challenge_nbr = 20
  args = { 'y' : [ 2, 9], 'x' : [ 2, 9 ], 'challenge_nbr' : challenge_nbr, \
           'ascii_fig' : "animals", 'timeout' : 5 }
  mymath.challenge.MultiplicationSet( **args )

  args = { 'y' : [ 1, 10], 'x' : [ 1, 10 ], 'challenge_nbr' : challenge_nbr, \
           'ascii_fig' : "star wars", 'timeout' : 8 }
  mymath.challenge.DivisionSet( **args )

  args = { 'y' : [ 1, 100], 'x' : [ 1, 10 ], 'challenge_nbr' : challenge_nbr, \
           'ascii_fig' : "animals", 'timeout' : 8 }
  mymath.challenge.DivisionWithRemainderSet( **args )

  args = { 'challenge_nbr' : 10, 'ascii_fig' : "Harry Potter", 'timeout' : 60 }
  mymath.challenge.HourMinuteAdditionSet( **args )
  mymath.challenge.HourMinuteSubstractionSet( **args )

def cli( ):
  """ CLI for myMath """
  description = "myMath"  
  parser = argparse.ArgumentParser( description=description )
  parser.add_argument( '-ce1', '--ce1', default=False,  \
  action='store_const', const=True, \
  help="Tests for CE1" )
  parser.add_argument( '-cm1', '--cm1', default=False,  \
  action='store_const', const=True, \
  help="Tests for CM1" )
  args = parser.parse_args()

  if args.ce1 is True:
    ce1()
  elif args.cm1 is True:
    cm1()
  else:  
    gui()    


if __name__ == "__main__":
  cli()  


